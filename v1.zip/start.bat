@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 灵枢 v3 - 小说工程化（工程 + 文件 + 双库）

set "PY="
py -3 -c "import sys" >nul 2>&1
if not errorlevel 1 set "PY=py -3"
if not defined PY (
  python -c "import sys" >nul 2>&1
  if not errorlevel 1 set "PY=python"
)
if not defined PY (
  echo   [错误] 没有找到 Python 3.8+，请安装后重试。
  pause
  exit /b 1
)

%PY% "%~dp0backend\run.py"
if errorlevel 1 pause
