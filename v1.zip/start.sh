#!/usr/bin/env bash
# 灵枢 v3 —— 一键启动（Linux / macOS）。零第三方依赖。
set -u
cd "$(dirname "$0")"

PY=""
for c in python3 python3.13 python3.12 python3.11 python3.10 python3.9 python; do
  command -v "$c" >/dev/null 2>&1 || continue
  if "$c" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,8) else 1)' 2>/dev/null; then
    PY="$c"; break
  fi
done
[ -n "$PY" ] || { echo "  [错误] 没有找到 Python 3.8+"; exit 1; }
exec "$PY" backend/run.py
