"""v3 启动入口。"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app import files  # noqa: E402
from app.server import serve  # noqa: E402

if __name__ == "__main__":
    port = 8013
    if "--port" in sys.argv:
        port = int(sys.argv[sys.argv.index("--port") + 1])
    # 首次启动：手动编辑模式自带一个入门工程，打开就有东西可看
    created = files.ensure_manual_project()
    if created:
        print(f"[v3] 已创建入门工程「{created}」（手动编辑模式，不需要 API Key）")
    raise SystemExit(serve(port))
