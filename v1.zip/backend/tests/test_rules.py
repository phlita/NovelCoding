# -*- coding: utf-8 -*-
"""内置规则引擎 + AI 规范 的测试。

规则是「小说编程语言」的标准库：条件成立自动改状态，或在事件里主动调用。
这里验证：占位符展开、世界规则触发、内置函数、规则可编辑、规范文本完整。
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import aispec, files, rules  # noqa: E402
from app.kernel import Kernel, State  # noqa: E402

FAILS: list[str] = []


def check(label, got, want=None, *, truthy=False):
    ok = bool(got) if truthy else (got == want)
    msg = "  ✔ " + label
    if not ok:
        msg = "  ✘ " + label + f"   期望 {want!r}，实际 {got!r}"
        FAILS.append(label)
    print(msg)


def show(title):
    print()
    print("=" * 62)
    print(title)
    print("=" * 62)


def fresh_state() -> State:
    st = State()
    st.变量["时辰"] = 22
    st.变量["疲惫在场"] = 0
    st.人物状态["李三"] = {"精力": 50, "动机": 18, "胆量": 30, "饥饿": 70, "戒备": 0}
    st.人物状态["赵爷"] = {"精力": 60, "动机": 50, "胆量": 40, "饥饿": 10, "戒备": 0}
    st.关系["李三-赵爷"] = {"信任": 0, "亏欠": 1}
    return st


def kernel_of(st: State) -> Kernel:
    return Kernel(st, known_persons={"李三", "赵爷"}, known_places=set(),
                  known_vars=set(st.变量), known_pairs=set(st.关系))


# --------------------------------------------------------------------------- #
def test_expand():
    show("一、占位符展开")
    check("{全部} 换成人名", rules._expand("s.{全部}.精力 -= 8", {"全部": "李三"}),
          "s.李三.精力 -= 8")
    check("多参数", rules._expand("s.{人物}.动机 -= {幅度}", {"人物": "李三", "幅度": 3}),
          "s.李三.动机 -= 3")
    check("不认识的占位符原样保留",
          rules._expand("s.{未知}.x += 1", {}), "s.{未知}.x += 1")


def test_world_rules():
    show("二、世界规则自动触发")
    rules.reset()
    st = fresh_state()
    k = kernel_of(st)
    trace: list[dict] = []
    fired = rules.apply_world_rules(k, "第01章", trace)
    check("有规则触发", fired > 0, truthy=True)

    # 时辰=22 → 天黑了要睡（精力 -8、胆量 -2）
    # 随后 desire_decay（动机≤20 且 饥饿≥60）再扣 精力 -2
    check("深夜精力下降（50 → 42 → 40）", st.人物状态["李三"]["精力"], 40)
    check("深夜胆量下降（30 → 28）", st.人物状态["李三"]["胆量"], 28)
    check("轨迹里记了规则", any(t.get("来源") == "规则" for t in trace), True)

    # 动机 18 且 饥饿 70 → 动机衰减
    check("又饿又没盼头 → 动机下降（18 → 14）", st.人物状态["李三"]["动机"], 14)

    # 信任 0 → 李三对赵爷戒备上升
    check("信任见底 → 戒备上升", st.人物状态["李三"]["戒备"], 3)

    # 赵爷饥饿只有 10，不该触发饥饿规则
    check("赵爷不受饥饿规则影响", st.人物状态["赵爷"]["胆量"], 38)


def test_world_rule_conditions_editable():
    show("三、规则条件可改（这就是「手动改每个条件」）")
    backup = rules.load()
    try:
        rules.save({"world": [{
            "id": "custom", "name": "自定义规则", "enabled": True,
            "当": "v.时辰 >= 22", "则": ["s.{全部}.精力 -= 1"], "说明": "测试用",
        }]})
        st = fresh_state()
        rules.apply_world_rules(kernel_of(st), "第01章", [])
        check("自定义条件生效（只减 1）", st.人物状态["李三"]["精力"], 49)
        check("旧规则已不再触发（动机不变）", st.人物状态["李三"]["动机"], 18)

        # 关掉
        rules.save({"world": [{
            "id": "custom", "name": "自定义规则", "enabled": False,
            "当": "v.时辰 >= 22", "则": ["s.{全部}.精力 -= 1"],
        }]})
        st2 = fresh_state()
        rules.apply_world_rules(kernel_of(st2), "第01章", [])
        check("关掉后不再触发", st2.人物状态["李三"]["精力"], 50)
    finally:
        rules.save({"world": backup["world"], "fn": backup["fn"]})


def test_builtin_functions():
    show("四、内置函数（事件里调用）")
    rules.reset()
    st = fresh_state()
    k = kernel_of(st)
    trace: list[dict] = []
    ok = rules.call_function(k, "调用 动机衰减(李三, 3)", "第01章", trace)
    check("调用成功", ok, True)
    check("动机 18 → 15", st.人物状态["李三"]["动机"], 15)

    trace2: list[dict] = []
    rules.call_function(k, "调用 疲惫(李三, 5)", "第01章", trace2)
    check("精力 50 → 45", st.人物状态["李三"]["精力"], 45)
    check("胆量 30 → 25", st.人物状态["李三"]["胆量"], 25)

    trace3: list[dict] = []
    ok3 = rules.call_function(k, "调用 不存在的函数(李三)", "第01章", trace3)
    check("不存在的函数返回 False", ok3, False)
    check("并给出提示", any("没有名为" in t.get("说明", "") for t in trace3), True)

    trace4: list[dict] = []
    rules.call_function(k, "调用 动机衰减(李三)", "第01章", trace4)
    check("参数不足时告警", any("需要 2 个参数" in t.get("说明", "") for t in trace4), True)

    # 事件里的 @效果 调用：走 kernel 的公开入口
    trace5: list[dict] = []
    k.apply_effect_raw("调用 被安抚(李三, 2)", "第01章", "试探", trace5)
    check("kernel.apply_effect_raw 能识别「调用」", st.人物状态["李三"]["动机"], 17)


def test_rules_persist():
    show("五、规则文件读写")
    rules.reset()
    d = rules.describe()
    check("有变量约定", bool(d["变量约定"]), truthy=True)
    check("有世界规则", len(d["world"]) >= 5, truthy=True)
    check("有内置函数", len(d["fn"]) >= 3, truthy=True)
    check("规则文件已落盘", Path(d["文件"]).is_file(), True)

    v1 = d["version"]
    rules.save({"说明": "改过的说明"})
    d2 = rules.describe()
    check("版本号递增", d2["version"] > v1, True)
    check("说明被保存", d2["说明"], "改过的说明")
    rules.reset()
    check("重置后回到默认说明", rules.describe()["说明"], rules.DEFAULT_RULES["说明"])


def test_aispec():
    show("六、AI 规范（接入后直接产出条目）")
    rules.reset()
    text = aispec.spec_text()
    check("含标题", "小说编程 · 条目编写规范" in text, True)
    check("列了所有大类", all(cat in text for cat in files.REGISTRY), True)
    check("讲了解释 @ 注释区", "@" in text and "注释区" in text, True)
    check("讲了表达式 v./s./r.", "v.变量名" in text and "s.人物.字段" in text, True)
    check("列了内置函数", "动机衰减" in text, True)
    check("提到世界规则自动生效", "自动" in text, True)
    check("要求标注待补而不是编造", "@待补" in text, True)
    check("要求写文件名行", "文件名：" in text, True)
    check("规范足够长（不是敷衍）", len(text) > 2000, truthy=True)

    js = aispec.spec_json()
    check("JSON 版有 registry", bool(js["registry"]), truthy=True)
    check("JSON 版有 functions", len(js["functions"]) >= 3, truthy=True)
    check("JSON 版有 world_rules", len(js["world_rules"]) >= 5, truthy=True)
    check("JSON 版含完整文本", js["text"] == text, True)


def test_build_with_rules():
    show("七、构建时规则真的生效（端到端）")
    from app import builder

    rules.reset()
    files.ensure_manual_project()
    proj = files.MANUAL_PROJECT
    # 「我的第一部小说」里没有 时辰/精力 这类变量，规则应当安静跳过而不是报错
    report = builder.build(proj)
    check("构建没有错误", report["统计"]["错误"], 0)
    check("正文照常产出", report["统计"]["总字数"] > 0, truthy=True)


def test_empty_falls_back_to_default():
    show("八、全部删掉 → 用默认兜底")
    backup = rules.load()
    try:
        # 显式清空两份清单
        rules.save({"world": [], "fn": []})
        d = rules.describe()
        check("标记为用默认兜底", d["用默认兜底"], True)
        check("世界规则仍有内容（兜底）", len(d["world"]) >= 5, truthy=True)
        check("内置函数仍有内容（兜底）", len(d["fn"]) >= 3, truthy=True)

        # 兜底规则仍然真的生效
        st = fresh_state()
        n = rules.apply_world_rules(kernel_of(st), "第01章", [])
        check("兜底规则会触发", n > 0, truthy=True)
        check("精力确实降了", st.人物状态["李三"]["精力"] < 50, True)

        # 只留一条自定义 → 不再兜底，只跑那条
        rules.save({"world": [{"id": "only", "name": "唯一规则", "enabled": True,
                               "当": "v.时辰 >= 22", "则": ["s.{全部}.精力 -= 1"]}], "fn": []})
        d2 = rules.describe()
        check("不再是默认兜底", d2["用默认兜底"], False)
        check("只剩一条世界规则", len(d2["world"]), 1)
        check("函数回落到兜底（空数组）", len(d2["fn"]) >= 3, truthy=True)
    finally:
        rules.save({"world": backup["world"], "fn": backup["fn"]})


def test_rule_add_delete():
    show("九、规则可增删")
    backup = rules.load()
    try:
        world = list(backup["world"])
        world.append({"id": "user_made", "name": "我加的规则", "enabled": True,
                      "当": "v.时辰 == 3", "则": ["s.{全部}.胆量 -= 1"], "说明": "凌晨"))
        rules.save({"world": world, "fn": backup["fn"]})
        d = rules.describe()
        check("新增的规则在清单里", any(r.get("id") == "user_made" for r in d["world"]), True)

        # 删掉它
        rules.save({"world": backup["world"], "fn": backup["fn"]})
        d2 = rules.describe()
        check("删除后不在了", any(r.get("id") == "user_made" for r in d2["world"]), False)
        check("原有规则还在", len(d2["world"]) == len(backup["world"]), True)
    finally:
        rules.save({"world": backup["world"], "fn": backup["fn"]})


def main():
    test_expand()
    test_world_rules()
    test_world_rule_conditions_editable()
    test_builtin_functions()
    test_rules_persist()
    test_aispec()
    test_build_with_rules()
    test_empty_falls_back_to_default()
    test_rule_add_delete()
    print()
    if FAILS:
        print(f"失败 {len(FAILS)} 项：" + "；".join(FAILS))
        sys.exit(1)
    print("全部通过。")


if __name__ == "__main__":
    main()
