# -*- coding: utf-8 -*-
"""归并 / 跨库引用 / 单章重建 三项新能力的测试。

和无运行环境时也能看懂：每一段先建一个临时工程，再断言行为。
"""
import json
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import builder, files, merge  # noqa: E402

FAILS: list[str] = []
TMP = "测试用工程"


def check(label, got, want=None, *, truthy=False):
    ok = bool(got) if truthy else (got == want)
    msg = "  ✔ " + label
    if not ok:
        msg = "  ✘ " + label + f"   期望 {want!r}，实际 {got!r}"
        FAILS.append(label)
    print(msg)


def show(title):
    print()
    print("=" * 62)
    print(title)
    print("=" * 62)


def fresh(name: str, extra: dict[str, str] | None = None) -> str:
    if (files.PROJECTS / name).exists():
        files.delete_project(name)
    files.create_project(name, "测试", "", "")
    for fn, body in (extra or {}).items():
        files.write_file("project", name, fn, body)
    return name


# --------------------------------------------------------------------------- #
def test_merge_suggest():
    show("一、实体归并：建议（确定性、带证据、排除同场）")
    p = fresh(TMP, {
        "李三.人物.属性": "@条目 李三\n身份 伙计\n",
        "三爷.人物.属性": "@条目 三爷\n@待审 称谓型角色\n年龄 40\n",
        "那人.人物.属性": "@条目 那人\n@待审 泛称角色（正文没给名字）\n",
        "第01章.剧本.正文": "@条目 第01章\n@章 第01章\n李三进了当铺。\n三爷在柜台后抬头。\n",
        "第02章.剧本.正文": "@条目 第02章\n@章 第02章\n那人推门进来。\n",
    })
    s = merge.suggest(p)
    both = [c for c in s["候选"] if {c["甲"], c["乙"]} == {"李三", "三爷"}]
    check("李三 与 三爷 第01章同场 → 不建议合并", both, [])
    check("泛称角色被单列", "那人" in s["泛称角色"], True)
    check("称谓角色被单列", "三爷" in s["称谓角色"], True)
    check("人物总数", s["人物总数"], 3)


def test_merge_apply():
    show("二、实体归并：执行（属性合并 / 关系重排 / 正文改名 / 旧文件删除）")
    p = fresh(TMP, {
        "李三.人物.属性": "@条目 李三\n身份 伙计\n年龄 23\n",
        "李三.人物.状态": "@条目 李三\n戒备 = 0\n",
        "三爷.人物.属性": "@条目 三爷\n@待审 称谓型角色\n身份 掌柜\n气质 先看手\n",
        "三爷.人物.知识": "@条目 三爷\n@知 字据是假的\n",
        "李三-三爷.关系.关系网": "@条目 关系\n信任 = 2\n",
        "试探.事件.逻辑": "@条目 试探\n@出场 李三 三爷\n@揭示 李三：三爷认得慢\n",
        "第01章.剧本.正文": "@条目 第01章\n@章 第01章\n三爷把字据推过来，李三没接。\n",
    })
    rep = merge.apply(p, [{"旧名": "三爷", "新名": "李三"}])
    root = files.scope_root("project", p)

    check("有重写文件", len(rep["重写文件"]) > 0, truthy=True)
    check("旧文件被删除", any("三爷.人物" in f for f in rep["删除文件"]), True)
    check("三爷.人物.属性 已不存在", (root / "三爷.人物.属性").exists(), False)

    attr = (root / "李三.人物.属性").read_text(encoding="utf-8")
    check("属性合并：保留原有 身份=伙计", "身份 伙计" in attr, True)
    check("属性合并：冲突不改写（三爷的 掌柜 被丢弃）", "掌柜" not in attr, True)
    check("属性合并：补进 年龄", "年龄 23" in attr, True)
    check("属性合并：补进 气质", "气质 先看手" in attr, True)

    know = (root / "李三.人物.知识").read_text(encoding="utf-8")
    check("知识并集：补建了 李三.人物.知识", (root / "李三.人物.知识").exists(), True)
    check("知识并集：含三爷原先知道的事", "字据是假的" in know, True)

    check("关系两端并成同一人 → 旧关系文件被删除",
          (root / "李三-三爷.关系.关系网").exists(), False)

    ev = (root / "试探.事件.逻辑").read_text(encoding="utf-8")
    check("事件里 @出场 的 三爷 已改名为 李三", "三爷" not in ev, True)
    check("事件里 @揭示 的 三爷 已改名", "李三：李三认得慢" in ev, True)

    script = (root / "第01章.剧本.正文").read_text(encoding="utf-8")
    check("剧本正文里 三爷 → 李三", "三爷" not in script and "李三把字据推过来" in script, True)

    rpt = json.loads((root.parent / "state" / "归并报告.json").read_text(encoding="utf-8"))
    check("归并报告落盘", rpt["归并"][0]["保留"], "李三")


def test_merge_guards():
    show("三、实体归并：拒绝不安全的映射")
    p = fresh(TMP, {"李三.人物.属性": "@条目 李三\n", "赵爷.人物.属性": "@条目 赵爷\n"})
    for label, mapping in [("目标不存在", [{"旧名": "李三", "新名": "王五"}]),
                           ("旧名不存在", [{"旧名": "张三", "新名": "李三"}]),
                           ("自映射", [{"旧名": "李三", "新名": "李三"}])]:
        try:
            merge.apply(p, mapping)
            check(label + " → 应报错", False, True)
        except files.FsError:
            check(label + " → 被拦下", True)


def test_library_import():
    show("四、跨库引用：项目里没有的 @导入 去公共库解析")
    # 造一个公共库条目
    lib = files.LIBRARY / "行为"
    lib.mkdir(parents=True, exist_ok=True)
    lib_file = lib / "测试习惯.行为.习惯"
    lib_file.write_text("@条目 测试习惯\n适用范围 公有\n表现 说话前停一下\n", encoding="utf-8")
    p = fresh(TMP, {
        "李三.人物.属性": "@条目 李三\n@导入 测试习惯.行为.习惯\n身份 伙计\n",
        "第01章.剧本.正文": "@条目 第01章\n@章 第01章\n他停了一下才开口。\n",
    })
    proj = builder.Project(p)
    check("从公共库解析出条目", "测试习惯.行为.习惯" in set(proj.从公共库), True)
    check("没有缺失依赖", proj.缺失依赖, [])

    # 项目里有同名定义时，项目优先
    files.write_file("project", p, "测试习惯.行为.习惯", "@条目 测试习惯\n表现 项目自己的定义\n")
    proj2 = builder.Project(p)
    check("项目自己也有同名条目 → 不走公共库", "测试习惯.行为.习惯" not in set(proj2.从公共库), True)

    # 找不到的导入 → 记进缺失
    files.write_file("project", p, "赵爷.人物.属性", "@条目 赵爷\n@导入 不存在的条目.行为.习惯\n")
    proj3 = builder.Project(p)
    check("找不到的导入记进缺失依赖", any("不存在的条目" in d for d in proj3.缺失依赖), True)
    lib_file.unlink(missing_ok=True)


def test_single_chapter_build():
    show("五、单章重建：只重跑一章，不推进全书终态")
    import seed_demo_project
    seed_demo_project.main()
    p = "当铺"
    full = builder.build(p)
    state_path = files.scope_root("project", p).parent / "state" / "运行时状态.json"
    full_state = json.loads(state_path.read_text(encoding="utf-8"))

    ch2_before = (files.scope_root("build", p) / "第02章.txt").read_text(encoding="utf-8")

    rep = builder.build(p, chapters=["第01章"], start_state=full_state,
                        report_dir=files.scope_root("build", p) / "单章重建")
    check("单章重建只跑一章", [c["章"] for c in rep["章节"]], ["第01章"])
    check("单章轨迹写到 build/单章重建/",
          (files.scope_root("build", p) / "单章重建" / "执行轨迹.md").is_file(), True)
    check("单章重建没有覆盖全书报告",
          json.loads((files.scope_root("build", p) / "构建报告.json").read_text(encoding="utf-8"))["统计"]["章节数"], 2)
    ch2_after = (files.scope_root("build", p) / "第02章.txt").read_text(encoding="utf-8")
    check("其它章节正文没被动", ch2_after == ch2_before, True)
    check("终态没被单章重建推进", json.loads(state_path.read_text(encoding="utf-8")), full_state)


def main():
    test_merge_suggest()
    test_merge_apply()
    test_merge_guards()
    test_library_import()
    test_single_chapter_build()
    for name in (TMP,):
        if (files.PROJECTS / name).exists():
            files.delete_project(name)
    print()
    if FAILS:
        print(f"失败 {len(FAILS)} 项：" + "；".join(FAILS))
        sys.exit(1)
    print("全部通过。")


if __name__ == "__main__":
    main()
