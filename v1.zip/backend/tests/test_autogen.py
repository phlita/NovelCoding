# -*- coding: utf-8 -*-
"""AI 全自动生成：解析 + 写入 的测试。不联网。"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import autogen, files  # noqa: E402

FAILS: list[str] = []
TMP = "自动生成测试"


def check(label, got, want=None, *, truthy=False):
    ok = bool(got) if truthy else (got == want)
    msg = "  ✔ " + label
    if not ok:
        msg = "  ✘ " + label + f"   期望 {want!r}，实际 {got!r}"
        FAILS.append(label)
    print(msg)


def show(title):
    print()
    print("=" * 62)
    print(title)
    print("=" * 62)


REPLY = """好的，我来生成。

```
文件名：李三.人物.属性
@条目 李三
@注释 当铺伙计
身份 伙计
年龄 23
```

```
文件名：李三.人物.状态
@条目 李三
戒备 = 0
精力 = 80
```

```
文件名：试探.事件.逻辑
@条目 试探
@前置 v.字据在手==1
@出场 李三
@效果 s.李三.戒备 += 2
```
"""


def test_parse():
    show("一、解析模型回复")
    got = autogen.parse_reply(REPLY)
    names = [g["文件名"] for g in got]
    check("解析出 3 个文件", len(got), 3)
    check("文件名正确", names, ["李三.人物.属性", "李三.人物.状态", "试探.事件.逻辑"])
    check("内容不含围栏", "```" not in got[0]["内容"], True)
    check("内容不含「文件名：」行", "文件名" not in got[0]["内容"], True)
    check("内容保留了 @ 行", got[0]["内容"].startswith("@条目 李三"), True)
    check("内容以换行结尾", got[0]["内容"].endswith("\n"), True)

    # 不带围栏的兜底
    plain = "文件名：赵爷.人物.属性\n身份 掌柜\n"
    check("无围栏也能认", len(autogen.parse_reply(plain)), 1)

    # 同名去重
    dup = "```\n文件名：A.人物.属性\nx 1\n```\n```\n文件名：A.人物.属性\ny 2\n```\n"
    d = autogen.parse_reply(dup)
    check("同名只取第一次", len(d), 1)
    check("取的是第一次的内容", "x 1" in d[0]["内容"], True)

    check("空回复返回空", autogen.parse_reply(""), [])
    check("纯散文返回空", autogen.parse_reply("这是一段正常的解释，没有任何文件名标记。"), [])


def test_generate_dry_run():
    show("二、生成：文件名校验 + 跳过规则")
    if (files.PROJECTS / TMP).exists():
        files.delete_project(TMP)
    files.create_project(TMP, "测试", "", "")
    root = files.scope_root("project", TMP)

    # 预先放一个文件，验证「不覆盖」策略
    (root / "李三.人物.属性").write_text("@条目 李三\n身份 原样\n", encoding="utf-8")

    items = autogen.parse_reply(REPLY)
    from app import files as F

    written, skipped = [], []
    for it in items:
        name = it["文件名"]
        info = F.parse_filename(name)
        if not info["ok"]:
            skipped.append((name, info["why"]))
            continue
        target = root / name
        if target.exists():
            skipped.append((name, "已存在"))
            continue
        written.append(name)

    check("新文件会被写", "李三.人物.状态" in written, True)
    check("已存在的不覆盖", "李三.人物.属性" in [s[0] for s in skipped], True)
    check("原有内容没被动", "原样" in (root / "李三.人物.属性").read_text(encoding="utf-8"), True)

    # 非法文件名必须被挡
    bad = autogen.parse_reply("```\n文件名：随便一个名字\n内容\n```\n")
    check("非法文件名解析出来", len(bad), 1)
    info = F.parse_filename(bad[0]["文件名"])
    check("非法文件名校验不通过", info["ok"], False)
    check("给出原因", bool(info["why"]), truthy=True)

    files.delete_project(TMP)


def test_context_summary():
    show("三、上下文摘要（避免重复造人）")
    files.ensure_manual_project()
    s = autogen.context_summary(files.MANUAL_PROJECT)
    check("有摘要", bool(s), truthy=True)
    check("列出人物", "人物" in s, truthy=True)
    check("含已有的人名", "李三" in s, True)

    system, user = autogen.build_prompt(files.MANUAL_PROJECT, "写第 02 章")
    check("system 含规范", "条目编写规范" in system, True)
    check("system 含已有条目", "李三" in system, True)
    check("user 含任务", "写第 02 章" in user, True)
    check("user 要求文件名写法", "文件名：" in user, True)


def test_generate_guards():
    show("四、生成的前置检查")
    # 缺 project
    try:
        autogen.generate("", "x")
        check("缺 project 应报错", False, True)
    except files.FsError as exc:
        check("缺 project 被拦", "缺少 project" in str(exc), True)

    # 工程不存在
    try:
        autogen.generate("不存在的工程XYZ", "x")
        check("工程不存在应报错", False, True)
    except files.FsError as exc:
        check("工程不存在被拦", "不存在" in str(exc), True)

    # 任务为空
    files.ensure_manual_project()
    try:
        autogen.generate(files.MANUAL_PROJECT, "  ")
        check("空任务应报错", False, True)
    except files.FsError as exc:
        check("空任务被拦", "请说明" in str(exc), True)


def test_frontend_alignment():
    show("五、行号对齐的两个修复点（源码级检查）")
    hl = Path(__file__).resolve().parents[2] / "frontend" / "js" / "highlight.js"
    css = Path(__file__).resolve().parents[2] / "frontend" / "style.css"
    h = hl.read_text(encoding="utf-8")
    c = css.read_text(encoding="utf-8")

    check("高亮层不再用 join(\"\\n\") 连接行", 'out.join("\\n")' not in h, True)
    check("高亮层用空串连接", 'out.join("")' in h, True)
    check("每行用 div 而非行内 span", '<div class="cl">' in h, True)
    check("CSS 不再给 .cl 设 min-height", "min-height: calc(1em" not in c, True)
    check("行高是具体像素", "--code-line-h: 21px" in c, True)
    check("两层共用同一选择器块", ".code-layer, .code-input {" in c, True)


def main():
    test_parse()
    test_generate_dry_run()
    test_context_summary()
    test_generate_guards()
    test_frontend_alignment()
    print()
    if FAILS:
        print(f"失败 {len(FAILS)} 项：" + "；".join(FAILS))
        sys.exit(1)
    print("全部通过。")


if __name__ == "__main__":
    main()
