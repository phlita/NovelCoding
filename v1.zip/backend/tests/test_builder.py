# -*- coding: utf-8 -*-
"""构建器测试：表达式求值 + 确定性内核 + 组装/风格化 + 门禁 + 可复现。"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import builder, files  # noqa: E402
from app.kernel import Decision, Event, Evaluator, Kernel, State  # noqa: E402
import seed_demo_project  # noqa: E402

FAILS: list[str] = []


def check(label, got, want=None, *, truthy=False):
    ok = bool(got) if truthy else (got == want)
    msg = "  ✔ " + label
    if not ok:
        msg = "  ✘ " + label + f"   期望 {want!r}，实际 {got!r}"
        FAILS.append(label)
    print(msg)


def show(title):
    print()
    print("=" * 62)
    print(title)
    print("=" * 62)


# --------------------------------------------------------------------------- #
def test_evaluator():
    show("一、表达式求值")
    st = State(变量={"字据在手": 1, "人情债": 2}, 人物状态={"李三": {"胆量": 4, "戒备": 0}},
               关系={"李三-赵爷": {"信任": 2, "亏欠": 1}})
    st.知识["李三"] = {"赵爷认字据比平常久"}
    ev = Evaluator(get_v=st.get_v, get_s=st.get_s, get_r=st.get_r, knows=st.knows)
    check("数值比较 v.字据在手==1", ev.eval("v.字据在手==1"), True)
    check("关系比较 r.李三-赵爷.信任 >= 2（带连字符）", ev.eval("r.李三-赵爷.信任 >= 2"), True)
    check("人物状态 s.李三.胆量 >= 4", ev.eval("s.李三.胆量 >= 4"), True)
    check("且/或 组合", ev.eval("s.李三.胆量 >= 4 且 r.李三-赵爷.信任 >= 3 或 v.人情债==2"), True)
    check("非", ev.eval("非 v.字据在手==0"), True)
    check("算术 2*3+1", ev.eval("2*3+1"), 7)
    check("括号 (2+3)*2", ev.eval("(2+3)*2"), 10)
    check("知(李三, 赵爷认字据)", ev.eval("知(李三, 赵爷认字据)"), True)
    check("未定义变量按 0 且记警告", ev.eval("v.没这个 >= 1"), False)
    check("未定义变量产生警告", len(ev.warnings) >= 1, truthy=True)


def test_kernel():
    show("二、内核：效果 / 揭示 / 分支")
    st = State(变量={"字据在手": 1}, 人物状态={"赵爷": {"戒备": 0}, "李三": {"胆量": 4}},
               关系={"李三-赵爷": {"信任": 2}})
    k = Kernel(st, known_persons={"李三", "赵爷"}, known_places={"当铺"})
    trace = []
    ok = k.run_event(Event(名="试探", 前置="v.字据在手==1", 出场=["李三", "赵爷"], 地点="当铺",
                          效果=["s.赵爷.戒备 += 2", "v.字据在手 = 0"],
                          揭示=["李三：赵爷认得慢"]), "第01章", trace)
    check("事件执行成功", ok, True)
    check("效果累积 s.赵爷.戒备", st.人物状态["赵爷"]["戒备"], 2)
    check("效果赋值 v.字据在手", st.变量["字据在手"], 0)
    check("揭示进知识账本", st.knows("李三", "赵爷认得慢"), True)
    check("轨迹含 发生/效果/揭示", len([t for t in trace if t["类型"] in ("发生", "效果", "揭示")]), 4)

    trace2 = []
    ok2 = k.run_event(Event(名="试探", 前置="v.字据在手==1"), "第02章", trace2)
    check("前置不成立 → 返回 False", ok2, False)
    check("前置不成立 → 轨迹记「跳过」", trace2[0]["类型"], "跳过")

    dc = Decision(名="查账", 问题="问不问？",
                  选项=[{"名": "直接问", "条件": "r.李三-赵爷.信任 >= 3", "去向": "摊牌"},
                        {"名": "忍着不问", "条件": "s.李三.胆量 >= 1", "去向": "忍着"}],
                  默认="忍着")
    trace3 = []
    nxt = k.run_decision(dc, "第01章", trace3)
    check("按顺序取第一个成立的选项", trace3[0]["选中"], "忍着不问")
    check("决策返回去向", nxt, "忍着")


def test_build_demo():
    show("三、构建示范工程「当铺」")
    seed_demo_project.main()
    report = builder.build("当铺", log=lambda t: print("  ·", t))

    st = report["统计"]
    check("章节数", st["章节数"], 2)
    check("有错误", st["错误"], 0)
    check("状态变化条数 ≥ 5", st["状态变化"] >= 5, truthy=True)
    check("有分支决策", st["分支"] >= 1, truthy=True)
    check("有知识揭示", st["揭示"] >= 2, truthy=True)

    ch1 = report["章节"][0]
    check("第01章标题", ch1["标题"], "第一章 字据")
    check("第01章未被拦截", ch1["已拦截"], False)
    eff = {(t["目标"], t["后"]) for t in ch1["状态变化"]}
    check("赵爷戒备 0→2", ("s.赵爷.戒备", 2) in eff, True)
    check("字据在手 1→0", ("v.字据在手", 0) in eff, True)
    check("亏欠 1→2（关系字段写回）", ("r.李三-赵爷.亏欠", 2) in eff, True)
    check("分支选中「忍着不问」", ch1["分支"][0]["选中"], "忍着不问")
    check("揭示「赵爷认这张纸比平常久」", any("比平常久" in t["事实"] for t in ch1["揭示"]), True)

    ch2 = report["章节"][1]
    check("第02章 摊牌 因前置不成立被跳过", any("不成立" in (w.get("说明") or "") for w in ch2["警告"]), True)

    state = json.loads((files.PROJECTS / "当铺" / "state" / "运行时状态.json").read_text(encoding="utf-8"))
    check("终态：v.字据在手", state["变量"]["字据在手"], 0)
    check("终态：s.赵爷.戒备", state["人物状态"]["赵爷"]["戒备"], 2)
    check("终态：人情债（试探+忍着不问）", state["变量"]["人情债"], 2)
    check("终态：知识账本含两条", len(state["知识"]["李三"]) >= 2, truthy=True)
    check("终态：已发生含两事件", len(state["已发生"]) >= 2, truthy=True)

    txt = (files.PROJECTS / "当铺" / "build" / "第01章.txt").read_text(encoding="utf-8")
    check("正文首行是章节标题", txt.splitlines()[0], "第一章 字据")
    check("正文保留了原文句子", "招牌旧，风一吹就响" in txt, True)
    check("正文里的对白带引号", "「掌柜的在吗？」" in txt, True)
    check("正文里没有系统词", ("戒备" not in txt and "变量" not in txt), True)
    print("  --- 第01章正文 ---")
    print("\n".join("    " + l for l in txt.splitlines()[:14]))

    trace_md = (files.PROJECTS / "当铺" / "build" / "执行轨迹.md").read_text(encoding="utf-8")
    check("轨迹文件写出来了", "## 终态" in trace_md, True)

    # 可复现
    report2 = builder.build("当铺")
    txt2 = (files.PROJECTS / "当铺" / "build" / "第01章.txt").read_text(encoding="utf-8")
    check("两次构建字节一致（确定性）", txt2 == txt, True)
    check("两次构建统计一致", report2["统计"] == report["统计"], True)


def test_style():
    show("四、机械风格化")
    style = builder.parse_style({"字段": {"句长": "平均 12 字", "禁用词": "心头一紧 不易察觉",
                                          "对话占比": "40%~55%"}})
    check("句长解析", style["句长"], 12)
    check("长句阈值 = 句长×1.8（不低于 24）", style["长句阈值"], 24)
    check("禁用词解析", style["禁用词"], ["心头一紧", "不易察觉"])
    long_para = "他把柜台上的灰擦了第三遍才听见门帘响，进来的那个人穿着一件洗得发白的青布长衫，袖口已经磨出了毛边，手里还捏着一张叠得整整齐齐的纸。"
    got = builder.style_apply([long_para + "他心头一紧。"], style)
    check("超长句被断句", len(got["改动"]) >= 1, truthy=True)
    check("禁用词被记入体检", got["禁用词命中"], {"心头一紧": 1})
    check("断句不改字（只加句号）",
          "".join(got["段落"]).replace("。", "") == (long_para + "他心头一紧").replace("，", "").replace("。", ""),
          True)


def test_gate():
    show("五、门禁：严格模式拦下错误（引用不存在的条目）")
    p = "构建自检"
    if (files.PROJECTS / p).exists():
        files.delete_project(p)
    files.create_project(p, "自检", "", "")
    files.write_file("project", p, "第01章.剧本.正文",
                     "@条目 第01章\n@章 第一章\n@事件 不存在的事件\n\n> 正文。\n")
    soft = builder.build(p)
    check("宽松模式：记录错误但照出正文", soft["统计"]["错误"], 1)
    check("宽松模式：门禁=有问题未拦截", soft["门禁"]["结果"], "有问题未拦截")
    hard = builder.build(p, strict=True)
    check("严格模式：门禁=拦截", hard["门禁"]["结果"], "拦截")
    check("严格模式：不产出正文文件", hard["章节"][0]["文件"], "")
    files.delete_project(p)


def test_conservation():
    show("六、逻辑守恒检查")
    trace = [{"类型": "效果", "事件": "试探", "目标": "s.赵爷.戒备", "前": 0, "后": 2},
             {"类型": "揭示", "事件": "试探", "人物": "李三", "事实": "赵爷认得很慢"},
             {"类型": "效果", "事件": "试探", "目标": "v.人情债", "前": 1, "后": 1}]
    issues = builder.conservation_check("那人把纸放好。", trace, [], strict_facts=False)
    check("改了赵爷状态但正文没他 → 报出", any("赵爷" in i for i in issues), True)
    check("李三学到信息但正文没他 → 报出", any("学到了" in i for i in issues), True)
    check("无效效果（前后没变）→ 报出", any("没变" in i for i in issues), True)
    clean = builder.conservation_check(
        "李三把纸放好。赵爷看了一眼，也把纸收了。",
        [{"类型": "效果", "事件": "试探", "目标": "s.赵爷.戒备", "前": 0, "后": 2}], [])
    check("人都在正文里 → 不报", clean, [])
    facts = builder.conservation_check(
        "李三把纸放好。",
        [{"类型": "揭示", "事件": "试探", "人物": "李三", "事实": "赵爷认得很慢"}], [], strict_facts=True)
    check("模型模式才查事实落点", any("找不到落点" in i for i in facts), True)


def test_model_fallback():
    show("七、模型翻译（当前引擎为内置演示 → 应优雅回退，不崩）")
    report = builder.build("当铺", mode="model")
    ch1 = report["章节"][0]
    check("模式标为模型翻译", report["模式"], "模型翻译")
    check("没有异常错误", report["统计"]["错误"], 0)
    check("渲染说明记录了回退原因", bool(ch1["渲染说明"]), truthy=True)
    check("正文仍按骨架输出", "招牌旧，风一吹就响" in ch1["正文"], True)
    print("    渲染说明：", ch1["渲染说明"])


def main():
    test_evaluator()
    test_kernel()
    test_build_demo()
    test_style()
    test_gate()
    test_conservation()
    test_model_fallback()
    print()
    if FAILS:
        print(f"失败 {len(FAILS)} 项：" + "；".join(FAILS))
        sys.exit(1)
    print("全部通过。")


if __name__ == "__main__":
    main()
