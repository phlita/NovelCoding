# -*- coding: utf-8 -*-
"""拆解器测试：规则模式全流程 + 模型 JSON 归一化（用假 JSON，不需真模型）。"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import decompose, files  # noqa: E402

SAMPLE = files.ROOT / "samples" / "示例小说-当铺.txt"
PROJECT = "拆解自检"


def clean():
    d = files.PROJECTS / PROJECT
    if d.exists():
        files.delete_project(PROJECT)


def show(title):
    print()
    print("=" * 60)
    print(title)
    print("=" * 60)


def main():
    clean()
    text = SAMPLE.read_text(encoding="utf-8")

    show("一、分章预览")
    p = decompose.preview(text)
    print("判定:", p["章节判定"], "| 统计:", p["统计"])
    for c in p["章节"]:
        print(f"  {c['编号']} {c['标题']}  {c['字数']}字  开头：{c['开头'][:20]}")

    show("二、规则模式（无模型）全流程")
    report = decompose.run(PROJECT, text, mode="rules", log=lambda t: print("  ·", t))
    print()
    print("引擎分布:", report["引擎分布"])
    print("生成条目:", len(report["条目"]))
    for item in report["条目"]:
        print(f"  {item['文件']:<26} {item['置信度']}")

    show("三、落盘内容抽样")
    for name in ("第01章.剧本.正文", "李三.人物.属性", "李三.人物.口癖", "赵爷.人物.属性",
                 "原文风格.文风.样式", f"{PROJECT}.时间线.节点"):
        f = files.read_file("project", PROJECT, name)
        print()
        print(f"--- {name} ({f['大类']}.{f['子类']}, 依赖 {len(f['依赖'])}) ---")
        print(f["content"].strip()[:700])

    show("四、关系网与地点")
    rels = [f["name"] for f in files.project_summary(PROJECT)["files"] if f["大类"] == "关系"]
    locs = [f["name"] for f in files.project_summary(PROJECT)["files"] if f["大类"] == "地点"]
    print("关系:", rels)
    print("地点:", locs)
    if rels:
        print()
        print(files.read_file("project", PROJECT, rels[0])["content"])

    show("五、模型 JSON 归一化（假 JSON，验证合并代码路径）")
    fake = {
        "人物": [{"名": "李三", "身份": "当铺伙计", "年龄": "23", "缺陷": "见血就晕",
                  "口癖": "「您……」", "证据": ["李三把柜台上的灰擦了第三遍"]}],
        "事件": [{"名": "认据", "前置": "三爷持有字据", "出场": ["赵爷", "三爷"],
                  "地点": "当铺", "步骤": ["赵爷接过字据对光查看"],
                  "效果": ["赵爷.戒备 +2"], "揭示": ["李三：字据是真的"], "钩子": "门外有人"}],
        "变量": [{"名": "戒备", "类型": "数值", "初值": "0", "量纲": "0~10", "说明": "人物戒备"}],
        "决策": [{"名": "信任评估", "问题": "要不要把东西还回去", "选项": ["还｜信任≥3｜还物"]}],
        "行为": [{"名": "摸袖口", "归属": ["三爷"], "触发条件": "被追问", "表现": "手指捻袖口内衬"}],
        "关系": [{"甲": "李三", "乙": "赵爷", "信任": "3", "亏欠": "0", "来源事件": "共扛后巷火事"}],
        "剧本": {"导演": "先给柜台，再给人脸", "镜头": ["特写：字据边缘的毛边"]},
    }
    ch = decompose.split_chapters(text)[0]
    n = decompose._normalize_ai(fake, ch)
    print("引擎:", n["引擎"])
    print("人物:", {k: v["属性"] for k, v in n["人物"].items()})
    print("事件:", [(e["名"], e["效果"], e["揭示"]) for e in n["事件"]])
    print("变量:", n["变量"], "决策:", list(n["决策"]), "行为:", list(n["行为"]))
    print("关系:", n["关系"])
    print("剧本导演:", n["剧本"]["导演"], "| 镜头:", n["剧本"]["镜头"], "| 分镜条数:", len(n["剧本"]["分镜"]))
    assert n["剧本"]["分镜"], "分镜应来自确定性切分（保留原文）"
    assert n["变量"]["戒备"]["类型"] == "数值"

    show("六、模型模式跑一遍（mock 引擎应自动走规则并标注）")
    clean()
    report2 = decompose.run(PROJECT, text, mode="model", max_chapters=1,
                            log=lambda t: None)
    print("引擎分布:", report2["引擎分布"])

    show("七、异常路径")
    try:
        decompose.run(PROJECT, text)
    except files.FsError as exc:
        print("重名工程被拒:", exc.detail)

    clean()
    print()
    print("全部通过。")


if __name__ == "__main__":
    main()
