# -*- coding: utf-8 -*-
"""AI 交互细节：排队识别 / 思考内容处理 / 回复落地 的测试。不联网。"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import files  # noqa: E402

FAILS: list[str] = []
TMP = "落地测试"


def check(label, got, want=None, *, truthy=False):
    ok = bool(got) if truthy else (got == want)
    msg = "  ✔ " + label
    if not ok:
        msg = "  ✘ " + label + f"   期望 {want!r}，实际 {got!r}"
        FAILS.append(label)
    print(msg)


def show(title):
    print()
    print("=" * 62)
    print(title)
    print("=" * 62)


ROOT = Path(__file__).resolve().parents[2]


def test_queue_detection():
    show("一、Trae 排队提示必须被识别（不是「空回复」）")
    src = (ROOT / "backend" / "app" / "trae.py").read_text(encoding="utf-8")
    check("识别 position 字段", '"position"' in src or "doc.get(\"position\")" in src)
    check("识别 Too many current requests", "Too many current requests" in src)
    check("排队单独报错（不再说空回复）", "正在排队" in src)
    check("提示可换模型", "换一个模型" in src)
    check("state 里有 queue 字段", '"queue": None' in src)


def test_reasoning_not_answer():
    show("二、思考内容不得顶替正文")
    cb = (ROOT / "backend" / "app" / "codebuddy.py").read_text(encoding="utf-8")
    tr = (ROOT / "backend" / "app" / "trae.py").read_text(encoding="utf-8")

    # 老写法 state["content"] or state["reasoning"] 必须消失
    check("CodeBuddy 不再用 reasoning 兜底",
          'state["content"] or state["reasoning"]' not in cb)
    check("Trae 不再用 reasoning 兜底",
          'state["text"] or state["reasoning"]' not in tr)
    check("CodeBuddy 只拿 content", 'text = state["content"]' in cb)
    check("Trae 只拿 text", 'text = state["text"]' in tr)
    check("只有思考时给出专门提示",
          "只输出了思考内容" in cb and "只输出了思考内容" in tr)
    check("提示里带上思考开头，便于排查", "思考开头" in cb and "思考开头" in tr)


def test_token_budget():
    show("三、对话给足 token 预算")
    routes = (ROOT / "backend" / "app" / "routes.py").read_text(encoding="utf-8")
    check("非流式默认 8192", 'b.get("max_tokens") or 8192' in routes)
    check("流式也传 max_tokens", 'max_tokens = int(b.get("max_tokens") or 8192)' in routes)
    check("流式把 max_tokens 传下去", "llm.stream(messages, max_tokens=max_tokens)" in routes)
    check("错误里带 retry 标志", '"retry": retry' in routes)


def test_apply_endpoint():
    show("四、回复落地接口")
    routes = (ROOT / "backend" / "app" / "routes.py").read_text(encoding="utf-8")
    check("有 /api/ai/apply", '"/api/ai/apply"' in routes)
    check("支持 target 整体写入", 'target = str(b.get("target")' in routes)
    check("校验目标文件名", "目标文件名不合法" in routes)
    check("默认不覆盖", "已存在（未开启覆盖）" in routes)

    # 实际跑一遍：多条目 + 指定目标
    import importlib

    routes_mod = importlib.import_module("app.routes")
    import app.files as F

    if (F.PROJECTS / TMP).exists():
        F.delete_project(TMP)
    F.create_project(TMP, "测试", "", "")

    class Ctx:
        def __init__(self, payload):
            self.json = payload
            self.query = {}
            self.params = {}

    reply = """```
文件名：李三.人物.属性
身份 伙计
```
```
文件名：当铺.地点.属性
氛围 木头味
```
"""
    r = routes_mod.ai_apply(Ctx({"project": TMP, "text": reply}))
    check("解析并写入 2 个", len(r["写入"]), 2)
    root = F.scope_root("project", TMP)
    check("文件真的落盘", (root / "李三.人物.属性").is_file(), True)
    check("内容正确", "身份 伙计" in (root / "李三.人物.属性").read_text(encoding="utf-8"), True)

    # 再来一次：默认不覆盖
    r2 = routes_mod.ai_apply(Ctx({"project": TMP, "text": reply}))
    check("第二次全部跳过", len(r2["写入"]), 0)
    check("跳过原因是不覆盖", "未开启覆盖" in r2["跳过"][0]["原因"], True)

    # 指定 target：整体覆盖写入
    r3 = routes_mod.ai_apply(Ctx({"project": TMP, "text": "全新内容\n第二行",
                                  "target": "李三.人物.状态", "overwrite": True}))
    check("target 模式写入 1 个", len(r3["写入"]), 1)
    got = (root / "李三.人物.状态").read_text(encoding="utf-8")
    check("整体替换成功", got.strip() == "全新内容\n第二行", True)

    F.delete_project(TMP)


def test_frontend():
    show("五、前端接线")
    js = (ROOT / "frontend" / "app.js").read_text(encoding="utf-8")
    html = (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")
    css = (ROOT / "frontend" / "style.css").read_text(encoding="utf-8")

    check("有 applyReply", "const applyReply" in js)
    check("有 retryLast", "const retryLast" in js)
    check("withFile 已导出（模板要用）", "withFile," in js)
    check("当前文件放 user 消息而非 system", "【当前文件】${cur.value.name}" in js)
    check("错误单独存字段", 'error: "", retry: false' in js)
    check("模板显示错误块", 'class="msg-err"' in html)
    check("有重试按钮", '@click="retryLast"' in html)
    check("有「写入条目」按钮", 'applyReply(m.content)' in html)
    check("有 .msg-err 样式", ".msg-err" in css)


def main():
    test_queue_detection()
    test_reasoning_not_answer()
    test_token_budget()
    test_apply_endpoint()
    test_frontend()
    print()
    if FAILS:
        print(f"失败 {len(FAILS)} 项：" + "；".join(FAILS))
        sys.exit(1)
    print("全部通过。")


if __name__ == "__main__":
    main()
