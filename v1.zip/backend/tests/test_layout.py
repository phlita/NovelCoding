# -*- coding: utf-8 -*-
"""布局：面板高度 / 折叠 / 宽度 的持久化测试（纯逻辑，不依赖浏览器）。

layout.js 是浏览器端脚本，这里用最小 JS 运行时（node）无法保证，
所以改用「源码级 + 逻辑一致性」检查：确认三件事
  1. 数据模型里有 heights / collapsed；
  2. normalize 会夹取高度、过滤非法值；
  3. 前端确实把 panelStyle / toggleCollapse / startResizeH 接了上去。
这比假装跑一遍浏览器更诚实。
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FAILS: list[str] = []


def check(label, ok, detail=""):
    msg = "  ✔ " + label
    if not ok:
        msg = "  ✘ " + label + (f"   [{detail}]" if detail else "")
        FAILS.append(label)
    print(msg)


def show(title):
    print()
    print("=" * 62)
    print(title)
    print("=" * 62)


def read(p: Path) -> str:
    return p.read_text(encoding="utf-8")


def main():
    layout = read(ROOT / "frontend" / "js" / "layout.js")
    css = read(ROOT / "frontend" / "style.css")
    js = read(ROOT / "frontend" / "app.js")
    html = read(ROOT / "frontend" / "index.html")
    icons = read(ROOT / "frontend" / "js" / "icons.js")

    show("一、layout.js：高度与折叠的数据模型")
    check("DEFAULTS 里有 heights", "heights:" in layout)
    check("DEFAULTS 里有 collapsed", "collapsed:" in layout)
    check("左栏三个面板都有高度项", layout.count('"left.') >= 3)
    check("有 clampH 夹取", "function clampH" in layout)
    check("有 setHeight", "function setHeight" in layout)
    check("有 setCollapsed", "function setCollapsed" in layout)
    check("normalize 处理 heights", "raw.heights" in layout)
    check("normalize 处理 collapsed", "raw.collapsed" in layout)
    check("导出里含 setHeight / setCollapsed",
          "setHeight, setCollapsed" in layout)

    show("二、app.js：接线")
    check("layout 状态含 heights", "heights: {}" in js)
    check("layout 状态含 collapsed", "collapsed: {}" in js)
    check("有 panelStyle", "const panelStyle" in js)
    check("有 isCollapsed", "const isCollapsed" in js)
    check("有 toggleCollapse", "const toggleCollapse" in js)
    check("有 startResizeH", "const startResizeH" in js)
    check("折叠时 flex 收成 0 0 auto", '"0 0 auto"' in js)
    check("展开时按 px 固定", 'flex: `0 0 ${h}px`' in js)
    check("resetLayout 会重置高度与折叠",
          "Object.assign(layout.heights" in js and "Object.assign(layout.collapsed" in js)
    check("导出 panelStyle / toggleCollapse / startResizeH",
          "panelStyle, isCollapsed, toggleCollapse, startResizeH" in js)

    show("三、index.html：三个面板都有折叠按钮与拖动条")
    check("本项目有折叠按钮", html.count('toggleCollapse(pid)') >= 4)
    check("有垂直拖动条", 'class="hsplitter"' in html)
    check("本项目后有条", "startResizeH('left.tree'" in html)
    check("构建产物后有条", "startResizeH('left.build'" in html)
    check("对话后有条", "startResizeH('right.chat'" in html)
    check("不再有写死的 max-height:26vh", "max-height:26vh" not in html)
    check("不再两个 panel grow 争抢", html.count('class="panel grow"') == 0)

    show("四、style.css：折叠与拖动条")
    check("有 .panel.collapsed", ".panel.collapsed" in css)
    check("折叠时隐藏非标题内容", ".panel.collapsed > *:not(.panel-head)" in css)
    check("有 .hsplitter", ".hsplitter" in css)
    check("有 resizing-h 光标态", "body.resizing-h" in css)
    check("标题栏不被压缩", "flex: none" in css)
    check("面板 overflow hidden", "overflow: hidden" in css)

    show("五、图标：Lucide + CDN + 主题适配")
    check("用 Lucide CDN", "lucide-static" in icons)
    check("通过 jsDelivr", "cdn.jsdelivr.net" in icons)
    check("用 mask 而非 img（否则暗色主题下图标不可见）",
          "--ico:url(" in icons and "ico-mask" in icons)
    check("有离线兜底字形", "no-icon-cdn" in icons and "data-g" in icons)
    check("CSS 有 mask 规则", "mask-image: var(--ico)" in css)
    check("离线时改用字形", "html.no-icon-cdn .ico-mask::after" in css)
    check("图标颜色跟随 currentColor", "background-color: currentColor" in css)
    check("大类都有对应图标", icons.count('": "') >= 13)

    print()
    if FAILS:
        print(f"失败 {len(FAILS)} 项：" + "；".join(FAILS))
        sys.exit(1)
    print("全部通过。")


if __name__ == "__main__":
    main()
