# -*- coding: utf-8 -*-
"""AI 接入 / 手动模式 / 默认工程 的测试。

不联网、不读真实编辑器登录：只验证「结构与判定」是否正确。
真正的登录探测要在你本机跑（设置 → 扫描本机登录）。
"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import config, files, llm  # noqa: E402

FAILS: list[str] = []


def check(label, got, want=None, *, truthy=False):
    ok = bool(got) if truthy else (got == want)
    msg = "  ✔ " + label
    if not ok:
        msg = "  ✘ " + label + f"   期望 {want!r}，实际 {got!r}"
        FAILS.append(label)
    print(msg)


def show(title):
    print()
    print("=" * 62)
    print(title)
    print("=" * 62)


# --------------------------------------------------------------------------- #
def test_manual_is_normal():
    show("一、手动模式不是错误状态")
    backup = config.load()
    try:
        config.save({"llm_provider": "manual"})
        info = config.resolve()
        check("api_style 标为 mock（不调用模型）", info["api_style"], "mock")
        check("手动模式算「已配置」", info["configured"], True)
        check("is_manual() 为真", llm.is_manual(), True)
        cap = llm.can_chat()
        check("can_chat().ok 为假", cap["ok"], False)
        check("给出了人话原因", bool(cap["reason"]), truthy=True)
        check("原因提到「不影响」", "不影响" in cap["reason"], True)

        reply = llm.chat([{"role": "user", "content": "你好"}])
        check("手动模式仍能返回说明（不抛异常）", "手动编辑模式" in reply, True)
        check("说明里提到构建可用", "构建" in reply, True)
    finally:
        config.save({"llm_provider": backup.get("llm_provider") or "manual"})


def test_providers():
    show("二、通路清单与免 Key 判定")
    ids = [p["id"] for p in config.public_providers()]
    check("有手动模式", "manual" in ids, True)
    check("有 CodeBuddy", "codebuddy" in ids, True)
    check("有 Trae", "trae" in ids, True)
    check("有 OpenAI 兼容", "deepseek" in ids, True)
    check("手动模式排第一（默认）", ids[0], "manual")

    backup = config.load()
    try:
        for pid, style in (("codebuddy", "codebuddy"), ("trae", "trae")):
            config.save({"llm_provider": pid})
            info = config.resolve()
            check(f"{pid} 的 api_style", info["api_style"], style)
            check(f"{pid} 不需要 Key 也算已配置", info["configured"], True)

        config.save({"llm_provider": "deepseek"})
        info = config.resolve()
        check("deepseek 没 Key → 未配置", info["configured"], False)
        cap = llm.can_chat()
        check("未填 Key 时 can_chat 为假", cap["ok"], False)
        check("提示里说要填 Key", "API Key" in cap["reason"], True)
    finally:
        config.save({"llm_provider": backup.get("llm_provider") or "manual"})


def test_manual_project():
    show("三、默认工程（手动模式自带）")
    existed = (files.PROJECTS / files.MANUAL_PROJECT).exists()
    if not existed:
        created = files.ensure_manual_project()
        check("首次启动创建了工程", created, files.MANUAL_PROJECT)
    else:
        check("工程已存在（幂等，不重报）", files.ensure_manual_project(), None)

    root = files.scope_root("project", files.MANUAL_PROJECT)
    names = {p.name for p in root.glob("*") if p.is_file()}
    check("有工程清单", f"{files.MANUAL_PROJECT}.工程.清单" in names, True)
    check("有人物属性", "李三.人物.属性" in names, True)
    check("有事件逻辑", "试探.事件.逻辑" in names, True)
    check("有决策分支", "查账.决策.分支" in names, True)
    check("有章节剧本", "第01章.剧本.正文" in names, True)
    check("有文风样式", "冷硬语气.文风.样式" in names, True)

    # 这个工程必须真的能构建（手动模式的卖点：不接 AI 也能出正文）
    from app import builder

    report = builder.build(files.MANUAL_PROJECT)
    st = report["统计"]
    check("能构建出章节", st["章节数"], 1)
    check("没有错误", st["错误"], 0)
    check("有状态变化", st["状态变化"] >= 2, truthy=True)
    check("有分支", st["分支"] >= 1, truthy=True)
    txt = (files.scope_root("build", files.MANUAL_PROJECT) / "第01章.txt")
    check("正文文件已生成", txt.is_file(), True)
    if txt.is_file():
        body = txt.read_text(encoding="utf-8")
        check("正文里有对白", "「" in body, True)


def test_settings_defaults():
    show("四、设置项默认值")
    cfg = config.load()
    check("温度有默认值", isinstance(cfg.get("temperature"), (int, float)), True)
    check("带有 codebuddy_db_path 字段", "codebuddy_db_path" in cfg, True)
    check("带有 trae_db_path 字段", "trae_db_path" in cfg, True)


def test_status_redacted():
    show("五、状态摘要必须脱敏（不把账号显示到页面）")
    from app import codebuddy, trae

    cb = codebuddy.status()
    tr = trae.status()
    for name, st in (("codebuddy", cb), ("trae", tr)):
        acc = st.get("account") or ""
        uid = st.get("uid") or ""
        check(f"{name}：account 不含真实账号", acc in ("", "***"), True)
        check(f"{name}：uid 不含真实账号", uid in ("", "***"), True)
        check(f"{name}：token 不含令牌字符", st.get("token") in ("", "***", "(空)"), True)


def test_choosable():
    show("六、模型切换清单")
    backup = config.load()
    try:
        config.save({"llm_provider": "manual"})
        r = config.resolve()
        check("手动模式 api_style", r["api_style"], "mock")

        # openai 类：有预设模型列表
        config.save({"llm_provider": "deepseek"})
        p = config.preset("deepseek")
        check("deepseek 有可选模型", len(p.get("models") or []) >= 1, True)
        check("当前生效模型回落到默认", config.resolve()["model"], p["default_model"])

        # 切换模型后 resolve 必须跟着变
        config.save({"llm_models": {"deepseek": "deepseek-reasoner"}})
        check("切换后的模型生效", config.resolve()["model"], "deepseek-reasoner")
        config.save({"llm_models": {"deepseek": None}})
    finally:
        config.save({"llm_provider": backup.get("llm_provider") or "manual"})


def test_localai_independent():
    show("七、本机接入是可选模块（删掉不影响其它功能）")
    from app import localai

    check("模块可用", localai.available(), True)
    check("有 codebuddy 通路", "codebuddy" in localai.provider_ids(), True)
    check("有 trae 通路", "trae" in localai.provider_ids(), True)

    # 直接验证「模块加载失败时的行为」：把 _mod 换成永远返回 None 的桩
    real_mod = localai._mod
    localai._mod = lambda name: None
    try:
        check("加载不到通路时 available() 为假", localai.available(), False)
        check("加载不到通路时列表为空", localai.provider_ids(), [])
        r = localai.probe("codebuddy")
        check("probe 不抛异常", r.get("ok"), False)
        check("给出可读说明", "不可用" in (r.get("issue") or ""), True)
        m = localai.models("trae")
        check("models 不抛异常", m.get("models"), [])
        st = localai.status()
        check("status 标为不可用", st.get("available"), False)
        check("status 给了说明", bool(st.get("issue")), truthy=True)
        try:
            localai.chat("codebuddy", [{"role": "user", "content": "x"}])
            check("chat 应报错", False, True)
        except RuntimeError as exc:
            check("chat 报可读错误", "不可用" in str(exc), True)
    finally:
        localai._mod = real_mod

    check("恢复后 available() 为真", localai.available(), True)
    check("恢复后能列出通路", len(localai.provider_ids()) >= 1, True)


def test_trae_sse_parse():
    show("八、Trae 的 SSE 解析（具名事件）")
    from app import trae

    # 真实名册结构：function_configs → 找 chat_v3 → config_info_list
    payload = {
        "function_configs": [
            {"function": "code_completion", "config_info_list": [
                {"config_name": "comp", "usage": "code_completion",
                 "display_config": {"display_name": "补全"}}]},
            {"function": "chat_v3", "config_info_list": [
                {"config_name": "abc", "usage": "chat_completion",
                 "display_config": {"display_name": "模型甲", "tags": ["fast"],
                                    "model_capability": "reasoning_model"},
                 "model_detail_list": [{"max_tokens": 8000}]},
                {"config_name": "xyz", "usage": "chat_completion",
                 "display_config": {"display_name": "模型乙"}},
                {"config_name": "abc", "usage": "chat_completion",
                 "display_config": {"display_name": "重复"}},
                {"config_name": "summ", "usage": "summary",
                 "display_config": {"display_name": "摘要"}},
            ]},
        ]}
    got = trae.parse_models(payload)
    ids = [m["id"] for m in got]
    check("只取 chat_v3 组里的 chat_completion", ids, ["abc", "xyz"])
    check("用 display_config.display_name 当标签", got[0]["label"], "模型甲")
    check("重复 config_name 去重", len(got), 2)
    check("reasoning 标进 note", "reasoning" in (got[0]["note"] or ""), True)
    check("max_tokens 读出来", got[0]["max"], 8000)

    check("顶层键猜错时返回空（旧写法）",
          trae.parse_models({"model_config_list": [{"config_name": "a"}]}), [])
    check("坏输入返回空", trae.parse_models("not json"), [])
    check("空 payload", trae.parse_models({}), [])
    check("没有 chat_v3 组时返回空",
          trae.parse_models({"function_configs": [{"function": "x", "config_info_list": []}]}), [])

    # 确认 flush 里不再引用局部 event（源码级检查）
    src = Path(trae.__file__).read_text(encoding="utf-8")
    check("flush 里不再有裸 event 赋值", "event, data_lines[:]" not in src, True)
    check("空回复会带上诊断", "收到 " in src, True)


def main():
    test_manual_is_normal()
    test_providers()
    test_manual_project()
    test_settings_defaults()
    test_status_redacted()
    test_choosable()
    test_localai_independent()
    test_trae_sse_parse()
    print()
    if FAILS:
        print(f"失败 {len(FAILS)} 项：" + "；".join(FAILS))
        sys.exit(1)
    print("全部通过。")


if __name__ == "__main__":
    main()
