"""构建器：条目文件 → 执行 → 正文（build/）。

流程（前三步完全确定性，第四步可选模型）：

    1. 读条目：变量 / 人物状态 / 关系 / 知识 / 事件 / 决策 / 剧本 / 文风
    2. 执行：按章节顺序跑事件与决策（前置→效果→揭示→分支），留下执行轨迹
    3. 组装骨架：有 .剧本.正文 就用分镜（原文级），没有就用事件步骤合成
    4. 风格化：机械断句 + 禁用词体检；模式=模型时改由模型按 .文风.样式 翻译，
       再用"逻辑守恒检查"核对轨迹里的状态变化与揭示是否落进了正文

产物：
    build/第NN章.txt        正文
    build/执行轨迹.md       确定性轨迹（状态怎么变的、谁知道了什么、走了哪条分支）
    build/构建报告.json     门禁、体检、守恒检查
    state/运行时状态.json   终态快照
"""
from __future__ import annotations

import json
import re
from collections import OrderedDict
from pathlib import Path

from app import files, llm, rules
from app.kernel import Decision, Event, Kernel, State, parse_step

RENDER_PROMPT = Path(__file__).resolve().parent / "prompts" / "render_chapter.md"
NOISE_SENT_RE = re.compile(r"^[\s　]+$")


# --------------------------------------------------------------------------- #
# 一、读条目
# --------------------------------------------------------------------------- #
def parse_notes(content: str) -> tuple[dict[str, list[str]], list[str]]:
    """把条目文件拆成 注释区（@键 值）与 正文区（行）。"""
    notes: dict[str, list[str]] = OrderedDict()
    body: list[str] = []
    for line in (content or "").splitlines():
        s = line.strip()
        if s.startswith("@"):
            key, _, val = s[1:].partition(" ")
            notes.setdefault(key.strip(), []).append(val.strip())
        else:
            body.append(line)
    return notes, body


def _kv_lines(body: list[str]) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in body:
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if "=" in s:
            k, _, v = s.partition("=")
            out[k.strip()] = v.strip()
        else:
            k, _, v = s.partition("　")
            if v:
                out[k.strip()] = v.strip()
            else:
                parts = s.split(None, 1)
                out[parts[0]] = parts[1].strip() if len(parts) > 1 else ""
    return out


class Project:
    """一个工程的条目集合（构建的输入）。"""

    def __init__(self, name: str):
        self.name = name
        self.root = files.scope_root("project", name)
        if not self.root.exists():
            raise files.FsError(f"工程不存在：{name}", 404)
        self.变量: dict[str, dict] = OrderedDict()
        self.人物状态: dict[str, dict] = OrderedDict()
        self.关系: dict[str, dict] = OrderedDict()
        self.知识种子: dict[str, list[str]] = OrderedDict()
        self.事件: dict[str, Event] = OrderedDict()
        self.决策: dict[str, Decision] = OrderedDict()
        self.剧本: dict[str, dict] = OrderedDict()      # 章 → {标题, 分镜, 引用}
        self.文风: dict = {}
        self.清单: dict = {}
        self.时间线: list[str] = []
        self.文件: list[str] = []
        self.来源: dict[str, str] = {}          # 文件名 → 项目 / 公共库
        self.待解析依赖: list[tuple[str, list[str]]] = []
        self.从公共库: list[str] = []
        self.缺失依赖: list[str] = []
        self.已加载名: set[str] = set()
        self._lib_idx: dict[str, Path] | None = None
        self._load()

    # ------------------------------------------------------------------ #
    def _load(self):
        # 先把项目自己的条目全部读入，登记"已加载名"
        paths = [p for p in sorted(self.root.rglob("*")) if p.is_file()]
        for path in paths:
            info = files.parse_filename(path.name)
            if info["ok"]:
                self.已加载名.add(info["条目名"])
            self._load_one(path)
        # 再解析 @导入：项目里没有的，去公共库补（项目定义永远优先）
        # 用索引游标而不是 for-in，这样公共库条目带来的新依赖也会被继续解析（可传递）
        i = 0
        while i < len(self.待解析依赖):
            _stem, deps = self.待解析依赖[i]
            i += 1
            self._resolve_imports(deps)
        self.文件 = list(dict.fromkeys(self.文件))

    # ------------------------------------------------------------------ #
    def _library_index(self) -> dict[str, Path]:
        """公共库索引：条目名 + 文件名 → 路径。懒建，解析跨库依赖时用。"""
        if getattr(self, "_lib_idx", None) is None:
            idx: dict[str, Path] = {}
            if files.LIBRARY.exists():
                for p in sorted(files.LIBRARY.rglob("*")):
                    if not p.is_file():
                        continue
                    info = files.parse_filename(p.name)
                    if not info["ok"]:
                        continue
                    idx.setdefault(p.name, p)          # 全名优先
                    idx.setdefault(info["条目名"], p)   # 裸条目名兜底
            self._lib_idx = idx
        return self._lib_idx

    def _resolve_imports(self, deps: list[str]) -> None:
        """跨工程引用：@导入 的条目本项目里没有 → 去公共库取。

        只补缺，不覆盖项目自己的定义（项目永远优先）。
        注意：一个条目可能对应多个文件（.人物.属性 / .人物.知识），所以按「条目名」
        判断是否已加载时，要连同它的全部子类文件一起取，不能只取第一个。
        """
        for raw in deps or []:
            token = raw.strip().split()[0] if raw.strip() else ""
            if not token:
                continue
            name = _strip_ext(token)
            if name in self.已加载名:
                continue
            # 找出这个条目名对应的全部公共库文件（可能多个子类）
            bundle = self._library_bundle(name)
            if not bundle:
                self.缺失依赖.append(raw.strip())
                continue
            for p in bundle:
                if p.name in self.文件:
                    continue
                self._load_one(p)
                self.从公共库.append(p.name)
            self.已加载名.add(name)

    def _library_bundle(self, name: str) -> list[Path]:
        """公共库里与条目名匹配的全部文件（同条目多子类一起返回）。"""
        want = name.split(".")[0] if "." in name else name
        out = []
        for p in self._library_index().values():
            info = files.parse_filename(p.name)
            if info["ok"] and info["条目名"] == want and p not in out:
                out.append(p)
        return out

    def _load_one(self, path: Path):
        info = files.parse_filename(path.name)
        if not info["ok"]:
            return
        cat, sub, stem = info["大类"], info["子类"], info["条目名"]
        text = path.read_text(encoding="utf-8", errors="replace")
        notes, body = parse_notes(text)
        # self.文件 只存「文件名」，因为 persons()/places() 从这里解析条目名。
        self.文件.append(path.name)
        self.来源[path.name] = ("公共库" if files.LIBRARY in path.parents else "项目")
        # 记录依赖，稍后解析
        deps: list[str] = []
        for key in ("导入", "import", "依赖", "引用"):
            deps.extend(notes.get(key, []))
        if deps:
            self.待解析依赖.append((stem, deps))
        if cat == "变量":
            self.变量[stem] = {"类型": _kv_lines(body).get("类型", "数值"),
                               "初值": _kv_lines(body).get("初值", "0"),
                               "说明": _kv_lines(body).get("说明", "")}
        elif cat == "人物" and sub == "状态":
            fields = {}
            for k, v in _kv_lines(body).items():
                if k == stem or v == "":
                    continue
                fields[k] = _num(v)
            self.人物状态[stem] = fields
        elif cat == "关系":
            fields = {}
            for k, v in _kv_lines(body).items():
                # 正文区里常有一行单独的「甲-乙」（关系双方的写法），不是字段，跳过
                if k == stem or v == "":
                    continue
                fields[k] = _num(v)
            self.关系[stem] = fields
        elif cat == "人物" and sub == "知识":
            facts = [l.strip() for l in body if l.strip() and not l.strip().startswith("@")]
            seeds = [f for f in notes.get("知", []) + notes.get("知识", []) if f]
            self.知识种子[stem] = facts + seeds
        elif cat == "事件" and sub == "逻辑":
            self.事件[stem] = Event(
                名=stem,
                前置=(notes.get("前置", [""])[0] or ""),
                出场=[x for v in notes.get("出场", []) for x in v.split()] +
                     [x for v in notes.get("参与", []) for x in v.split()],
                地点=(notes.get("地点", [""])[0] or ""),
                步骤=[x for v in notes.get("步骤", []) for x in v.split("；") if x.strip()],
                效果=[x for v in notes.get("效果", []) for x in v.split("；") if x.strip()],
                揭示=[x for v in notes.get("揭示", []) for x in v.split("；") if x.strip()],
                钩子=(notes.get("钩子", [""])[0] or ""),
                来源=(notes.get("来源", [""])[0] or ""))
        elif cat == "决策":
            opts = []
            for raw in notes.get("选项", []):
                parts = [p.strip() for p in re.split(r"[|｜]", raw)]
                while len(parts) < 3:
                    parts.append("")
                opts.append({"名": parts[0], "条件": parts[1], "去向": parts[2]})
            self.决策[stem] = Decision(名=stem, 问题=(notes.get("问题", [""])[0] or
                                                   (_kv_lines(body).get("问题", ""))),
                                       选项=opts, 默认=(notes.get("默认", [""])[0] or ""))
        elif cat == "剧本" and sub == "正文":
            refs: list[tuple[str, str]] = []
            for key in ("事件", "导入"):
                for v in notes.get(key, []):
                    for name in re.split(r"[\s、,，]+", v):
                        if name:
                            refs.append(("事件", _strip_ext(name)))
            for v in notes.get("决策", []):
                for name in re.split(r"[\s、,，]+", v):
                    if name:
                        refs.append(("决策", _strip_ext(name)))
            章 = _strip_ext((notes.get("章", [""])[0] or "").strip()) or stem
            self.剧本[stem] = {"章": 章, "编号": stem, "注释": notes,
                               "分镜": [l.strip() for l in body if l.strip()],
                               "引用": refs,
                               "导演": (notes.get("导演", [""])[0] or ""),
                               "镜头": notes.get("镜头", [])}
        elif cat == "文风" and sub == "样式":
            fields = dict(_kv_lines(body))
            # 正文区两种写法都认：「句长 平均 18 字」与「句长=平均 18 字」
            for key in ("视角", "句长", "对话占比", "禁用词", "节奏", "高频词", "句长阈值"):
                for line in body:
                    s = line.strip()
                    if s.startswith(key):
                        fields.setdefault(key, s[len(key):].lstrip("　:：=").strip())
            self.文风 = {"条目": stem, "字段": fields, "原文": text}
        elif cat == "工程" and sub == "清单":
            kv = _kv_lines(body)
            self.清单 = {"书名": kv.get("书名", self.name), "类型": kv.get("类型", ""),
                         "梗概": kv.get("一句话梗概", ""),
                         "构建顺序": [l.strip() for l in body if l.strip().startswith("第")]}
        elif cat == "时间线" and sub == "节点":
            for line in body:
                s = line.strip()
                if s and not s.startswith("@"):
                    head = re.split(r"[|｜]", s)[0].strip()
                    if head:
                        self.时间线.append(head)

    # ------------------------------------------------------------------ #
    def init_state(self) -> State:
        st = State()
        for name, info in self.变量.items():
            st.变量[name] = _num(info.get("初值", 0))
        for person, fields in self.人物状态.items():
            st.人物状态[person] = dict(fields)
        for pair, fields in self.关系.items():
            st.关系[pair] = dict(fields)
        for person, facts in self.知识种子.items():
            st.知识.setdefault(person, set()).update(facts)
        return st

    def persons(self) -> set:
        return {f.split(".")[0] for f in self.文件 if ".人物." in f} | set(self.人物状态) | set(self.知识种子)

    def places(self) -> set:
        return {f.split(".")[0] for f in self.文件 if ".地点." in f}

    def chapters(self) -> list[str]:
        """章节顺序：工程清单 @构建顺序 > 时间线节点 > 剧本文件名排序。"""
        order = [c for c in self.清单.get("构建顺序", []) if c in self.剧本] or \
                self.清单.get("构建顺序", [])
        if not order:
            order = [c for c in self.时间线 if c in self.剧本]
        if not order:
            order = sorted(self.剧本.keys())
        if not order:
            order = sorted({f.split(".")[0] for f in self.文件 if ".剧本." in f})
        return order

    def chapter_steps(self, chapter: str) -> tuple[list[tuple[str, str]], dict]:
        """本章要执行的东西：剧本里显式引用的 事件/决策；没有引用就用"来源=本章"的事件。"""
        script = self.剧本.get(chapter)
        refs = list(script["引用"]) if script else []
        if not refs:
            refs = [("事件", name) for name, ev in self.事件.items()
                    if _refers_to(ev.来源, chapter) or name.startswith(chapter)]
        steps = []
        for kind, name in refs:
            if kind == "事件" and name in self.事件:
                steps.append(("事件", name))
            elif kind == "决策" and name in self.决策:
                steps.append(("决策", name))
            else:
                steps.append(("缺失", name))
        return steps, (script or {})


def _strip_ext(name: str) -> str:
    parts = (name or "").strip().split(".")
    if len(parts) >= 3 and parts[-2] in ("事件", "决策", "剧本", "人物", "地点", "变量", "文风", "行为"):
        return ".".join(parts[:-2])
    return (name or "").strip()


def _refers_to(src: str, chapter: str) -> bool:
    return bool(src) and (chapter in src or src.startswith(chapter))


def _num(v) -> float | int | str:
    if isinstance(v, (int, float)):
        return v
    s = str(v).strip()
    if s in ("是", "真", "开"):
        return 1
    if s in ("否", "假", "关"):
        return 0
    try:
        return float(s) if "." in s else int(s)
    except ValueError:
        return s


# --------------------------------------------------------------------------- #
# 二、组装骨架（原文级，不改写）
# --------------------------------------------------------------------------- #
def skeleton(script: dict, events: list[Event]) -> list[str]:
    """有分镜用分镜；没有分镜就用事件步骤合成。返回段落列表。"""
    lines = list(script.get("分镜") or []) if script else []
    if lines:
        out = []
        for raw in lines:
            s = raw.strip()
            if s.startswith(">"):
                out.append(s[1:].strip())
            else:
                out.append(s)
        return [x for x in out if x and not NOISE_SENT_RE.match(x)]
    out = []
    for ev in events:
        for raw in ev.步骤:
            kind, text = parse_step(raw)
            if not text:
                continue
            if kind == "对白":
                out.append(f"「{text}」")
            elif kind == "内心":
                out.append(f"（{text}）")
            elif kind == "镜头":
                continue
            else:
                out.append(text)
    return out


# --------------------------------------------------------------------------- #
# 三、风格化（机械、可解释、记录改动）
# --------------------------------------------------------------------------- #
def parse_style(文风: dict) -> dict:
    fields = (文风 or {}).get("字段") or {}
    句长 = _first_num(fields.get("句长", "")) or 18
    禁用 = [w for w in re.split(r"[、,，\s]+", str(fields.get("禁用词", ""))) if w and w != "@待补"]
    目标对话 = _first_num(str(fields.get("对话占比", "")))
    return {"句长": 句长, "禁用词": 禁用, "目标对话占比": 目标对话,
            "视角": fields.get("视角", ""), "条目": (文风 or {}).get("条目", ""),
            "长句阈值": max(24, int(句长 * 1.8))}


def _first_num(text: str):
    m = re.search(r"\d+(?:\.\d+)?", str(text or ""))
    return float(m.group(0)) if m else None


def style_apply(paras: list[str], style: dict) -> dict:
    """机械风格化：超长句断句（保守）+ 禁用词体检 + 对话占比对照。"""
    changes: list[str] = []
    hits: dict[str, int] = {}
    out: list[str] = []
    threshold = style["长句阈值"]
    for para in paras:
        text = para
        for w in style["禁用词"]:
            n = text.count(w)
            if n:
                hits[w] = hits.get(w, 0) + n
        pieces = re.split(r"(?<=[。！？…])", text)
        rebuilt = []
        for piece in pieces:
            if not piece:
                continue
            if len(piece) > threshold:
                cut = _split_long(piece, threshold)
                if len(cut) > 1:
                    changes.append(f"{len(piece)} 字长句 → 断为 {len(cut)} 句：{piece[:18]}…")
                rebuilt.extend(cut)
            else:
                rebuilt.append(piece)
        out.append("".join(rebuilt))
    chars = sum(len(p) for p in out)
    quote_chars = sum(len(m) for p in out for m in re.findall(r"「(.+?)」", p))
    ratio = round(quote_chars / chars * 100) if chars else 0
    return {"段落": out, "改动": changes, "禁用词命中": hits,
            "对话占比": ratio, "字数": chars}


def _split_long(piece: str, threshold: int) -> list[str]:
    """在逗号处就近切断，最多切两刀；切不了就原样保留（不做任何改写）。"""
    parts = [piece]
    for _ in range(2):
        nxt = []
        for p in parts:
            if len(p) <= threshold:
                nxt.append(p)
                continue
            marks = [i for i, ch in enumerate(p) if ch in "，、；"]
            if not marks:
                nxt.append(p)
                continue
            mid = len(p) / 2
            pos = min(marks, key=lambda i: abs(i - mid))
            nxt.append(p[:pos + 1].replace("，", "。").replace("、", "。").replace("；", "。"))
            nxt.append(p[pos + 1:])
        parts = nxt
    return [p for p in parts if p]


# --------------------------------------------------------------------------- #
# 四、可选：模型翻译（骨架 → 正文），再核对逻辑守恒
# --------------------------------------------------------------------------- #
RENDER_SYSTEM = ("你是小说工程化系统的渲染器：把骨架按文风表翻译成人读的正文。"
                 "不许增删事件、不许改变因果、不许让角色知道轨迹外的信息、不许使用禁用词。")


def model_render(chapter: str, 骨架: list[str], style: dict, trace: list, 出场: list) -> tuple[str, str]:
    cur = llm.provider_info()
    if cur.get("api_style") == "mock":
        return "", "手动模式没有接入 AI：不做翻译，直接输出确定性骨架（正文不受影响）"
    tpl = RENDER_PROMPT.read_text(encoding="utf-8")
    prompt = (tpl.replace("{{章}}", chapter)
              .replace("{{文风}}", "\n".join(f"{k}：{v}" for k, v in (style or {}).items()))
              .replace("{{轨迹}}", "\n".join(f"- {t}" for t in _trace_lines(trace)))
              .replace("{{骨架}}", "\n".join(骨架)))
    try:
        text = llm.chat([{"role": "system", "content": RENDER_SYSTEM},
                         {"role": "user", "content": prompt}], max_tokens=4000)
        return text.strip(), ""
    except llm.LLMError as exc:
        return "", f"模型翻译失败，已回退骨架：{exc}"


def conservation_check(text: str, trace: list, 出场: list, *, strict_facts: bool = False) -> list[str]:
    """逻辑守恒：轨迹里的状态变化 / 揭示，在正文里有没有着落。

    · 始终检查（机械可靠）：改状态的人是否出现在正文里（不在场却改了状态 = 可能漏写）；无效效果。
    · 仅模型翻译时追加（strict_facts）：事实原话能否在正文里找到 —— 确定性组装时正文就是原文，
      拿它去核对必然误报，所以只在正文被模型改写过的前提下才要求落点。
    """
    issues = []
    for item in trace:
        if item.get("类型") == "效果":
            target = item.get("目标", "")
            person = target.split(".")[1] if target.startswith("s.") else ""
            if person and person not in text:
                issues.append(f"{item.get('事件')}：状态变化涉及「{person}」，正文里没出现这个名字")
            if isinstance(item.get("前"), (int, float)) and isinstance(item.get("后"), (int, float)):
                if item["前"] == item["后"]:
                    issues.append(f"{item.get('事件')}：{target} 状态没变（{item['前']} → {item['后']}），可能是无效效果")
        elif item.get("类型") == "揭示":
            who = str(item.get("人物", ""))
            if who and who not in text:
                issues.append(f"{item.get('事件')}：{who} 学到了信息，但正文里没出现这个人")
            if strict_facts:
                fact = str(item.get("事实", ""))
                key = re.sub(r"[，。！？、]", "", fact)[:6]
                if key and key not in re.sub(r"[，。！？、]", "", text):
                    issues.append(f"{item.get('事件')}：揭示「{fact}」在正文里找不到落点")
    return issues


def _trace_lines(trace: list) -> list[str]:
    out = []
    for t in trace:
        kind = t.get("类型")
        if kind == "效果":
            out.append(f"{t.get('事件')}：{t.get('目标')} {t.get('前')} → {t.get('后')}")
        elif kind == "揭示":
            out.append(f"{t.get('事件')}：{t.get('人物')}知道了「{t.get('事实')}」")
        elif kind == "分支":
            out.append(f"{t.get('决策')}：选中「{t.get('选中')}」（条件 {t.get('条件')}）→ {t.get('去向')}")
        elif kind == "发生":
            out.append(f"{t.get('事件')}：发生")
        elif kind in ("警告", "错误", "跳过"):
            out.append(f"[{kind}] {t.get('事件') or t.get('决策')}：{t.get('说明')}")
    return out


# --------------------------------------------------------------------------- #
# 五、总装
# --------------------------------------------------------------------------- #
def build(project: str, *, chapters: list[str] | None = None, mode: str = "rules",
          strict: bool = False, log=None, start_state: dict | None = None,
          report_dir: Path | None = None) -> dict:
    """构建全书或单章。

    · chapters 给了就只跑这些章（单章重建）；其余 build/*.txt 不动
    · start_state 给了就用它当起点（单章重建接着上次终点）；否则从条目初值起算
    · report_dir 指定报告/轨迹/状态落在哪（单章重建默认写到 build/单章重建-<章>/，不覆盖全书报告）
    """
    say = log or (lambda *_: None)
    proj = Project(project)
    say(f"读入 {len(proj.文件)} 个条目：变量 {len(proj.变量)} / 事件 {len(proj.事件)} / "
        f"决策 {len(proj.决策)} / 剧本 {len(proj.剧本)}")
    if proj.从公共库:
        names = sorted(set(proj.从公共库))
        tail = "、" .join(names[:6]) + ("…" if len(names) > 6 else "")
        say(f"跨库引用：从公共库解析 {len(names)} 个条目（{tail}）")
    if proj.缺失依赖:
        say(f"⚠ 有 {len(set(proj.缺失依赖))} 个 @导入 在项目和公共库里都找不到："
            f"{'、'.join(sorted(set(proj.缺失依赖))[:8])}")
    state = proj.init_state()
    if start_state:
        # 单章重建：接着上次终点跑。只覆盖给了值的部分，其余保持条目初值。
        for k, v in (start_state.get("变量") or {}).items():
            state.变量[k] = v
        for k, fields in (start_state.get("人物状态") or {}).items():
            state.人物状态.setdefault(k, {}).update(fields)
        for k, fields in (start_state.get("关系") or {}).items():
            state.关系.setdefault(k, {}).update(fields)
        for who, facts in (start_state.get("知识") or {}).items():
            state.知识.setdefault(who, set()).update(facts)
        state.已发生 = list(start_state.get("已发生") or [])
        say("单章重建：以 state/运行时状态.json 为起点")
    kernel = Kernel(state, proj.persons(), proj.places(), proj.变量.keys(), proj.关系.keys())
    style = parse_style(proj.文风)
    say(f"文风：{style['条目'] or '（无样式表，用默认阈值）'}  句长≈{style['句长']}字  "
        f"禁用词 {len(style['禁用词'])} 个")

    order = chapters or proj.chapters()
    if not order:
        raise files.FsError("没有可构建的章节：需要 .剧本.正文 或 .时间线.节点 指定章节顺序")

    build_dir = files.scope_root("build", project)
    build_dir.mkdir(parents=True, exist_ok=True)
    report_chapters = []
    md = [f"# {proj.清单.get('书名') or project} · 执行轨迹", ""]

    for chapter in order:
        steps, script = proj.chapter_steps(chapter)
        trace: list[dict] = []
        fired_events: list[Event] = []
        # 世界规则：每章开跑前先按条件自动作用到状态上（天黑了要睡、饿了会衰减…）
        world_fired = rules.apply_world_rules(kernel, chapter, trace)
        if world_fired:
            say(f"{chapter}：世界规则触发 {world_fired} 次")
        queue = list(steps)
        guard = 0
        while queue and guard < 200:
            guard += 1
            kind, name = queue.pop(0)
            if kind == "事件":
                ev = proj.事件[name]
                if kernel.run_event(ev, chapter, trace):
                    fired_events.append(ev)
            elif kind == "决策":
                dc = proj.决策[name]
                nxt = kernel.run_decision(dc, chapter, trace)
                if nxt:
                    queue.insert(0, ("事件", _strip_ext(nxt)))
            else:
                trace.append({"章": chapter, "类型": "错误", "说明": f"引用了不存在的条目：{name}"})

        骨架 = skeleton(script, fired_events)
        if not 骨架:
            trace.append({"章": chapter, "类型": "警告", "说明": "本章没有正文来源（既没有分镜，也没有事件步骤）"})

        errors = [t for t in trace if t.get("类型") == "错误"]
        rendered, note = "", ""
        if mode == "model" and 骨架 and not errors:
            rendered, note = model_render(chapter, 骨架, (proj.文风 or {}).get("字段") or {},
                                          trace, [p for ev in fired_events for p in ev.出场])
        body_paras = [l for l in (rendered.split("\n") if rendered else 骨架) if l.strip()]
        styled = style_apply(body_paras, style)

        title = script.get("章") or chapter
        header = title if title.startswith("第") else f"{chapter}　{title}"
        text = header + "\n\n" + "\n\n".join(styled["段落"]) + "\n"

        blocked = bool(strict and errors)
        target = build_dir / f"{chapter}.txt"
        if blocked:
            target.unlink(missing_ok=True)
        else:
            target.write_text(text, encoding="utf-8")

        issues = conservation_check("\n".join(styled["段落"]), trace,
                                    [p for ev in fired_events for p in ev.出场],
                                    strict_facts=(mode == "model" and bool(rendered)))
        report_chapters.append({
            "章": chapter, "标题": header, "文件": target.name if not blocked else "",
            "字数": styled["字数"], "段落": len(styled["段落"]),
            "轨迹条数": len(trace),
            "状态变化": [t for t in trace if t.get("类型") == "效果"],
            "分支": [t for t in trace if t.get("类型") == "分支"],
            "揭示": [t for t in trace if t.get("类型") == "揭示"],
            "风格改动": styled["改动"], "禁用词命中": styled["禁用词命中"],
            "对话占比": styled["对话占比"], "目标对话占比": style["目标对话占比"],
            "错误": errors, "警告": [t for t in trace if t.get("类型") in ("警告", "跳过")],
            "已拦截": blocked, "渲染说明": note, "守恒问题": issues,
            "正文": "" if blocked else text,
        })
        say(f"{chapter}：{styled['字数']} 字 / 轨迹 {len(trace)} 条 / "
            f"风格改动 {len(styled['改动'])} 处" + ("（有错误，已拦截）" if blocked else ""))

        md += [f"## {chapter} {title}", ""]
        if not trace:
            md += ["（本章没有事件与决策，只有分镜）", ""]
        for t in trace:
            md.append(f"- {_describe(t)}")
        md.append("")

    md += ["## 终态", "", "```json", json.dumps(state.snapshot(), ensure_ascii=False, indent=2), "```", ""]
    (report_dir or build_dir).mkdir(parents=True, exist_ok=True)
    ((report_dir or build_dir) / "执行轨迹.md").write_text("\n".join(md), encoding="utf-8")

    total_errors = sum(len(c["错误"]) for c in report_chapters)
    total_warn = sum(len(c["警告"]) for c in report_chapters)
    report = {
        "工程": project, "模式": "模型翻译" if mode == "model" else "确定性组装",
        "章节": report_chapters,
        "统计": {"章节数": len(report_chapters),
                 "总字数": sum(c["字数"] for c in report_chapters),
                 "错误": total_errors, "警告": total_warn,
                 "状态变化": sum(len(c["状态变化"]) for c in report_chapters),
                 "分支": sum(len(c["分支"]) for c in report_chapters),
                 "揭示": sum(len(c["揭示"]) for c in report_chapters),
                 "风格改动": sum(len(c["风格改动"]) for c in report_chapters),
                 "守恒问题": sum(len(c["守恒问题"]) for c in report_chapters)},
        "文风": {"条目": style["条目"], "句长": style["句长"], "禁用词": style["禁用词"],
                 "长句阈值": style["长句阈值"], "目标对话占比": style["目标对话占比"]},
        "门禁": {"结果": "拦截" if total_errors and strict else ("有问题未拦截" if total_errors else "通过"),
                 "说明": "严格模式下有错误就不出正文"},
        "跨库引用": {"从公共库解析": sorted(set(proj.从公共库)),
                     "未解析的导入": sorted(set(proj.缺失依赖)),
                     "说明": "项目里没有的 @导入 条目会去公共库 library/ 取；项目自己的定义优先"},
        "产物": (["build/第NN章.txt（只重写这几章）", "build/单章重建/执行轨迹.md", "build/单章重建/构建报告.json",
                  "（单章重建不写 state/运行时状态.json）"] if report_dir else
                 ["build/第NN章.txt", "build/执行轨迹.md", "build/构建报告.json", "state/运行时状态.json"]),
    }
    out_dir = report_dir or build_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "构建报告.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if not report_dir:
        # 只有整本构建才推进 state/运行时状态.json（单章重建不能假装全书终态）
        state_dir = files.scope_root("project", project).parent / "state"
        state_dir.mkdir(parents=True, exist_ok=True)
        (state_dir / "运行时状态.json").write_text(
            json.dumps(state.snapshot(), ensure_ascii=False, indent=2), encoding="utf-8")
    say(f"构建完成：{report['统计']['总字数']} 字，门禁 {report['门禁']['结果']}")
    return report


def _describe(t: dict) -> str:
    kind = t.get("类型")
    if kind == "效果":
        return f"**效果** {t.get('目标')}：{t.get('前')} → **{t.get('后')}**"
    if kind == "揭示":
        return f"**揭示** {t.get('人物')} 知道了「{t.get('事实')}」"
    if kind == "分支":
        return f"**分支** {t.get('决策')} → 选中「{t.get('选中')}」（{t.get('条件')}）⇒ {t.get('去向')}"
    if kind == "发生":
        return f"发生：{t.get('事件')}"
    return f"[{kind}] {t.get('事件') or t.get('决策') or ''} {t.get('说明') or ''}".strip()
