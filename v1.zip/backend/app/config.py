"""配置与模型接入：手动模式 + 本机免 Key（CodeBuddy / Trae）+ OpenAI 兼容。"""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "backend" / "data"
DATA.mkdir(parents=True, exist_ok=True)
SETTINGS_FILE = DATA / "settings.json"

PROVIDERS = {
    # 手动编辑模式 = 默认。不是「演示」，不是降级：这就是完整可用的工作方式。
    "manual": {"id": "manual", "label": "手动编辑模式（不调用 AI）", "api_style": "mock",
               "needs_key": False, "base_url": "", "default_model": "",
               "desc": "编辑 / 构建 / 预览全部可用，只有 AI 对话关闭",
               "models": []},
    "codebuddy": {"id": "codebuddy", "label": "本机 CodeBuddy（免 Key）", "api_style": "codebuddy",
                  "needs_key": False, "base_url": "https://copilot.tencent.com",
                  "default_model": "auto",
                  "desc": "读取 VS Code / CodeBuddy IDE 里已登录的账号",
                  "models": [{"id": "auto", "label": "auto（服务端默认）"},
                             {"id": "default", "label": "Default"},
                             {"id": "deepseek-v4-flash", "label": "DeepSeek-V4-Flash"},
                             {"id": "glm-5v-turbo", "label": "GLM-5v-Turbo"},
                             {"id": "hy3", "label": "Hy3"},
                             {"id": "default-1.1", "label": "Claude-3.7-Sonnet"},
                             {"id": "default-1.2", "label": "Claude-4.0-Sonnet"},
                             {"id": "kimi-k2-instruct-taiji", "label": "Kimi-K2"}]},
    "trae": {"id": "trae", "label": "本机 TraeCode（免 Key）", "api_style": "trae",
             "needs_key": False, "base_url": "", "default_model": "",
             "desc": "读取已登录 TraeCode 扩展（marscode.marscode-extension）的编辑器",
             "models": []},
    "openai": {"id": "openai", "label": "OpenAI（GPT）", "api_style": "openai", "needs_key": True,
               "base_url": "https://api.openai.com/v1", "default_model": "gpt-4o",
               "models": [{"id": "gpt-4o", "label": "GPT-4o"}, {"id": "gpt-4o-mini", "label": "GPT-4o mini"}]},
    "deepseek": {"id": "deepseek", "label": "DeepSeek", "api_style": "openai", "needs_key": True,
                 "base_url": "https://api.deepseek.com", "default_model": "deepseek-chat",
                 "models": [{"id": "deepseek-chat", "label": "DeepSeek Chat"}]},
    "glm": {"id": "glm", "label": "智谱 GLM", "api_style": "openai", "needs_key": True,
            "base_url": "https://open.bigmodel.cn/api/paas/v4", "default_model": "glm-4.6",
            "models": [{"id": "glm-4.6", "label": "GLM-4.6"}]},
    "kimi": {"id": "kimi", "label": "Kimi", "api_style": "openai", "needs_key": True,
             "base_url": "https://api.moonshot.cn/v1", "default_model": "kimi-k2-0905-preview",
             "models": [{"id": "kimi-k2-0905-preview", "label": "Kimi K2"}]},
    "qwen": {"id": "qwen", "label": "通义千问", "api_style": "openai", "needs_key": True,
             "base_url": "https://dashscope.aliyuncs.com/compatible-mode/v1",
             "default_model": "qwen-plus", "models": [{"id": "qwen-plus", "label": "通义 Plus"}]},
}
DEFAULTS = {"llm_provider": "manual", "llm_keys": {}, "llm_models": {}, "llm_custom": {},
            "temperature": 0.9, "codebuddy_db_path": "", "trae_db_path": ""}


def load() -> dict:
    data = dict(DEFAULTS)
    if SETTINGS_FILE.is_file():
        try:
            raw = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                data.update(raw)
        except (json.JSONDecodeError, OSError):
            pass
    for k in ("llm_keys", "llm_models", "llm_custom"):
        if not isinstance(data.get(k), dict):
            data[k] = {}
    return data


def save(patch: dict) -> dict:
    data = load()
    for k in ("llm_provider", "temperature"):
        if patch.get(k) is not None:
            data[k] = patch[k]
    for k in ("llm_keys", "llm_models"):
        if isinstance(patch.get(k), dict):
            cur = data.get(k) or {}
            for pid, val in patch[k].items():
                if val is None:
                    cur.pop(pid, None)
                else:
                    cur[pid] = str(val)
            data[k] = cur
    if isinstance(patch.get("llm_custom"), dict):
        cur = data.get("llm_custom") or {}
        for pid, val in patch["llm_custom"].items():
            if pid in cur and cur[pid] != val and not patch.get("force_custom"):
                raise ValueError(f"自定义接口「{pid}」已存在且内容不同；改名，或带 force_custom 覆盖")
            cur[pid] = val
        data["llm_custom"] = cur
    SETTINGS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return data


def preset(pid: str) -> dict:
    pid = (pid or "manual").lower()
    custom = load().get("llm_custom") or {}
    if pid in custom:
        item = dict(custom[pid])
        item.setdefault("id", pid)
        item.setdefault("label", pid)
        item.setdefault("api_style", "openai")
        item.setdefault("needs_key", True)
        item.setdefault("default_model", (item.get("models") or [{}])[0].get("id", ""))
        return item
    return PROVIDERS.get(pid) or PROVIDERS["manual"]


def _local_available() -> bool:
    """本机接入模块（localai）是否还在。删掉它就只是没有本机识别能力。"""
    try:
        from app import localai

        return localai.available()
    except Exception:  # noqa: BLE001
        return False


def resolve() -> dict:
    cfg = load()
    pid = (cfg.get("llm_provider") or "manual").strip().lower()
    p = preset(pid)
    key = ((cfg.get("llm_keys") or {}).get(pid) or "").strip()
    model = ((cfg.get("llm_models") or {}).get(pid) or "").strip() or p.get("default_model", "")
    style = p.get("api_style", "openai")
    # 本机通路在模块缺失时不算「已配置」——否则界面会显示可用、一调用就报错
    local_ok = True
    if style in ("codebuddy", "trae"):
        local_ok = _local_available()
    return {"provider": pid, "label": p["label"], "api_style": style,
            "base_url": (p.get("base_url") or "").strip(), "api_key": key, "model": model,
            "temperature": float(cfg.get("temperature", 0.9)),
            "desc": p.get("desc", ""),
            "local_available": local_ok,
            # 手动模式与免 Key 的本地通路都算「已配置」——它们本来就不需要 Key
            "configured": (style == "mock" or bool(key) or
                           (p.get("needs_key") is False and local_ok))}


def public_providers() -> list[dict]:
    cfg = load()
    keys = cfg.get("llm_keys") or {}
    local_ok = _local_available()
    ids = ["manual"]
    # 本机通路只在模块还在时才列出——删掉 localai 就看不到这两个选项
    if local_ok:
        ids += ["codebuddy", "trae"]
    ids += [k for k in (cfg.get("llm_custom") or {})]
    ids += ["openai", "deepseek", "glm", "kimi", "qwen"]
    out = []
    for pid in ids:
        p = preset(pid)
        out.append({"id": p["id"], "label": p["label"], "desc": p.get("desc", ""),
                    "base_url": p.get("base_url", ""), "default_model": p.get("default_model", ""),
                    "needs_key": p.get("needs_key", True), "api_style": p.get("api_style", "openai"),
                    "models": p.get("models", []),
                    "has_key": bool((keys.get(pid) or "").strip())})
    return out
