"""v3 API 路由。架构：工程与公共库都是文件，接口只做文件与双库操作 + 对话。"""
from __future__ import annotations

import json
import traceback
from pathlib import Path

from app import builder, config, decompose, files, llm, merge
from app.net import Error, Json, Raw, Sse
from app.files import FsError

ROUTES: list[tuple[str, str, object]] = []


def route(method: str, pattern: str):
    def deco(fn):
        ROUTES.append((method, pattern, fn))
        return fn
    return deco


def match(method: str, path: str):
    for m, pattern, fn in ROUTES:
        if m != method:
            continue
        params = _match(pattern, path)
        if params is not None:
            return fn, params
    return None, None


def _match(pattern: str, path: str):
    if pattern == path:
        return {}
    p, s = pattern.strip("/").split("/"), path.strip("/").split("/")
    if len(p) != len(s):
        return None
    out = {}
    for a, b in zip(p, s):
        if a.startswith("{") and a.endswith("}"):
            out[a[1:-1]] = b
        elif a != b:
            return None
    return out


def guard(fn):
    """保留位：错误转换已在 server.py 统一处理。"""
    return fn


# --------------------------------------------------------------------------- #
@route("GET", "/api/health")
def health(ctx):
    cur = config.resolve()
    return {"ok": True, "version": "v3.0-shell", "provider": cur,
            "root": str(files.ROOT)}


@route("GET", "/api/settings")
def settings_get(ctx):
    cfg = config.load()
    return {"llm_provider": cfg.get("llm_provider"), "temperature": cfg.get("temperature"),
            "providers": config.public_providers(),
            "codebuddy_db_path": cfg.get("codebuddy_db_path") or "",
            "trae_db_path": cfg.get("trae_db_path") or ""}


# ------------------------------- AI 能力与探测 ------------------------------- #
@route("GET", "/api/ai/status")
def ai_status(ctx):
    """能否用 AI。界面据此只在 AI 输入区提示，不拦截其它功能。"""
    from app import llm as llm_mod

    llm = config.resolve()
    cap = llm_mod.can_chat()
    return {"provider": llm["provider"], "label": llm["label"], "api_style": llm["api_style"],
            "model": llm["model"], "configured": llm["configured"],
            "manual": llm["api_style"] == "mock",
            "local_available": llm.get("local_available", True),
            "ok": cap["ok"], "reason": cap["reason"]}


@route("POST", "/api/ai/probe")
def ai_probe(ctx):
    """探测本机免 Key 通路：读编辑器里的登录信息，不发送任何对话请求。

    走 localai 这层可选模块——它不在时如实说明「没有这个能力」，其余功能不受影响。
    """
    b = ctx.json
    which = str(b.get("which") or "").strip().lower()
    force = bool(b.get("force"))
    try:
        from app import localai
    except ImportError:
        return {"which": which, "ok": False, "available": False,
                "issue": "本机接入模块缺失（localai.py）：编辑与构建不受影响，只是读不到本机编辑器登录",
                "checked": [], "attempts": []}
    if not localai.available():
        return {"which": which, "ok": False, "available": False,
                "issue": "本机接入模块缺失（localai.py）：编辑与构建不受影响，只是读不到本机编辑器登录",
                "checked": [], "attempts": []}
    if which in ("codebuddy", "trae"):
        return {"which": which, "available": True, **localai.probe(which, force)}
    return {"available": True, **localai.probe_all(force)}


@route("GET", "/api/ai/models")
def ai_models(ctx):
    """拉当前通路的模型列表（CodeBuddy / Trae 走各自的服务端目录）。"""
    which = (ctx.query.get("which") or "").strip().lower()
    force = ctx.query.get("force") in ("1", "true", "yes")
    try:
        from app import localai
    except ImportError:
        return {"models": [], "error": "本机接入模块缺失（localai.py）"}
    if which in ("codebuddy", "trae"):
        return localai.models(which, force)
    return {"models": [], "error": "未知通路"}


@route("GET", "/api/ai/diag")
def ai_diag(ctx):
    """诊断：把本机通路拿到的原始响应摘要吐出来。

    网关没有文档，出问题时唯一靠得住的是「它到底回了什么」。
    这里只返回结构摘要（键名 / 条目数 / 前几百字节），不返回任何令牌。
    """
    which = (ctx.query.get("which") or "trae").strip().lower()
    try:
        from app import localai
    except ImportError:
        return {"ok": False, "error": "本机接入模块缺失（localai.py）"}
    if which not in ("codebuddy", "trae"):
        return {"ok": False, "error": "未知通路"}
    return localai.diagnose(which)


@route("GET", "/api/ai/choosable")
def ai_choosable(ctx):
    """右栏模型切换器要用的清单：当前通路 + 所有可选模型。

    返回 {current, options:[{id,label,provider,providerLabel}], error}
      · 本机通路（CodeBuddy / Trae）通常有多个模型 → options 多条
      · OpenAI 兼容通常只有配置里的那一个 → options 一条（前端就不显示选框）
      · 手动模式 → options 为空
    """
    llm = config.resolve()
    style = llm.get("api_style")
    options: list[dict] = []
    error = ""
    provider_label = llm.get("label") or ""

    if style in ("codebuddy", "trae"):
        try:
            from app import localai

            cat = localai.models(style, False)
            error = cat.get("error") or ""
            for m in cat.get("models") or []:
                item = {"id": m["id"], "label": m.get("label") or m["id"],
                        "provider": style, "providerLabel": provider_label}
                # CodeBuddy 的计费倍率（x0.11 这种），Trae 的标签（reasoning 等）
                if m.get("rate") is not None:
                    item["rate"] = m["rate"]
                if m.get("note"):
                    item["note"] = m["note"]
                options.append(item)
        except ImportError:
            error = "本机接入模块缺失（localai.py）"
    elif style == "openai":
        preset = config.preset(llm["provider"])
        for m in preset.get("models") or []:
            options.append({"id": m["id"], "label": m.get("label") or m["id"],
                            "provider": llm["provider"], "providerLabel": provider_label})
    # 手动模式：没有可选项

    return {"current": llm.get("model") or "", "provider": llm.get("provider") or "",
            "providerLabel": provider_label, "manual": style == "mock",
            "options": options, "error": error}


@route("POST", "/api/settings")
def settings_set(ctx):
    config.save(ctx.json)
    return settings_get(ctx)


@route("GET", "/api/registry")
def registry(ctx):
    return files.registry_public()


# ------------------------------- 内置规则 ------------------------------- #
@route("GET", "/api/rules")
def rules_get(ctx):
    from app import rules

    return rules.describe()


@route("POST", "/api/rules")
def rules_set(ctx):
    from app import rules

    rules.save(ctx.json)
    return rules.describe()


@route("POST", "/api/rules/reset")
def rules_reset(ctx):
    from app import rules

    rules.reset()
    return rules.describe()


# ------------------------------- AI 规范 ------------------------------- #
@route("GET", "/api/ai/spec")
def ai_spec(ctx):
    """给外部 AI 的规范：接入后照它产出条目，不需要人手处理。

    ?format=text（默认，可直接塞 system prompt）| json
    """
    from app import aispec

    if (ctx.query.get("format") or "text").lower() == "json":
        return aispec.spec_json()
    return Raw(aispec.spec_text().encode("utf-8"), "text/plain; charset=utf-8")


# ------------------------------- 工程 ------------------------------- #
@route("GET", "/api/projects")
def projects(ctx):
    return {"projects": files.list_projects()}


@route("POST", "/api/projects")
def project_create(ctx):
    b = ctx.json
    return files.create_project(str(b.get("name") or ""), str(b.get("书名") or ""),
                               str(b.get("类型") or ""), str(b.get("梗概") or ""))


@route("GET", "/api/projects/{name}/summary")
def project_summary(ctx):
    return files.project_summary(ctx.params["name"])


@route("POST", "/api/projects/{name}/rename")
def project_rename(ctx):
    new = str(ctx.json.get("new") or "").strip()
    files.rename_project(ctx.params["name"], new)
    return {"name": new}


@route("DELETE", "/api/projects/{name}")
def project_delete(ctx):
    files.delete_project(ctx.params["name"])
    return None


# ------------------------------- 目录树 ------------------------------- #
@route("GET", "/api/tree")
def tree(ctx):
    return files.tree(ctx.query.get("project") or "")


# ------------------------------- 文件 ------------------------------- #
def _scope_args(ctx) -> tuple[str, str, str]:
    scope = (ctx.query.get("scope") or ctx.json.get("scope") or "project")
    project = ctx.query.get("project") or ctx.json.get("project") or ""
    rel = ctx.query.get("path") or ctx.json.get("path") or ""
    return scope, project, rel


@route("GET", "/api/file")
def file_get(ctx):
    scope, project, rel = _scope_args(ctx)
    return files.read_file(scope, project, rel)


@route("PUT", "/api/file")
def file_save(ctx):
    b = ctx.json
    return files.write_file(b.get("scope") or "project", b.get("project") or "",
                            b.get("path") or "", b.get("content") or "")


@route("POST", "/api/file/new")
def file_new(ctx):
    b = ctx.json
    return files.new_file(b.get("scope") or "project", b.get("project") or "",
                          str(b.get("大类") or ""), str(b.get("子类") or ""),
                          str(b.get("条目名") or ""))


@route("POST", "/api/file/rename")
def file_rename(ctx):
    b = ctx.json
    return files.rename_file(b.get("scope") or "project", b.get("project") or "",
                             b.get("path") or "", str(b.get("new") or ""))


@route("POST", "/api/file/delete")
def file_delete(ctx):
    b = ctx.json
    files.delete_file(b.get("scope") or "project", b.get("project") or "", b.get("path") or "")
    return None


# ------------------------------- 双库传递 ------------------------------- #
@route("POST", "/api/transfer/pull")
def transfer_pull(ctx):
    b = ctx.json
    return {"files": files.pull_from_library(b.get("project") or "", b.get("paths") or [],
                                             str(b.get("into") or ""), str(b.get("rename") or ""))}


@route("POST", "/api/transfer/promote")
def transfer_promote(ctx):
    b = ctx.json
    return files.promote_to_library(b.get("project") or "", b.get("path") or "",
                                    str(b.get("name") or ""), bool(b.get("generalize")))


# ------------------------------- 拆解器（导入整本小说） ------------------------------- #
def _load_novel_text(b: dict) -> str:
    """正文来源：直接给 text，或给服务器上的 path（本地开发便利）。"""
    text = b.get("text")
    if text:
        return str(text)
    path = str(b.get("path") or "").strip()
    if not path:
        raise Error("请提供小说正文（text）或服务器文件路径（path）")
    p = Path(path).expanduser()
    if not p.is_file():
        raise Error(f"文件不存在：{path}")
    raw = p.read_bytes()
    for enc in ("utf-8-sig", "utf-8", "gbk", "gb18030"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


@route("POST", "/api/decompose/preview")
def decompose_preview(ctx):
    b = ctx.json
    text = _load_novel_text(b)
    return decompose.preview(text, int(b.get("max_chapters") or 0))


@route("GET", "/api/decompose/report")
def decompose_report(ctx):
    project = ctx.query.get("project") or ""
    f = files.scope_root("project", project).parent / "state" / "拆解报告.json"
    if not f.is_file():
        raise files.FsError("还没有拆解报告", 404)
    return json.loads(f.read_text(encoding="utf-8"))


@route("POST", "/api/decompose/run")
def decompose_run(ctx):
    b = ctx.json
    text = _load_novel_text(b)
    project = str(b.get("project") or "").strip()
    mode = "model" if str(b.get("mode") or "rules") == "model" else "rules"
    max_chapters = int(b.get("max_chapters") or 0)
    meta = {"书名": b.get("书名") or project, "类型": b.get("类型") or "", "梗概": b.get("梗概") or ""}

    # 进度：拆解在工作线程里跑，逐章 log 通过 queue 推给前端
    import queue
    import threading

    q: "queue.Queue[object]" = queue.Queue()

    def worker():
        try:
            report = decompose.run(project, text, mode=mode, max_chapters=max_chapters, meta=meta,
                                   log=lambda t: q.put({"event": "log", "data": {"text": t}}))
            q.put({"event": "report", "data": report})
            q.put({"event": "done", "data": {"project": project}})
        except files.FsError as exc:
            q.put({"event": "message", "data": {"error": exc.detail}})
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc()
            q.put({"event": "message", "data": {"error": f"拆解失败：{exc}"}})
        finally:
            q.put(None)

    def stream_gen():
        yield {"event": "log", "data": {"text": f"开始拆解（{'模型抽取' if mode == 'model' else '规则抽取'}）"}}
        th = threading.Thread(target=worker, daemon=True)
        th.start()
        while True:
            item = q.get()
            if item is None:
                break
            yield item

    return Sse(stream_gen())


# ------------------------------- 构建器（条目 → 正文） ------------------------------- #
@route("POST", "/api/build")
def build_run(ctx):
    b = ctx.json
    project = str(b.get("project") or "").strip()
    if not project:
        raise Error("缺少 project")
    mode = "model" if str(b.get("mode") or "rules") == "model" else "rules"
    strict = bool(b.get("strict"))
    chapters = b.get("chapters") or None
    if chapters is not None and not isinstance(chapters, list):
        raise Error("chapters 必须是数组")
    single = bool(b.get("single")) and bool(chapters)

    import queue
    import threading

    q: "queue.Queue[object]" = queue.Queue()

    def worker():
        try:
            if single:
                # 单章重建：以现有运行时状态为起点，报告/轨迹落到 build/单章重建/，不碰全书产物
                project_dir = _project_file(project)
                start = None
                st = project_dir / "state" / "运行时状态.json"
                if st.is_file():
                    start = json.loads(st.read_text(encoding="utf-8"))
                report = builder.build(project, chapters=chapters, mode=mode, strict=strict, log=_log,
                                       start_state=start, report_dir=project_dir / "build" / "单章重建")
            else:
                report = builder.build(project, chapters=chapters, mode=mode, strict=strict, log=_log)
            q.put({"event": "report", "data": report})
            q.put({"event": "done", "data": {"project": project}})
        except files.FsError as exc:
            q.put({"event": "message", "data": {"error": exc.detail}})
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc()
            q.put({"event": "message", "data": {"error": f"构建失败：{exc}"}})
        finally:
            q.put(None)

    def _log(t: str):
        q.put({"event": "log", "data": {"text": t}})

    def stream_gen():
        label = "确定性组装" if mode == "rules" else "模型翻译"
        scope = f"单章 {'、'.join(chapters)}" if single else "整本"
        yield {"event": "log", "data": {"text": f"开始构建（{label} · {scope}）"}}
        th = threading.Thread(target=worker, daemon=True)
        th.start()
        while True:
            item = q.get()
            if item is None:
                break
            yield item

    return Sse(stream_gen())


def _project_file(project: str, *parts: str) -> Path:
    if not project:
        raise Error("缺少 project")
    d = files.PROJECTS / project
    if not d.exists():
        raise files.FsError(f"工程不存在：{project}", 404)
    return d.joinpath(*parts)


@route("GET", "/api/build/report")
def build_report(ctx):
    f = _project_file(ctx.query.get("project") or "", "build", "构建报告.json")
    if not f.is_file():
        raise files.FsError("还没有构建报告，先构建一次", 404)
    return json.loads(f.read_text(encoding="utf-8"))


@route("GET", "/api/build/trace")
def build_trace(ctx):
    f = _project_file(ctx.query.get("project") or "", "build", "执行轨迹.md")
    if not f.is_file():
        raise files.FsError("还没有执行轨迹，先构建一次", 404)
    return Raw(f.read_text(encoding="utf-8").encode("utf-8"), "text/plain; charset=utf-8")


@route("GET", "/api/state")
def state_get(ctx):
    f = _project_file(ctx.query.get("project") or "", "state", "运行时状态.json")
    if not f.is_file():
        raise files.FsError("还没有运行时状态，先构建一次", 404)
    return json.loads(f.read_text(encoding="utf-8"))


# ------------------------------- 实体归并 ------------------------------- #
@route("GET", "/api/merge/suggest")
def merge_suggest(ctx):
    return merge.suggest(ctx.query.get("project") or "")


@route("POST", "/api/merge/apply")
def merge_apply(ctx):
    b = ctx.json
    project = str(b.get("project") or "").strip()
    if not project:
        raise Error("缺少 project")
    mapping = b.get("mapping") or []
    return merge.apply(project, mapping,
                       rewrite_text=bool(b.get("rewrite_text", True)),
                       dry_run=bool(b.get("dry_run")))


@route("GET", "/api/merge/report")
def merge_report(ctx):
    f = _project_file(ctx.query.get("project") or "", "state", "归并报告.json")
    if not f.is_file():
        raise files.FsError("还没有归并报告，先做一次归并", 404)
    return json.loads(f.read_text(encoding="utf-8"))


# ------------------------------- AI 全自动生成 ------------------------------- #
@route("POST", "/api/ai/generate")
def ai_generate(ctx):
    """全自动：按规范让 AI 产出条目，直接写入工程（不需要人手贴）。

    入参 {project, task, dry_run, overwrite}
    用 SSE 推日志，最后推 report。
    """
    from app import autogen

    b = ctx.json
    project = str(b.get("project") or "").strip()
    task = str(b.get("task") or "").strip()
    dry_run = bool(b.get("dry_run"))
    overwrite = bool(b.get("overwrite"))

    import queue
    import threading

    q: "queue.Queue[object]" = queue.Queue()

    def worker():
        try:
            report = autogen.generate(project, task, dry_run=dry_run, overwrite=overwrite,
                                      log=lambda t: q.put({"event": "log", "data": {"text": t}}))
            q.put({"event": "report", "data": report})
            q.put({"event": "done", "data": {"project": project}})
        except files.FsError as exc:
            q.put({"event": "message", "data": {"error": exc.detail}})
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc()
            q.put({"event": "message", "data": {"error": f"生成失败：{exc}"}})
        finally:
            q.put(None)

    def stream_gen():
        yield {"event": "log", "data": {"text": f"开始生成（{'试运行' if dry_run else '写入'}）"}}
        th = threading.Thread(target=worker, daemon=True)
        th.start()
        while True:
            item = q.get()
            if item is None:
                break
            yield item

    return Sse(stream_gen())


# ------------------------------- AI 回复落地 ------------------------------- #
@route("POST", "/api/ai/apply")
def ai_apply(ctx):
    """把 AI 的一段回复解析成条目并写入工程。

    入参 {project, text, overwrite, target}
      · target 给了 → 整体写进这个文件（对话里「插入/追加」的语义升级版）
      · target 没给 → 从回复里解析出多个条目文件，逐个写入
    返回 {写入:[], 跳过:[]}
    """
    from app import autogen

    b = ctx.json
    project = str(b.get("project") or "").strip()
    text = str(b.get("text") or "")
    target = str(b.get("target") or "").strip()
    overwrite = bool(b.get("overwrite"))
    if not project:
        raise Error("缺少 project")
    if not text.strip():
        raise Error("回复内容为空")
    root = files.scope_root("project", project)
    if not root.exists():
        raise files.FsError(f"工程不存在：{project}", 404)

    # 指定了目标文件：整段写进去（当前打开的文件，最常用）
    if target:
        info = files.parse_filename(target)
        if not info["ok"]:
            raise files.FsError(f"目标文件名不合法：{info['why']}")
        path = root / target
        if path.exists() and not overwrite:
            return {"写入": [], "跳过": [{"文件名": target, "原因": "已存在（未开启覆盖）"}]}
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text.rstrip() + "\n", encoding="utf-8")
        return {"写入": [{"文件名": target, "字节": len(text)}], "跳过": []}

    # 没指定：按规范解析出多个条目
    written, skipped = [], []
    for item in autogen.parse_reply(text):
        name = item["文件名"]
        info = files.parse_filename(name)
        if not info["ok"]:
            skipped.append({"文件名": name, "原因": info["why"]})
            continue
        path = root / name
        if path.exists() and not overwrite:
            skipped.append({"文件名": name, "原因": "已存在（未开启覆盖）"})
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(item["内容"], encoding="utf-8")
        written.append({"文件名": name, "字节": len(item["内容"])})
    return {"写入": written, "跳过": skipped}


# ------------------------------- 对话 ------------------------------- #
@route("POST", "/api/chat")
def chat(ctx):
    b = ctx.json
    messages = b.get("messages") or []
    if not isinstance(messages, list) or not messages:
        raise Error("messages 不能为空")
    system = b.get("system") or ""
    if system:
        messages = [{"role": "system", "content": system}] + messages
    try:
        # 对话默认给足预算：带规范 + 当前文件时，2048 会被思考内容吃掉大半，
        # 正文还没写完就被截断，用户看到的就是「什么都没出来」。
        text = llm.chat(messages, max_tokens=int(b.get("max_tokens") or 8192))
    except llm.LLMError as exc:
        raise Error(str(exc), 502) from None
    return {"reply": text}


@route("POST", "/api/chat/stream")
def chat_stream(ctx):
    b = ctx.json
    messages = b.get("messages") or []
    system = b.get("system") or ""
    if system:
        messages = [{"role": "system", "content": system}] + messages
    # 同 /api/chat：给足预算，否则思考内容会把正文的额度吃掉
    max_tokens = int(b.get("max_tokens") or 8192)

    def gen():
        try:
            for chunk in llm.stream(messages, max_tokens=max_tokens):
                yield {"event": "delta", "data": {"text": chunk}}
            yield {"event": "done", "data": {}}
        except llm.LLMError as exc:
            msg = str(exc)
            # 排队 / 限流是可重试的，别的不是——前端据此决定要不要显示「重试」
            retry = any(k in msg for k in ("排队", "queue", "限流", "Too many", "超时", "timeout"))
            yield {"event": "message", "data": {"error": msg, "retry": retry}}

    return Sse(gen())
