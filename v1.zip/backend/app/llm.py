"""模型调用层。

四条通路：
  · manual    —— **手动编辑模式**（原「内置演示」）。不调用任何模型，不是错误状态。
                 文件系统、双库、构建器、预览全部照常可用；只有 AI 对话会如实提示未配置。
  · codebuddy —— 本机编辑器登录，免 Key，见 app/codebuddy.py
  · trae      —— 本机 TraeCode 扩展登录，免 Key，见 app/trae.py
  · openai    —— 任何 OpenAI 兼容接口（DeepSeek / GLM / Kimi / 通义 / 自建）

设计要点（细节优化 3）：**「没有配置 AI」不是故障**。
手动模式是一个正常的、功能完整的工作方式——你手写条目、手写剧本、自己点构建。
所以这里不抛「未配置」异常去拦截整条链路，而是提供一个 can_chat() 让界面
只在 AI 输入区显示一行提示。构建器的 rules 模式根本不经过本模块。
"""
from __future__ import annotations

import json
from collections.abc import Iterator

from app import config
from app.net import HttpError, request

MANUAL = "manual"


class LLMError(RuntimeError):
    """面向用户的大模型调用错误。"""


# --------------------------------------------------------------------------- #
# 能力查询
# --------------------------------------------------------------------------- #
def provider_info() -> dict:
    """当前生效的模型配置。"""
    return config.resolve()


def is_manual() -> bool:
    """是不是手动编辑模式（不调用模型）。"""
    return config.resolve().get("api_style") == "mock"


def can_chat() -> dict:
    """能否调用 AI。

    返回 {"ok": bool, "reason": str}。`reason` 是给人看的一句话，
    界面把它放进 AI 输入区，而不是弹错误框。
    """
    llm = config.resolve()
    if llm.get("api_style") == "mock":
        return {"ok": False,
                "reason": "当前是手动编辑模式：编辑、构建、预览都不受影响，只是 AI 对话不可用。"
                          "要启用 AI，到「设置 → 模型接口」接入本机 CodeBuddy / Trae，或填一个 API Key。"}
    if not llm.get("configured"):
        if llm.get("local_available") is False:
            return {"ok": False,
                    "reason": "本机接入模块（localai）不在了：编辑与构建不受影响，只是读不到本机编辑器的登录。"
                              "可以改用 OpenAI 兼容接口填一个 Key。"}
        return {"ok": False,
                "reason": f"「{llm.get('label') or llm.get('provider')}」还没有填 API Key。"}
    return {"ok": True, "reason": ""}


# --------------------------------------------------------------------------- #
# 手动模式回复
# --------------------------------------------------------------------------- #
_MANUAL_HINT = (
    "（手动编辑模式）这里没有接 AI，但工作台的一切都照常可用：\n"
    "· 左栏建条目、写文件，Ctrl+S 保存\n"
    "· 构建 → 构建全书，确定性内核会把条目跑成正文\n"
    "· 编辑区切到「预览」可以直接看渲染结果\n"
    "要启用 AI 对话，到「设置 → 模型接口」接入本机 CodeBuddy / Trae（免 Key），或填一个 API Key。"
)


def _manual_reply(messages: list[dict]) -> str:
    last_user = next((m.get("content", "") for m in reversed(messages)
                      if m.get("role") == "user"), "")
    tail = f"\n\n（你刚才说：{last_user.strip()[:120]}）" if last_user.strip() else ""
    return _MANUAL_HINT + tail


# --------------------------------------------------------------------------- #
# 统一分发
# --------------------------------------------------------------------------- #
def _dispatch_style(llm: dict) -> str:
    """把配置里的 api_style 归一成四个通路名。"""
    style = (llm.get("api_style") or "openai").strip().lower()
    if style in ("mock", "manual"):
        return MANUAL
    if style == "codebuddy":
        return "codebuddy"
    if style == "trae":
        return "trae"
    return "openai"


def chat(messages: list[dict], *, max_tokens: int = 2048,
         temperature: float | None = None) -> str:
    llm = config.resolve()
    style = _dispatch_style(llm)

    if style == MANUAL:
        return _manual_reply(messages)

    if style == "codebuddy" or style == "trae":
        # 本机通路走可选模块 localai；它被整个删掉时也要给可读的说明，而不是崩掉
        try:
            from app import localai
        except ImportError:
            raise LLMError("本机接入模块（localai.py）不在了：编辑与构建不受影响，"
                           "只是用不了本机编辑器的登录。可改用 OpenAI 兼容接口。") from None
        try:
            return localai.chat(style, messages, model=llm.get("model") or None,
                                max_tokens=max_tokens,
                                temperature=llm.get("temperature") if temperature is None else temperature)
        except RuntimeError as exc:
            raise LLMError(str(exc)) from exc

    # openai 兼容
    if not llm.get("configured"):
        raise LLMError(f"「{llm.get('label')}」还没有填 API Key。")
    body = {"model": llm["model"], "messages": messages, "max_tokens": max_tokens,
            "temperature": llm["temperature"] if temperature is None else temperature}
    try:
        text = request("POST", (llm.get("base_url") or "").rstrip("/") + "/chat/completions",
                       {"Authorization": f"Bearer {llm['api_key']}",
                        "Accept": "application/json"}, json_body=body, timeout=180)
    except HttpError as exc:
        raise LLMError(f"{llm['label']} 调用失败（HTTP {exc.status}）：{(exc.body or '')[:200]}") from exc
    try:
        data = json.loads(text)
        return data["choices"][0]["message"]["content"] or ""
    except (json.JSONDecodeError, KeyError, IndexError, TypeError) as exc:
        raise LLMError("模型返回格式异常") from exc


def stream(messages: list[dict], *, max_tokens: int = 2048) -> Iterator[str]:
    """统一流式：真实通路已有各自的流式实现，这里把统一结果切片推出，前端体验一致。"""
    text = chat(messages, max_tokens=max_tokens)
    step = 12
    for i in range(0, len(text), step):
        yield text[i:i + step]
