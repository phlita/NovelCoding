"""v3 文件系统：工程 + 公共库（双库），一切皆文件。

文件命名规范（中文后缀，直白可读）：
    条目名.大类.子类          例如：李三.人物.属性 / 试探.事件.逻辑 / 第01章.剧本.正文
    · 大类 / 子类 由下方 REGISTRY 注册表规定（改命名只改这里，不散落在代码里）
    · 条目名允许含「-」表示联合条目，例如：李三-赵爷.关系.关系网

文件内部规范：
    @ 开头的行 = 注释区（导演说明 / 出处 / 依赖），不进入正文，构建时忽略
    其余行     = 正文区（数据或剧本）

双库：
    library/            公共库：所有工程可调用；按大类分文件夹
    projects/<工程名>/  项目库：只有本工程调用；内含 src/ build/ state/
    传递：拉入（库→项目，记 from 来源） / 存入（项目→库，可泛化）
"""
from __future__ import annotations

import json
import re
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]          # v3/
PROJECTS = ROOT / "projects"
LIBRARY = ROOT / "library"
for _p in (PROJECTS, LIBRARY):
    _p.mkdir(parents=True, exist_ok=True)

# --------------------------------------------------------------------------- #
# 类型注册表：大类 → 子类 → 说明与模板。文件名后缀即「大类.子类」
# --------------------------------------------------------------------------- #
REGISTRY: dict[str, dict] = {
    "工程": {
        "清单": {"desc": "一个工程的总清单：元信息、包含文件、公共库引用",
                 "template": "@条目 工程清单\n书名 \n类型 \n一句话梗概 \n构建顺序 \n"},
    },
    "世界": {
        "规则": {"desc": "时代、法则、禁忌", "template": "@条目 世界规则\n时代 \n法则 \n禁忌 \n"},
        "语汇": {"desc": "本作专用词汇、称呼、行话", "template": "@条目 语汇\n" },
    },
    "人物": {
        "属性": {"desc": "人物静态属性：身份、年龄、气质等", "template": "@条目 人物\n@注释 \n身份 \n年龄 \n气质 \n缺陷 \n"},
        "状态": {"desc": "会变化的数值状态：戒备/好感/体力", "template": "@条目 人物状态\n@注释 格式：状态名 = 初值\n戒备 = 0\n好感 = 0\n"},
        "口癖": {"desc": "语域、口癖、只说、绝不说（人味经营区）", "template": "@条目 人物口癖\n语域 \n口癖 \n只说 \n绝不说 \n"},
        "知识": {"desc": "这个人物初始知道什么（知识边界）", "template": "@条目 人物知识\n@注释 一行一条；谁知道什么决定他能说什么\n"},
    },
    "关系": {
        "关系网": {"desc": "条目名写「甲-乙」，记录信任/亏欠/敌意及来源", "template": "@条目 关系\n甲-乙\n信任 = 0\n亏欠 = 0\n来源事件 \n"},
    },
    "地点": {
        "属性": {"desc": "地点布局、氛围、可发生的动作", "template": "@条目 地点\n氛围 \n布局 \n可发生 \n"},
    },
    "资产": {
        "道具": {"desc": "物品：归属、状态、可触发事件", "template": "@条目 道具\n归属 \n状态 \n可触发 \n"},
    },
    "时间线": {
        "节点": {"desc": "章节/场景节点与时序约束", "template": "@条目 时间线\n@注释 格式：节点名 | 时间 | 状态\n"},
    },
    "事件": {
        "逻辑": {"desc": "函数：前置条件 → 步骤 → 副作用 → 知识写入",
                 "template": "@条目 事件\n@前置 v.变量==初值\n@出场 \n@地点 \n@步骤 动作：\n@步骤 对白：\n@效果 s.人物.状态 += 1\n@揭示 人物：事实\n@钩子 \n"},
        "剧本": {"desc": "事件的镜头/对白写法（导演说明进注释区）",
                 "template": "@条目 事件剧本\n@导演 \n@镜头 \n> 动作\n「对白」\n（内心）\n"},
    },
    "变量": {
        "数值": {"desc": "全局计量状态：类型、初值、量纲", "template": "@条目 变量\n类型 数值\n初值 0\n量纲 \n说明 \n"},
        "开关": {"desc": "是/否类全局状态", "template": "@条目 变量\n类型 开关\n初值 否\n说明 \n"},
    },
    "决策": {
        "分支": {"desc": "选项条件 → 去向事件 → 各自后果（选项按序取第一个成立）",
                 "template": "@条目 决策\n问题 \n@选项 选项一 | 条件 | 去向事件\n@选项 选项二 | 条件 | 去向事件\n@默认 默认去向\n"},
    },
    "行为": {
        "习惯": {"desc": "可复用行为库：公有（人人可用）或专有（人物专属）",
                 "template": "@条目 行为习惯\n适用范围 公有\n触发条件 \n表现 \n"},
    },
    "文风": {
        "样式": {"desc": "本作的样式表（= CSS）：句长节奏、对话占比、口吻、禁用词",
                 "template": "@条目 文风\n视角 \n句长 \n对话占比 \n禁用词 \n"},
    },
    "剧本": {
        "正文": {"desc": "章节剧本：镜头/动作/对白 + @导演说明（注释区不进正文）",
                 "template": "@条目 章节剧本\n@章 第01章\n@导演 节奏慢，留白两拍\n@镜头 特写：\n> 动作\n「对白」\n（内心）\n@钩子 \n"},
    },
}


def registry_public() -> dict:
    return {cat: {"子类": list(subs.keys()),
                  "说明": {k: v["desc"] for k, v in subs.items()}}
            for cat, subs in REGISTRY.items()}


def cat_desc(cat: str) -> str:
    subs = REGISTRY.get(cat) or {}
    return "、".join(f"{k}（{v['desc']}）" for k, v in subs.items())


def template_for(cat: str, sub: str, name: str = "") -> str:
    item = (REGISTRY.get(cat) or {}).get(sub)
    if not item:
        return ""
    body = item["template"]
    if name:
        lines = body.splitlines()
        tag = {"工程": "工程清单", "世界": "世界规则", "人物": "人物", "关系": "关系",
               "地点": "地点", "资产": "道具", "时间线": "时间线", "事件": "事件",
               "变量": "变量", "决策": "决策", "行为": "行为习惯", "文风": "文风",
               "剧本": "章节剧本"}.get(cat, "")
        out = []
        for line in lines:
            if line.startswith("@条目"):
                out.append(f"@条目 {name}" if (not tag or tag in line or cat in ("人物", "事件")) else line)
            else:
                out.append(line)
        body = "\n".join(out)
    return body


# --------------------------------------------------------------------------- #
# 命名解析与校验
# --------------------------------------------------------------------------- #
class FsError(Exception):
    def __init__(self, detail: str, status: int = 400):
        super().__init__(detail)
        self.detail, self.status = detail, status


NAME_RE = re.compile(r"^[^\\/:*?\"<>|\n]{1,80}$")


def parse_filename(filename: str) -> dict:
    """解析 条目名.大类.子类 → {条目名, 大类, 子类, ok, why}。

    注意：文件名整体无扩展名概念（末段是子类），不能用 Path.stem。
    """
    stem = Path(filename).name
    parts = stem.split(".")
    if len(parts) < 3:
        return {"条目名": stem, "大类": "", "子类": "", "ok": False,
                "why": "文件名必须是「条目名.大类.子类」，例如 李三.人物.属性"}
    cat, sub = parts[-2], parts[-1]
    name = ".".join(parts[:-2])
    if cat not in REGISTRY:
        return {"条目名": name, "大类": cat, "子类": sub, "ok": False,
                "why": f"大类「{cat}」不在类型注册表里（可选：{'、'.join(REGISTRY)}）"}
    if sub not in REGISTRY[cat]:
        return {"条目名": name, "大类": cat, "子类": sub, "ok": False,
                "why": f"{cat} 类的子类「{sub}」不存在（可选：{'、'.join(REGISTRY[cat])}）"}
    if not NAME_RE.match(name):
        return {"条目名": name, "大类": cat, "子类": sub, "ok": False,
                "why": "条目名含有非法字符"}
    return {"条目名": name, "大类": cat, "子类": sub, "ok": True, "why": ""}


def entry_of(path: Path, scope: str, project: str = "") -> dict:
    info = parse_filename(path.name)
    return {"scope": scope, "project": project,
            "rel": _rel(path, scope, project),
            "name": path.name, "条目名": info["条目名"], "大类": info["大类"],
            "子类": info["子类"], "valid": info["ok"], "问题": info["why"],
            "size": path.stat().st_size if path.is_file() else 0}


# --------------------------------------------------------------------------- #
# 路径安全
# --------------------------------------------------------------------------- #
def _project_dir(project: str) -> Path:
    if not project or not NAME_RE.match(project):
        raise FsError("工程名不合法")
    return PROJECTS / project


def scope_root(scope: str, project: str = "") -> Path:
    if scope == "library":
        return LIBRARY
    if scope == "project":
        if not project:
            raise FsError("scope=project 时必须给 project")
        return _project_dir(project) / "src"
    if scope == "build":
        return _project_dir(project) / "build"
    raise FsError(f"未知 scope：{scope}")


def safe_path(scope: str, project: str, rel: str) -> Path:
    root = scope_root(scope, project).resolve()
    rel = (rel or "").replace("\\", "/").lstrip("/")
    if not rel:
        raise FsError("路径为空")
    target = (root / rel).resolve()
    if target != root and root not in target.parents:
        raise FsError("非法路径（越出库根目录）", 403)
    return target


def _rel(path: Path, scope: str, project: str) -> str:
    try:
        return path.resolve().relative_to(scope_root(scope, project).resolve()).as_posix()
    except ValueError:
        return path.name


# --------------------------------------------------------------------------- #
# 工程
# --------------------------------------------------------------------------- #
def list_projects() -> list[dict]:
    out = []
    for d in sorted(PROJECTS.iterdir() if PROJECTS.exists() else []):
        if not d.is_dir():
            continue
        src = d / "src"
        files = [f for f in src.rglob("*") if f.is_file()] if src.exists() else []
        out.append({"name": d.name, "files": len(files),
                    "bytes": sum(f.stat().st_size for f in files),
                    "has_build": any((d / "build").glob("*")) if (d / "build").exists() else False})
    return out


def create_project(name: str, 书名: str = "", 类型: str = "", 梗概: str = "") -> dict:
    name = (name or "").strip()
    if not NAME_RE.match(name):
        raise FsError("工程名不合法（不要用 \\ / : * ? \" < > |）")
    d = PROJECTS / name
    if d.exists():
        raise FsError(f"工程「{name}」已存在")
    (d / "src").mkdir(parents=True)
    (d / "build").mkdir(parents=True)
    (d / "state").mkdir(parents=True)
    novel = d / "src" / f"{name}.工程.清单"
    novel.write_text(template_for("工程", "清单", name)
                     .replace("书名 ", f"书名 {书名 or name}")
                     .replace("类型 ", f"类型 {类型}")
                     .replace("一句话梗概 ", f"一句话梗概 {梗概}"),
                     encoding="utf-8")
    return {"name": name, "dir": str(d)}


def delete_project(name: str):
    d = _project_dir(name)
    if not d.exists():
        raise FsError("工程不存在", 404)
    shutil.rmtree(d)


def rename_project(old: str, new: str):
    o, n = _project_dir(old), _project_dir(new)
    if not o.exists():
        raise FsError("工程不存在", 404)
    if n.exists():
        raise FsError("目标名字已被占用")
    o.rename(n)


# --------------------------------------------------------------------------- #
# 文件读写
# --------------------------------------------------------------------------- #
def read_file(scope: str, project: str, rel: str) -> dict:
    p = safe_path(scope, project, rel)
    if not p.is_file():
        raise FsError("文件不存在", 404)
    text = p.read_text(encoding="utf-8", errors="replace")
    info = entry_of(p, scope, project)
    head, notes, deps = split_regions(text)
    info.update({"content": text, "注释区": notes, "依赖": deps,
                 "类型说明": (REGISTRY.get(info["大类"], {}).get(info["子类"], {}) or {}).get("desc", "")})
    return info


DEP_RE = re.compile(r"^\s*@(导入|import|依赖|引用)\s+(.+?)\s*$", re.I)
META_RE = re.compile(r"^\s*@(来源|出处|from)\s+(.+?)\s*$", re.I)


def split_regions(text: str) -> tuple[str, list[str], list[str]]:
    """把文件分成 注释区（@ 行）与正文区，并抽出依赖。

    · @导入 / @import / @依赖   → 依赖（上方文件必须存在）
    · @来源 / @出处             → 元信息（记录从哪来，不算依赖）
    """
    notes, deps, body_lines = [], [], []
    for line in (text or "").splitlines():
        if line.lstrip().startswith("@"):
            notes.append(line.strip())
            m = DEP_RE.match(line)
            if m:
                deps.append(m.group(2).strip())
        else:
            body_lines.append(line)
    return "\n".join(body_lines), notes, deps


def write_file(scope: str, project: str, rel: str, content: str) -> dict:
    """保存（可新建）：文件名规范必须合法。

    build 作用域是**生成物**，禁止写入——要改就改条目文件再构建。
    """
    if scope == "build":
        raise FsError("构建产物是只读的生成物：请改条目文件（src/）后重新构建")
    info = parse_filename(Path(rel).name)
    if not info["ok"]:
        raise FsError(info["why"])
    p = safe_path(scope, project, rel)
    if p.is_dir():
        raise FsError("同名目录已存在")
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content if content is not None else "", encoding="utf-8")
    return read_file(scope, project, rel)


def new_file(scope: str, project: str, cat: str, sub: str, name: str) -> dict:
    if cat not in REGISTRY:
        raise FsError(f"大类「{cat}」不在注册表里")
    if sub not in REGISTRY[cat]:
        raise FsError(f"{cat} 类没有「{sub}」子类（可选：{'、'.join(REGISTRY[cat])}）")
    if not NAME_RE.match((name or "").strip()):
        raise FsError("条目名不合法")
    filename = f"{name.strip()}.{cat}.{sub}"
    root = scope_root(scope, project)
    folder = root if scope == "library" else root
    if scope == "library":
        folder = root / cat
    p = folder / filename
    if p.exists():
        raise FsError(f"文件已存在：{filename}")
    # 公共库按大类分文件夹；项目库 src/ 平铺（文件名自带类型）
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(template_for(cat, sub, name.strip()), encoding="utf-8")
    rel = _rel(p, scope, project)
    return read_file(scope, project, rel)


def rename_file(scope: str, project: str, rel: str, new_name: str) -> dict:
    p = safe_path(scope, project, rel)
    if not p.is_file():
        raise FsError("文件不存在", 404)
    if new_name.strip() == p.name:
        raise FsError("新名字与原名字相同")
    info = parse_filename(new_name.strip())
    if not info["ok"]:
        raise FsError(info["why"])
    target = p.parent / Path(new_name.strip()).name
    if target.exists():
        raise FsError("已存在同名文件")
    p.rename(target)
    return read_file(scope, project, _rel(target, scope, project))


def delete_file(scope: str, project: str, rel: str):
    p = safe_path(scope, project, rel)
    if not p.exists():
        raise FsError("文件不存在", 404)
    if p.is_dir():
        shutil.rmtree(p)
    else:
        p.unlink()


# --------------------------------------------------------------------------- #
# 双库传递
# --------------------------------------------------------------------------- #
def pull_from_library(project: str, rels: list[str], into: str = "", rename: str = "") -> list[dict]:
    """公共库 → 项目：复制（可改条目名），并在文件头写入 @来源 记录。"""
    out = []
    _project_dir(project)
    for rel in rels or []:
        src = safe_path("library", "", rel)
        if not src.is_file():
            raise FsError(f"公共库文件不存在：{rel}", 404)
        info = parse_filename(src.name)
        if not info["ok"]:
            raise FsError(f"公共库文件命名不合法：{src.name}（{info['why']}）")
        名 = (rename if (rename and len(rels) == 1) else info["条目名"])
        filename = f"{名}.{info['大类']}.{info['子类']}"
        target = scope_root("project", project) / (into.strip("/") if into else "") / filename
        target.parent.mkdir(parents=True, exist_ok=True)
        text = src.read_text(encoding="utf-8", errors="replace")
        if "@来源" not in text.splitlines()[0:6]:
            text = f"@来源 公共库/{rel}\n{text}"
        target.write_text(text, encoding="utf-8")
        out.append(read_file("project", project, _rel(target, "project", project)))
    return out


def promote_to_library(project: str, rel: str, name: str = "", generalize: bool = False) -> dict:
    """项目 → 公共库：沉淀可复用资产；泛化 = 把本工程专有名词换成占位符。"""
    src = safe_path("project", project, rel)
    if not src.is_file():
        raise FsError("项目文件不存在", 404)
    info = parse_filename(src.name)
    if not info["ok"]:
        raise FsError(f"文件命名不合法：{info['why']}")
    名 = (name or info["条目名"]).strip()
    text = src.read_text(encoding="utf-8", errors="replace")
    if generalize:
        text = generalize_text(text, project)
    folder = LIBRARY / info["大类"]
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / f"{名}.{info['大类']}.{info['子类']}"
    if target.exists():
        raise FsError(f"公共库里已有「{target.name}」，换个名字再存")
    head = [ln for ln in text.splitlines() if ln.lstrip().startswith(("@来源", "@出处"))]
    lines = text.splitlines()
    lines = [ln for ln in lines if not ln.lstrip().startswith(("@来源", "@出处"))]
    lines.insert(0, f"@出处 工程「{project}」/{rel}")
    target.write_text("\n".join(lines), encoding="utf-8")
    return read_file("library", "", _rel(target, "library", ""))


def generalize_text(text: str, project: str) -> str:
    """把本工程的人物名替换成占位符，便于公共复用。"""
    names = []
    src = scope_root("project", project)
    for f in src.rglob("*"):
        if f.is_file():
            info = parse_filename(f.name)
            if info["ok"] and info["大类"] == "人物":
                names.append(info["条目名"])
    out = text
    for i, nm in enumerate(sorted(set(names), key=len, reverse=True), start=1):
        out = out.replace(nm, "{{人物%d}}" % i)
    return out


# --------------------------------------------------------------------------- #
# 目录树
# --------------------------------------------------------------------------- #
def tree(project: str = "") -> dict:
    def walk(root: Path, scope: str, proj: str) -> list[dict]:
        items = []
        if not root.exists():
            return items
        for child in sorted(root.iterdir(), key=lambda x: (x.is_file(), x.name)):
            if child.name.startswith("."):
                continue
            if child.is_dir():
                items.append({"type": "dir", "name": child.name, "scope": scope,
                              "project": proj, "rel": _rel(child, scope, proj),
                              "children": walk(child, scope, proj)})
            else:
                e = entry_of(child, scope, proj)
                e["type"] = "file"
                items.append(e)
        return items

    return {
        "library": walk(LIBRARY, "library", ""),
        "project": {"name": project,
                    "src": walk(scope_root("project", project), "project", project) if project else [],
                    "build": walk(scope_root("build", project), "build", project) if project else []},
        "registry": registry_public(),
    }


def project_summary(project: str) -> dict:
    d = _project_dir(project)
    if not d.exists():
        raise FsError("工程不存在", 404)
    src = d / "src"
    files = [entry_of(f, "project", project) for f in sorted(src.rglob("*")) if f.is_file()]
    by_cat: dict[str, int] = {}
    for f in files:
        by_cat[f["大类"] or "未分类"] = by_cat.get(f["大类"] or "未分类", 0) + 1
    bad = [f for f in files if not f["valid"]]
    build = d / "build"
    outputs = [entry_of(f, "build", project) for f in sorted(build.glob("*")) if f.is_file()]
    return {"name": project, "files": files, "by_cat": by_cat, "invalid": bad,
            "outputs": outputs,
            "stats": {"files": len(files), "words": sum(f["size"] for f in files),
                      "invalid": len(bad), "outputs": len(outputs)}}


# --------------------------------------------------------------------------- #
# 入门工程（首次启动）
# --------------------------------------------------------------------------- #
MANUAL_PROJECT = "我的第一部小说"

_MANUAL_FILES: dict[str, str] = {
    "我的第一部小说.工程.清单": """@条目 我的第一部小说
@注释 这是手动编辑模式自带的入门工程。全部文件都可以直接改，改完点「构建」看结果。
书名 我的第一部小说
类型 悬疑
一句话梗概 一份字据引出的试探
@构建顺序
  第01章
""",

    "李三.人物.属性": """@条目 李三
@注释 静态属性：不改的那些。会变的数值写在 .人物.状态 里。
身份 当铺伙计（前仵作学徒）
年龄 23
气质 说话前先把手上的活停一下
缺陷 见血就晕
""",

    "李三.人物.状态": """@条目 李三
@注释 数值型状态：初值在这里给，运行中被事件的 @效果 改写。
戒备 = 0
胆量 = 4
""",

    "李三.人物.知识": """@条目 李三
@注释 这一栏决定他能说什么、不能说什么：只写他确实知道的事。
@知 柜台下沿的缺口是去年冬天一个醉汉用刀磕的
@知 赵爷认字据从来不用这么久
""",

    "赵爷.人物.属性": """@条目 赵爷
@注释 采自 .人物.属性 模板；改这几行就是在给人物定型。
身份 当铺掌柜
年龄 四十七
气质 先看东西再看人
""",

    "赵爷.人物.状态": """@条目 赵爷
戒备 = 0
胆量 = 6
""",

    "赵爷.人物.知识": """@条目 赵爷
@知 这张字据是假的，但字是李三写的
""",

    "当铺.地点.属性": """@条目 当铺
氛围 木头和旧纸的味道，冬天有煤炉的灰
布局 柜台高过人的腰，门帘是蓝布
可发生 验货，讲价，试探，翻脸
""",

    "字据在手.变量.开关": """@条目 字据在手
类型 开关
初值 是
说明 李三手里有没有那张字据
""",

    "人情债.变量.数值": """@条目 人情债
类型 数值
初值 0
说明 李三欠赵爷的人情，累加
""",

    "李三-赵爷.关系.关系网": """@条目 李三-赵爷
@注释 条目名就是甲-乙；下游用 r.李三-赵爷.信任 取数。
信任 = 2
亏欠 = 1
""",

    "试探.事件.逻辑": """@条目 试探
@前置 v.字据在手==1
@出场 李三 赵爷
@地点 当铺
@步骤 动作：李三把字据推到柜台上，手指还压着一角。
@步骤 对白：这纸是新写的，墨还没干透。
@步骤 内心：他在等赵爷认完的那一刻。
@效果 s.赵爷.戒备 += 2
@效果 v.字据在手 = 0
@效果 v.人情债 += 1
@揭示 李三：赵爷认这张纸比平常久
@钩子 赵爷会在天亮前先出牌
""",

    "摊牌.事件.逻辑": """@条目 摊牌
@前置 r.李三-赵爷.信任>=3
@出场 李三 赵爷
@地点 当铺
@步骤 对白：字据是假的，你也知道。
@效果 v.人情债 += 1
""",

    "查账.决策.分支": """@条目 查账
问题 要不要当面问？
@选项 直接问 | r.李三-赵爷.信任 >= 3 | 摊牌
@选项 忍着不问 | s.李三.胆量 >= 1 | 试探
@默认 试探
""",

    "冷硬语气.文风.样式": """@条目 冷硬语气
@注释 样式表 = CSS：逻辑不变，换个样式表就是另一种文风。
视角 贴身第三人称
句长 平均 14 字
对话占比 35%
禁用词 心头一紧 不易察觉 一丝
""",

    "第01章.剧本.正文": """@条目 第01章
@章 第一章 字据
@事件 试探
@决策 查账
@导演 前松后紧，最后一句留白
@镜头 特写：柜台上一道旧划痕
「掌柜的在吗？」
> 李三掀开门帘，风跟着进来。
> 赵爷没抬头，只把算盘往旁边挪了半寸。
@钩子 赵爷会在天亮前先出牌
""",
}


def ensure_manual_project() -> str | None:
    """首次启动时建一个入门工程，让手动模式一打开就有东西可看。

    幂等：工程已存在就什么都不做。返回新建的工程名，已存在则返回 None。
    """
    if (PROJECTS / MANUAL_PROJECT).exists():
        return None
    create_project(MANUAL_PROJECT, "我的第一部小说", "悬疑", "一份字据引出的试探")
    root = scope_root("project", MANUAL_PROJECT)
    for filename, body in _MANUAL_FILES.items():
        (root / filename).write_text(body.rstrip() + "\n", encoding="utf-8")
    return MANUAL_PROJECT
