"""拆解器：导入整本小说 → 拆成条目文件 → 新建工程。

设计原则（与 v3 的"小说即程序"一致）
--------------------------------------------------
1. 拆解 = 反向编译：把散文装回条目文件，目标是**忠实搬运**，不是改写。
   原文一律保留在 章节.剧本.正文 里；抽取出来的设定另存为 人物/地点/关系/事件/变量/决策/行为。
2. 两种抽取引擎，输出同一种结构（所以合并与落盘只有一套代码）：
   · 规则引擎：纯确定性，不需要模型。分章 → 分场 → 切对白/动作/内心 → 统计文风 →
     抽候选人物/地点 → 同场共现推关系。语义字段留空并标 @待补，不编造。
   · 模型引擎：逐章交给模型按 JSON 抽取（人物属性、事件步骤、效果、揭示、决策、变量），
     失败自动降级为规则引擎并在报告里记一笔。模型为 mock 时直接用规则引擎。
3. 合并是确定性的：同名条目合并、口癖取最短对白、公有/专有行为按"分布人数"判定、
   冲突不改写而是记进报告等人审。
"""
from __future__ import annotations

import json
import re
from collections import Counter, OrderedDict
from pathlib import Path

from app import files, llm

# --------------------------------------------------------------------------- #
# 常量
# --------------------------------------------------------------------------- #
CHAPTER_RE = re.compile(
    r"^\s*(?:正文\s*)?第\s*([0-9〇零一二三四五六七八九十百千两]{1,6})\s*"
    r"([章节回卷部篇])\s*[、:：.\-—]?\s*(.{0,40})$")

SPEAK_RE = re.compile(
    r"([\u4e00-\u9fa5]{2,4})(?:说道|说|道|问道|问|答|应声道|应|笑道|笑|喊道|喊|叫道|叫|骂道|骂|叹了口气|叹了口气说)")
TITLE_WORD_RE = re.compile(
    r"([\u4e00-\u9fa5]{1,4})(爷|哥|姐|娘|婶|掌柜|先生|大人|大夫|老板|师父|师傅|公子|姑娘)")
PLACE_SUFFIX = ("当铺", "药铺", "茶馆", "客栈", "码头", "铺", "馆", "堂", "巷", "街", "院", "楼",
                "庄", "店", "局", "房", "屋", "城", "山", "寺", "庙", "桥")
PLACE_PART = set("的了在到从回进出往向这那和与把被给又也便就都才着过一两三几好些个不没")
QUOTE_RE = re.compile(r"[「“](.+?)[」”]")
MIND_RE = re.compile(r"(?:(?:他|她|我)[^。！？]{0,6}(?:心想|暗想|心说|寻思|琢磨|意识到|觉得|盘算)|"
                     r"(?:心里|念头|只觉|大概|只怕|似乎明白)[^。！？]{0,12})")

# 常见姓氏：姓名首字是姓氏 + 后续字不含虚词，才当人名候选
SURNAMES = set("李王张刘陈杨黄赵吴周徐孙马朱胡郭何高林罗郑梁谢宋唐许韩冯邓曹彭曾肖田董袁潘于蒋蔡余杜叶程苏魏吕"
               "丁任沈姚卢姜崔钟谭陆汪范金石廖贾夏韦付方白邹孟熊秦邱江尹薛闫段雷侯龙史陶黎贺顾毛郝龚邵万钱严覃武"
               "戴莫孔向汤范贺")
# 虚词/助词：出现在"姓"后面的姓名里就判为噪声
FUNCCH = set("的了是不我你他她们在有就也都还只能会没和与这那上下里外个些么什怎为因所但而且或把被给让从向对"
             "跟比如若虽则即便又再很太更最都")
# 正文里的泛称（真名未给出），单独标注，等人审
GENERIC = set("那人 这人 此人 来人 年轻人 中年人 老人 男人 女人 大爷 大哥 大姐 小哥 对方 众人 有人 "
              "外面的人 门口的人 屋里的人".split())


# 常见词，排除出"人名"候选
STOP = set("""他们 她们 我们 你们 咱们 自己 别人 大家 什么 怎么 这样 那样 这个 那个 这里 那里 这时 那时
一个 一下 一边 一起 一样 一直 已经 因为 所以 但是 可是 不过 就是 还是 或者 而且 然后 接着 于是 结果 时候
东西 事情 地方 心里 眼里 脸上 手上 身上 脚下 身后 前面 后面 上面 下面 里面 外面 旁边 对面 远处 眼前 周围
声音 眼神 语气 表情 目光 神色 力气 意思 主意 办法 道理 事情 问题 样子 模样 感觉 喜欢 知道 觉得 看着 听着
说着 笑着 站着 坐着 起来 出来 回来 过来 过去 出来 下来 上来 打开 放下 拿起 转身 点头 摇头 抬手 低头
先生 大人 大夫 老板 师父 师傅 姑娘 公子 掌柜 伙计 客人 隔壁 有人 没人 一声 一下 一半 一点 多少 几个 两个
""".split())


def _clean_name(name: str, limit: int = 24) -> str:
    """条目名清洗：去掉不能做文件名的字符，限长。"""
    name = re.sub(r"[\\/:*?\"<>|\r\n\t]", "", (name or "").strip())
    name = re.sub(r"\s+", "", name)
    return name[:limit]


# --------------------------------------------------------------------------- #
# 一、分章
# --------------------------------------------------------------------------- #
def split_chapters(text: str, max_chapters: int = 0) -> list[dict]:
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    lines = text.split("\n")
    marks: list[tuple[int, str, str]] = []
    for i, line in enumerate(lines):
        m = CHAPTER_RE.match(line.strip())
        if m:
            marks.append((i, line.strip()[:40], m.group(3).strip()))
    chapters: list[dict] = []
    if len(marks) >= 2:
        # 卷首（第一章之前）如果有正文，作为"序"保留
        if marks[0][0] > 0 and "".join(lines[:marks[0][0]]).strip():
            chapters.append({"标题": "序", "正文": "\n".join(lines[:marks[0][0]]).strip()})
        for idx, (line_no, title, _) in enumerate(marks):
            end = marks[idx + 1][0] if idx + 1 < len(marks) else len(lines)
            body = "\n".join(lines[line_no + 1:end]).strip()
            chapters.append({"标题": title, "正文": body})
    else:
        paras = [p for p in re.split(r"\n\s*\n", text) if p.strip()]
        buf, size = [], 0
        for p in paras:
            buf.append(p)
            size += len(p)
            if size >= 3000:
                chapters.append({"标题": "", "正文": "\n\n".join(buf)})
                buf, size = [], 0
        if buf:
            chapters.append({"标题": "", "正文": "\n\n".join(buf)})
    if not chapters:
        chapters = [{"标题": "", "正文": text.strip()}]
    for i, ch in enumerate(chapters, start=1):
        ch["序"] = i
        ch["编号"] = f"第{i:02d}章" if len(chapters) > 1 else "第01章"
        ch["字数"] = len(re.sub(r"\s", "", ch["正文"]))
    if max_chapters and max_chapters > 0:
        chapters = chapters[:max_chapters]
    return chapters


def preview(text: str, max_chapters: int = 0) -> dict:
    chapters = split_chapters(text, max_chapters)
    return {"章节": [{"序": c["序"], "编号": c["编号"], "标题": c["标题"], "字数": c["字数"],
                      "开头": c["正文"][:60]} for c in chapters],
            "统计": {"章节数": len(chapters),
                      "总字数": sum(c["字数"] for c in chapters),
                      "对话行数": len(QUOTE_RE.findall(text or ""))},
            "章节判定": "识别到「第X章」格式" if len(chapters) > 1 else "未识别章节标记，按长度切块"}


# --------------------------------------------------------------------------- #
# 二、规则引擎（确定性）
# --------------------------------------------------------------------------- #
def _paragraphs(body: str) -> list[str]:
    return [p.strip() for p in re.split(r"\n\s*\n|\n", body or "") if p.strip()]


def classify(para: str) -> tuple[str, str]:
    """段落分类：对白 / 内心 / 动作。"""
    if QUOTE_RE.search(para):
        return "对白", para
    if MIND_RE.search(para):
        return "内心", para
    return "动作", para


def scenes(paras: list[str], per_scene: int = 14) -> list[list[str]]:
    """分场：优先在时间/地点提示句断开，其次按段数切。"""
    cue = re.compile(r"^(?:翌日|次日|第二天|当日|当晚|那天|这日|这天|入夜|夜里|深夜|清早|一早|清晨|晌午|"
                     r"午后|傍晚|黄昏|片刻后|半晌|不多时|与此同时|话分两头|另一边|三日后|数日后)")
    out, cur = [], []
    for p in paras:
        if cur and (len(cur) >= per_scene or (cue.match(p) and len(cur) >= 3)):
            out.append(cur)
            cur = []
        cur.append(p)
    if cur:
        out.append(cur)
    return out


def _sentences(body: str) -> list[str]:
    return [s for s in re.split(r"(?<=[。！？…」])", body or "") if s.strip()]


def style_stats(text: str) -> dict:
    body = re.sub(r"\s", "", text or "")
    sents = _sentences(re.sub(r"\s+", "", text or ""))
    lens = [len(s) for s in sents if len(s) > 1]
    quotes = QUOTE_RE.findall(text or "")
    total = max(len(body), 1)
    quote_chars = sum(len(q) for q in quotes)
    grams = Counter()
    for i in range(len(body) - 1):
        g = body[i:i + 2]
        if re.match(r"^[\u4e00-\u9fa5]{2}$", g):
            grams[g] += 1
    return {"平均句长": round(sum(lens) / len(lens), 1) if lens else 0,
            "最长句": max(lens) if lens else 0,
            "对话占比": f"{round(quote_chars / total * 100)}%",
            "句数": len(lens),
            "高频词": [w for w, _ in grams.most_common(40)][:24]}


COMPOUND = {"欧阳", "司马", "上官", "诸葛", "慕容", "令狐", "东方", "独孤", "南宫", "西门",
            "夏侯", "皇甫", "尉迟", "公孙", "长孙", "宇文", "司徒", "端木"}
NICK_PREFIX = set("阿小老大")
TITLE_SUFFIX = set("爷哥姐娘婶婆叔姨嫂")


def _plausible_name(name: str, strong: bool, title: bool = False) -> bool:
    """人名可信度判定。

    放行条件（任一，全部确定性）：
      · 泛称表命中（那人 / 来人 …）—— 保留但会标注待人审
      · 以称呼结尾（三爷 / 张哥 / 掌柜）
      · 姓氏开头且后续字不是虚词（李三 / 赵爷 / 欧阳锋）
      · 昵称前缀（阿 / 小 / 老 / 大）+ 非虚词（阿珍 / 小满）
      · 强证据（说话归属）+ 3 字以上且不含虚词
    """
    if name in GENERIC:
        return True
    if not (2 <= len(name) <= 4):
        return False
    if name[-1] in TITLE_SUFFIX:
        return True
    if name[:2] in COMPOUND:
        return all(c not in FUNCCH for c in name[2:]) and len(name) >= 3
    if name[0] in SURNAMES:
        return all(c not in FUNCCH for c in name[1:])
    if name[0] in NICK_PREFIX and all(c not in FUNCCH for c in name[1:]):
        return True
    return bool(strong and len(name) >= 3 and all(c not in FUNCCH for c in name[1:]))


def _candidates(chapter: dict) -> dict:
    """一章里抽候选人物 / 地点，带证据。

    三步（全部确定性）：
      1. 强证据：说话归属（X说/X道）+ 称呼（X爷/X掌柜）→ 种子集合
      2. 弱证据：对白前紧邻的名词，只在"姓氏+非虚词"时才收
      3. 计数：拿种子在正文里数出现次数，取前 12 名
    """
    paras = _paragraphs(chapter["正文"])
    body = chapter["正文"]
    strong: Counter = Counter()
    weak: Counter = Counter()
    for para in paras:
        for s in _sentences(para):
            for m in SPEAK_RE.finditer(s):
                nm = m.group(1)
                if nm not in STOP:
                    strong[nm] += 1
            for m in TITLE_WORD_RE.finditer(s):
                nm = m.group(1) + m.group(2)
                if m.group(1) and m.group(1) not in STOP:
                    strong[nm] += 1
            for q in QUOTE_RE.finditer(s):
                head = s[:q.start()]
                m = re.search(r"([\u4e00-\u9fa5]{2,4})[^，。！？：]{0,6}$", head)
                if m and m.group(1) not in STOP:
                    weak[m.group(1)] += 1

    seeds: set[str] = {n for n in strong if _plausible_name(n, True)}
    for n, c in weak.items():
        if _plausible_name(n, False) and (c >= 1 or n in GENERIC):
            seeds.add(n)

    counts = {n: len(re.findall(re.escape(n), body)) for n in seeds}
    persons = {n: c for n, c in counts.items()
               if (n in strong and c >= 2) or (n in GENERIC and c >= 2) or c >= 3}
    persons = dict(sorted(persons.items(), key=lambda kv: -kv[1])[:12])

    evidence: dict[str, list[str]] = {}
    for n in persons:
        for s in _sentences(body):
            if n in s:
                evidence.setdefault(n, []).append(s.strip()[:80])
                if len(evidence[n]) >= 3:
                    break

    places = _canon_merge(_place_candidates(body))
    places = {n: c for n, c in places.items() if c >= 2}
    pev = {n: [_first_sentence_with(body, n)] for n in places}
    places = dict(sorted(places.items(), key=lambda kv: -kv[1])[:8])
    return {"人物": persons, "人物证据": evidence, "地点": places, "地点证据": pev,
            "泛称": [n for n in persons if n in GENERIC],
            "称呼型": [n for n in persons if n not in GENERIC and n[-1] in TITLE_SUFFIX]}


def _canon_merge(items: list[str]) -> Counter:
    """把"多余前缀"的候选并到最短后缀上："我想请当铺" → "当铺"。"""
    raw = Counter(items)
    canon: Counter = Counter()
    keys = [k for k in raw if len(k) >= 2]
    for nm, c in raw.items():
        base = ""
        for other in keys:
            if other != nm and len(other) < len(nm) and nm.endswith(other):
                if len(other) > len(base):
                    base = other
        canon[base or nm] += c
    return canon


def _place_candidates(body: str) -> list[str]:
    """地点候选：抓"地名后缀"，再向左吃 1~3 个非虚词汉字（遇到虚词/标点就停）。

    这样 "城南的当铺" → 当铺；"旧式巷道" → 旧式巷道；"后巷" → 后巷。
    """
    found: list[str] = []
    pat = re.compile("|".join(re.escape(s) for s in PLACE_SUFFIX))
    for m in pat.finditer(body or ""):
        i, j = m.start(), m.start()
        while j > 0 and i - j < 3:
            c = body[j - 1]
            if c in PLACE_PART or not re.match(r"[\u4e00-\u9fa5]", c):
                break
            j -= 1
        nm = body[j:m.end()]
        if len(nm) < 2:          # 单字（如"铺""巷"）不算地名，避免噪声
            continue
        if nm and nm not in STOP:
            found.append(nm)
    return found


def _first_sentence_with(body: str, needle: str) -> str:
    for s in _sentences(body):
        if needle in s:
            return s.strip()[:80]
    return ""


def rules_extract(chapter: dict) -> dict:
    """规则抽取：只给确定性可得的东西，语义字段一律留空待补。"""
    paras = _paragraphs(chapter["正文"])
    cand = _candidates(chapter)
    blocks = scenes(paras)
    lines: list[tuple[str, str]] = []
    for block in blocks:
        for p in block:
            lines.append(classify(p))
    quotes = [t for k, t in lines if k == "对白"]
    speaks = {}
    for para in paras:
        for s in _sentences(para):
            for m in SPEAK_RE.finditer(s):
                if m.group(1) in cand["人物"]:
                    speaks.setdefault(m.group(1), [])
                    if len(speaks[m.group(1)]) < 3:
                        speaks[m.group(1)].append(s.strip()[:80])
    events = [{"名": f"{chapter['编号']}-主线", "步骤": [f"动作：{t[:60]}" for k, t in lines if k == "动作"][:3],
               "对白": [t[:60] for k, t in lines if k == "对白"][:3],
               "出场": list(cand["人物"])[:6], "地点": list(cand["地点"])[:3],
               "证据": [p[:80] for p in paras[:2]]}]
    place_guess = next(iter(cand["地点"]), "")
    director = (f"本章 {len(paras)} 段 / 分 {len(blocks)} 场 / 对白 {len(quotes)} 处；"
                f"建议：{('对白密集，注意给动作留白' if len(quotes) > len(paras) * 0.4 else '叙述为主，把关键动作写具体')}")
    return {"人物": {n: {"证据": cand["人物证据"].get(n, []), "对白样本": speaks.get(n, [])}
                    for n in cand["人物"]},
            "地点": {n: {"证据": cand["地点证据"].get(n, [])} for n in cand["地点"]},
            "事件": events,
            "变量": {}, "决策": {}, "行为": {},
            "剧本": {"导演": director,
                     "镜头": [f"特写：{_noun_hint(paras[0])}"] if paras else [],
                     "分镜": [(k, t) for k, t in lines],
                     "出场": list(cand["人物"])[:6], "地点": place_guess},
            "文风": {chapter["编号"]: style_stats(chapter["正文"])},
            "引擎": "规则",
            "泛称": cand.get("泛称", []), "称呼型": cand.get("称呼型", []),
            "待补": ["人物属性（身份/年龄/气质/缺陷）", "资产·道具", "全局变量", "决策分支", "行为习惯"]}


def _noun_hint(para: str) -> str:
    m = re.search(r"([\u4e00-\u9fa5]{1,6}(?:据|契|信|刀|灯|酒|茶|账|钥|印|牌|票|钱|银|绳|锁|图|纸))", para or "")
    return m.group(1) if m else (para or "")[:12]


# --------------------------------------------------------------------------- #
# 三、模型引擎（结构化 JSON，失败降级）
# --------------------------------------------------------------------------- #
AI_PROMPT = (Path(__file__).resolve().parent / "prompts" / "decompose_chapter.md")

AI_SYSTEM = ("你是小说结构拆解器。只做抽取，不改写、不续写、不评价。"
             "严格输出 JSON，不要任何解释文字、不要 Markdown 代码块围栏。")


def _parse_json(text: str) -> dict:
    raw = (text or "").strip()
    raw = re.sub(r"^```(?:json)?|```$", "", raw, flags=re.M).strip()
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        pass
    start, end = raw.find("{"), raw.rfind("}")
    if 0 <= start < end:
        try:
            return json.loads(raw[start:end + 1])
        except json.JSONDecodeError:
            pass
    raise ValueError("模型未按要求输出 JSON")


def _norm_list(v) -> list:
    if v is None:
        return []
    if isinstance(v, list):
        return v
    return [v]


def _norm_str(v) -> str:
    if isinstance(v, str):
        return v.strip()
    if isinstance(v, (int, float, bool)):
        return str(v)
    if isinstance(v, dict):
        return "；".join(f"{k}：{_norm_str(x)}" for k, x in v.items())
    if isinstance(v, list):
        return "；".join(_norm_str(x) for x in v)
    return ""


def ai_extract(chapter: dict, *, use_model: bool) -> dict:
    if not use_model:
        return rules_extract(chapter)
    cur = llm.provider_info()
    if cur.get("api_style") == "mock":
        out = rules_extract(chapter)
        out["引擎"] = "规则（手动模式：未接入 AI）"
        return out
    tpl = AI_PROMPT.read_text(encoding="utf-8")
    prompt = (tpl.replace("{{编号}}", chapter["编号"]).replace("{{标题}}", chapter["标题"] or "")
              .replace("{{正文}}", chapter["正文"][:12000]))
    try:
        reply = llm.chat([{"role": "system", "content": AI_SYSTEM},
                          {"role": "user", "content": prompt}], max_tokens=3000)
        data = _parse_json(reply)
    except Exception as exc:  # noqa: BLE001  —— 模型不可用 / 输出不合规，降级
        out = rules_extract(chapter)
        out["引擎"] = f"规则（模型抽取失败自动降级：{exc}）"
        return out
    return _normalize_ai(data, chapter)


def _normalize_ai(data: dict, chapter: dict) -> dict:
    rules = rules_extract(chapter)          # 分镜/统计永远走确定性，模型只补语义
    persons: dict[str, dict] = {}
    for item in _norm_list(data.get("人物")):
        if isinstance(item, str):
            item = {"名": item}
        if not isinstance(item, dict):
            continue
        nm = _clean_name(_norm_str(item.get("名") or item.get("名称") or item.get("name")))
        if not nm:
            continue
        info = persons.setdefault(nm, {"属性": {}, "证据": [], "对白样本": []})
        for key in ("身份", "年龄", "气质", "缺陷", "语域", "口癖", "只说", "绝不说"):
            val = _norm_str(item.get(key))
            if val:
                info["属性"][key] = val
        b = item.get("属性") or item.get("attributes")
        if isinstance(b, dict):
            for k, v in b.items():
                if _norm_str(v):
                    info["属性"][_norm_str(k)] = _norm_str(v)
        for e in _norm_list(item.get("证据") or item.get("原文")):
            if _norm_str(e):
                info["证据"].append(_norm_str(e)[:80])
    for nm, info in persons.items():
        if nm in rules["人物"]:
            info["对白样本"] = rules["人物"][nm]["对白样本"]
            info["证据"] = info["证据"] or rules["人物"][nm]["证据"]

    places: dict[str, dict] = {}
    for item in _norm_list(data.get("地点")):
        if isinstance(item, str):
            item = {"名": item}
        if not isinstance(item, dict):
            continue
        nm = _clean_name(_norm_str(item.get("名") or item.get("名称")))
        if not nm:
            continue
        info = places.setdefault(nm, {"氛围": "", "布局": "", "可发生": [], "证据": []})
        info["氛围"] = info["氛围"] or _norm_str(item.get("氛围"))
        info["布局"] = info["布局"] or _norm_str(item.get("布局"))
        for x in _norm_list(item.get("可发生") or item.get("事件")):
            if _norm_str(x):
                info["可发生"].append(_norm_str(x))
        for e in _norm_list(item.get("证据")):
            if _norm_str(e):
                info["证据"].append(_norm_str(e)[:80])

    events = []
    for item in _norm_list(data.get("事件")):
        if isinstance(item, str):
            item = {"名": item}
        if not isinstance(item, dict):
            continue
        nm = _clean_name(_norm_str(item.get("名") or item.get("名称"))) or f"{chapter['编号']}-事件"
        events.append({"名": nm,
                       "前置": _norm_str(item.get("前置") or item.get("条件")),
                       "出场": [_c for _c in (_clean_name(_norm_str(x)) for x in _norm_list(item.get("出场") or item.get("角色"))) if _c],
                       "地点": _clean_name(_norm_str(item.get("地点"))),
                       "步骤": [_norm_str(x)[:80] for x in _norm_list(item.get("步骤")) if _norm_str(x)],
                       "效果": [_norm_str(x)[:80] for x in _norm_list(item.get("效果") or item.get("副作用")) if _norm_str(x)],
                       "揭示": [_norm_str(x)[:80] for x in _norm_list(item.get("揭示") or item.get("知识")) if _norm_str(x)],
                       "钩子": _norm_str(item.get("钩子"))[:80],
                       "证据": [_norm_str(x)[:80] for x in _norm_list(item.get("证据")) if _norm_str(x)]})
    if not events:
        events = rules["事件"]

    variables = {}
    for item in _norm_list(data.get("变量")):
        if isinstance(item, str):
            item = {"名": item}
        if not isinstance(item, dict):
            continue
        nm = _clean_name(_norm_str(item.get("名") or item.get("名称")))
        if nm:
            variables[nm] = {"类型": _norm_str(item.get("类型")) or "数值",
                             "初值": _norm_str(item.get("初值")) or "0",
                             "量纲": _norm_str(item.get("量纲")), "说明": _norm_str(item.get("说明"))}

    decisions = {}
    for item in _norm_list(data.get("决策")):
        if isinstance(item, str):
            item = {"名": item}
        if not isinstance(item, dict):
            continue
        nm = _clean_name(_norm_str(item.get("名") or item.get("问题") or item.get("名称")))
        if nm:
            decisions[nm] = {"问题": _norm_str(item.get("问题")),
                             "选项": [_norm_str(x)[:80] for x in _norm_list(item.get("选项")) if _norm_str(x)],
                             "证据": [_norm_str(x)[:80] for x in _norm_list(item.get("证据")) if _norm_str(x)]}

    behaviors = {}
    for item in _norm_list(data.get("行为") or data.get("行为习惯")):
        if isinstance(item, str):
            item = {"名": item}
        if not isinstance(item, dict):
            continue
        nm = _clean_name(_norm_str(item.get("名") or item.get("名称")))
        if nm:
            behaviors[nm] = {"归属": [_c for _c in (_clean_name(_norm_str(x)) for x in _norm_list(item.get("归属") or item.get("角色"))) if _c],
                             "触发": _norm_str(item.get("触发") or item.get("触发条件")),
                             "表现": _norm_str(item.get("表现")),
                             "证据": [_norm_str(x)[:80] for x in _norm_list(item.get("证据")) if _norm_str(x)]}

    relations = []
    for item in _norm_list(data.get("关系")):
        if isinstance(item, dict):
            a, b = _clean_name(_norm_str(item.get("甲"))), _clean_name(_norm_str(item.get("乙")))
            if a and b:
                relations.append({"甲": a, "乙": b, "信任": _norm_str(item.get("信任")),
                                  "亏欠": _norm_str(item.get("亏欠")),
                                  "来源事件": _norm_str(item.get("来源事件") or item.get("来源"))})

    script = rules["剧本"]
    ai_script = data.get("剧本") or data.get("本章剧本") or {}
    if isinstance(ai_script, dict):
        script = {"导演": _norm_str(ai_script.get("导演")) or script["导演"],
                  "镜头": [_norm_str(x)[:60] for x in _norm_list(ai_script.get("镜头")) if _norm_str(x)] or script["镜头"],
                  "分镜": script["分镜"], "出场": script["出场"], "地点": script["地点"]}

    return {"人物": persons or rules["人物"], "地点": places or rules["地点"], "事件": events,
            "变量": variables, "决策": decisions, "行为": behaviors, "关系": relations,
            "剧本": script, "文风": {chapter["编号"]: style_stats(chapter["正文"])},
            "引擎": "模型", "待补": []}


# --------------------------------------------------------------------------- #
# 四、合并与落盘（确定性）
# --------------------------------------------------------------------------- #
def _write(project: str, filename: str, content: str) -> None:
    info = files.parse_filename(filename)
    if not info["ok"]:
        raise files.FsError(f"拆解产生了不合规文件名：{filename}（{info['why']}）")
    p = files.scope_root("project", project) / filename
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content.rstrip() + "\n", encoding="utf-8")


def chapter_script_text(chapter: dict, ex: dict) -> str:
    sc = ex.get("剧本") or {}
    head = [f"@条目 {chapter['编号']}"]
    if chapter["标题"]:
        head.append(f"@章 {chapter['标题']}")
    head.append(f"@来源 原文拆解")
    if sc.get("导演"):
        head.append(f"@导演 {sc['导演']}")
    for shot in sc.get("镜头") or []:
        head.append(f"@镜头 {shot}")
    if sc.get("出场"):
        head.append(f"@出场 {' '.join(sc['出场'])}")
    if sc.get("地点"):
        head.append(f"@地点 {sc['地点']}")
    head.append("@注释 分镜由原文逐段切分而来：> 动作与叙述 / 「对白」 / （内心）；原文一字未删")
    body: list[str] = []
    for kind, text in sc.get("分镜") or []:
        if kind == "内心":
            body.append(f"（{text}）")
            continue
        for seg_kind, seg in _flatten(text):
            body.append(f"「{seg}」" if seg_kind == "对白" else f"> {seg}")
    hook = (chapter["正文"].strip().split("\n")[-1] or "")[:40]
    if hook:
        head.append(f"@钩子 {hook}")
    return "\n".join(head) + "\n\n" + "\n".join(body)


def _flatten(text: str) -> list[tuple[str, str]]:
    """把一段文字切成 (动作|对白) 片段，**保留全部原文**（不做删改）。"""
    text = (text or "").strip()
    if not text:
        return []
    out: list[tuple[str, str]] = []
    pos = 0
    for m in QUOTE_RE.finditer(text):
        seg = text[pos:m.start()].strip()
        if seg:
            out.append(("动作", seg))
        out.append(("对白", m.group(1)))
        pos = m.end()
    tail = text[pos:].strip()
    if tail:
        out.append(("动作", tail))
    return out or [("动作", text)]


def event_text(chapter: dict, ev: dict) -> str:
    lines = [f"@条目 {ev['名']}", f"@来源 {chapter['编号']} 拆解"]
    if ev.get("前置"):
        lines.append(f"@前置 {ev['前置']}")
    for c in ev.get("出场") or []:
        lines.append(f"@出场 {c}")
    if ev.get("地点"):
        lines.append(f"@地点 {ev['地点']}")
    for s in ev.get("步骤") or []:
        lines.append(f"@步骤 {s}")
    for s in ev.get("效果") or []:
        lines.append(f"@效果 {s}")
    for s in ev.get("揭示") or []:
        lines.append(f"@揭示 {s}")
    if ev.get("钩子"):
        lines.append(f"@钩子 {ev['钩子']}")
    if not (ev.get("效果") or ev.get("揭示")):
        lines.append("@待补 因果：这一事件改变了什么状态 / 谁知道了什么（需人审或模型）")
    for e in ev.get("证据") or []:
        lines.append(f"@证据 {e}")
    return "\n".join(lines)


def person_text(name: str, info: dict) -> str:
    lines = [f"@条目 {name}", f"@来源 原文拆解"]
    if info.get("泛称"):
        lines.append("@待审 泛称角色（正文没给名字），可能和某个具名角色是同一人，需要合并或改名")
    if info.get("称谓"):
        lines.append("@待审 这是称呼式条目（如 三爷/掌柜），可能和某个具名角色是同一人")
    for e in info.get("证据", [])[:3]:
        lines.append(f"@证据 {e}")
    for chapter_no in info.get("章", []):
        lines.append(f"@出场 {chapter_no}")
    if info.get("公有行为"):
        lines.append(f"@导入 {' '.join(info['公有行为'])}")
    attrs = info.get("属性") or {}
    for key in ("身份", "年龄", "气质", "缺陷"):
        lines.append(f"{key} {attrs.get(key, '')}".rstrip() + ("　@待补" if not attrs.get(key) else ""))
    for key, val in attrs.items():
        if key not in ("身份", "年龄", "气质", "缺陷"):
            lines.append(f"{key} {val}")
    return "\n".join(lines)


def person_quirk_text(name: str, info: dict) -> str:
    lines = [f"@条目 {name}", "@来源 原文拆解（从对白样本反推，待人审）"]
    samples = [s for s in info.get("对白样本", []) if len(s) <= 40][:3]
    for s in samples:
        lines.append(f"@样本 {s}")
    lines.append("语域 　@待补")
    lines.append("口癖 　@待补")
    lines.append("只说 　@待补")
    lines.append("绝不说 　@待补")
    return "\n".join(lines)


def person_knowledge_text(name: str, info: dict) -> str:
    lines = [f"@条目 {name}", "@来源 原文拆解"]
    lines.append("@注释 这一栏决定他能说什么、不能说什么；拆解只能给线索，需人审")
    for k in info.get("知识", []):
        lines.append(k)
    if not info.get("知识"):
        lines.append("@待补 知识边界")
    return "\n".join(lines)


def place_text(name: str, info: dict) -> str:
    lines = [f"@条目 {name}", "@来源 原文拆解"]
    for e in info.get("证据", [])[:2]:
        lines.append(f"@证据 {e}")
    for chapter_no in info.get("章", []):
        lines.append(f"@出场 {chapter_no}")
    lines.append(f"氛围 {info.get('氛围') or '　@待补'}")
    lines.append(f"布局 {info.get('布局') or '　@待补'}")
    can = info.get("可发生") or []
    lines.append("可发生 " + (" / ".join(can) if can else "　@待补"))
    return "\n".join(lines)


def relation_text(a: str, b: str, info: dict) -> str:
    lines = [f"@条目 {a}-{b}", "@注释 关系网条目", f"{a}-{b}"]
    lines.append(f"信任 {info.get('信任') or '　@待补'}")
    lines.append(f"亏欠 {info.get('亏欠') or '　@待补'}")
    for chapter_no in info.get("章", []):
        lines.append(f"@同场 {chapter_no}")
    for e in info.get("证据", [])[:2]:
        lines.append(f"@证据 {e}")
    src = info.get("来源事件")
    if src:
        lines.append(f"来源事件 {src}")
    return "\n".join(lines)


def behavior_text(name: str, info: dict) -> str:
    lines = [f"@条目 {name}", f"@来源 {'原文拆解' if info.get('来源') != '原文拆解' else '原文拆解'}"]
    pure = info.get("归属") or []
    scope = "公有" if info.get("公有") or not pure else "专有"
    lines.append(f"适用范围 {scope}" + (f"（归属：{'、'.join(pure)}）" if scope == "专有" else ""))
    lines.append(f"触发条件 {info.get('触发') or '　@待补'}")
    lines.append(f"表现 {info.get('表现') or '　@待补'}")
    for e in info.get("证据", [])[:2]:
        lines.append(f"@证据 {e}")
    return "\n".join(lines)


def variable_text(name: str, info: dict) -> str:
    return "\n".join([f"@条目 {name}", "@来源 原文拆解", f"类型 {info.get('类型') or '数值'}",
                      f"初值 {info.get('初值') or '0'}", f"量纲 {info.get('量纲') or '　@待补'}",
                      f"说明 {info.get('说明') or '　@待补'}"])


def decision_text(name: str, info: dict) -> str:
    lines = [f"@条目 {name}", "@来源 原文拆解", f"问题 {info.get('问题') or name}"]
    for opt in info.get("选项") or []:
        lines.append(f"@选项 {opt}")
    lines.append("@默认 　@待补")
    for e in info.get("证据", [])[:2]:
        lines.append(f"@证据 {e}")
    return "\n".join(lines)


def style_text(project: str, stats: dict, engines: dict) -> str:
    agg = list(stats.values())
    avg = round(sum(s["平均句长"] for s in agg) / len(agg), 1) if agg else 0
    ratios = []
    for s in agg:
        try:
            ratios.append(int(str(s["对话占比"]).rstrip("%")))
        except ValueError:
            continue
    ratio = f"{round(sum(ratios) / len(ratios))}%" if ratios else "—"
    words = Counter()
    for s in agg:
        for w in s["高频词"]:
            words[w] += 1
    top = "、".join(w for w, _ in words.most_common(16))
    return "\n".join([
        f"@条目 原文风格", "@来源 原文统计（确定性）",
        f"@注释 由 {len(agg)} 章正文统计得出，供后续构建时对齐",
        "视角 　@待补（需人审：贴身第三人称？全知？）",
        f"句长 平均 {avg} 字，连续三句同长即拆",
        f"对话占比 {ratio}",
        "禁用词 　@待补",
        f"高频词 {top}",
    ])


def timeline_text(project: str, chapters: list[dict]) -> str:
    lines = [f"@条目 {project}", "@来源 原文拆解", "@注释 格式：节点名 | 时间 | 状态"]
    for c in chapters:
        title = c["标题"] or "（无题）"
        lines.append(f"{c['编号']}｜{title}｜{c['字数']} 字｜待核对")
    return "\n".join(lines)


def plan_text(project: str, chapters: list[dict], meta: dict, mode: str) -> str:
    lines = [f"@条目 {project}", f"书名 {meta.get('书名') or project}",
             f"类型 {meta.get('类型') or ''}".rstrip(),
             f"一句话梗概 {meta.get('梗概') or ''}".rstrip(),
             f"@来源 由原文拆解生成（引擎：{mode}）",
             "@构建顺序"]
    for c in chapters:
        lines.append(f"  {c['编号']}")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# 五、总装
# --------------------------------------------------------------------------- #
def run(project: str, text: str, *, mode: str = "rules", max_chapters: int = 0,
        meta: dict | None = None, log=None) -> dict:
    """导入整本小说 → 拆解 → 新建工程。返回拆解报告。"""
    say = log or (lambda *_: None)
    meta = meta or {}
    use_model = (mode == "model")
    project = _clean_name(project, 40)
    if not project:
        raise files.FsError("工程名不能为空")
    chapters = split_chapters(text, max_chapters)
    if not chapters:
        raise files.FsError("没有可拆解的正文")
    say(f"分章完成：{len(chapters)} 章，共 {sum(c['字数'] for c in chapters)} 字")

    if (files.PROJECTS / project).exists():
        raise files.FsError(f"工程「{project}」已存在，换个名字或先删除")
    files.create_project(project, str(meta.get("书名") or project), str(meta.get("类型") or ""),
                         str(meta.get("梗概") or chapters[0]["正文"][:40]))
    say(f"已建工程：{project}")

    persons: dict[str, dict] = OrderedDict()
    places: dict[str, dict] = OrderedDict()
    pairs: dict[str, dict] = OrderedDict()
    variables: dict[str, dict] = OrderedDict()
    decisions: dict[str, dict] = OrderedDict()
    behaviors: dict[str, dict] = OrderedDict()
    style: dict[str, dict] = OrderedDict()
    engines: Counter = Counter()
    conflicts: list[str] = []
    made: list[dict] = []

    for ch in chapters:
        ex = ai_extract(ch, use_model=use_model)
        engines[ex.get("引擎", "规则")] += 1
        say(f"{ch['编号']}：抽取 {len(ex['人物'])} 人物 / {len(ex['地点'])} 地点 / {len(ex['事件'])} 事件")

        # 本章剧本 + 事件文件（保原文）
        fn = f"{ch['编号']}.剧本.正文"
        _write(project, fn, chapter_script_text(ch, ex))
        made.append({"文件": fn, "大类": "剧本", "子类": "正文", "置信度": "高（原文直接搬运）"})
        for ev in ex.get("事件") or []:
            nm = _clean_name(ev.get("名") or f"{ch['编号']}-事件")
            fn = f"{nm}.事件.逻辑"
            _write(project, fn, event_text(ch, ev))
            made.append({"文件": fn, "大类": "事件", "子类": "逻辑",
                         "置信度": "高（步骤来自原文）" if not (ev.get("效果") or ev.get("揭示"))
                                   else "中（含模型推断的效果/揭示）"})

        # 人物
        for nm, info in (ex.get("人物") or {}).items():
            nm = _clean_name(nm)
            if not nm:
                continue
            p = persons.setdefault(nm, {"属性": {}, "证据": [], "对白样本": [], "章": [], "知识": [],
                                        "公有行为": []})
            if nm in (ex.get("泛称") or []):
                p["泛称"] = True
            if nm in (ex.get("称呼型") or []):
                p["称谓"] = True
            p["章"].append(ch["编号"])
            for e in info.get("证据", []):
                if e and e not in p["证据"] and len(p["证据"]) < 3:
                    p["证据"].append(e)
            for s in info.get("对白样本", []):
                if s and s not in p["对白样本"]:
                    p["对白样本"].append(s)
            for k, v in (info.get("属性") or {}).items():
                cur = p["属性"].get(k)
                if cur and cur != v:
                    conflicts.append(f"{nm}.{k}：第{p['章'][0]}章「{cur}」 vs {ch['编号']}「{v}」——保留先出现的")
                else:
                    p["属性"][k] = v
        # 地点
        for nm, info in (ex.get("地点") or {}).items():
            nm = _clean_name(nm)
            if not nm:
                continue
            q = places.setdefault(nm, {"章": [], "证据": [], "氛围": "", "布局": "", "可发生": []})
            q["章"].append(ch["编号"])
            q["氛围"] = q["氛围"] or info.get("氛围", "")
            q["布局"] = q["布局"] or info.get("布局", "")
            for x in info.get("可发生", []):
                if x and x not in q["可发生"]:
                    q["可发生"].append(x)
            for e in info.get("证据", []):
                if e and e not in q["证据"] and len(q["证据"]) < 2:
                    q["证据"].append(e)
        # 变量 / 决策 / 行为 / 关系
        for nm, info in (ex.get("变量") or {}).items():
            nm = _clean_name(nm)
            if nm and nm not in variables:
                variables[nm] = info
        for nm, info in (ex.get("决策") or {}).items():
            nm = _clean_name(nm)
            if nm and nm not in decisions:
                decisions[nm] = info
        for nm, info in (ex.get("行为") or {}).items():
            nm = _clean_name(nm)
            if not nm:
                continue
            b = behaviors.setdefault(nm, {"归属": [], "触发": "", "表现": "", "证据": [], "章": []})
            b["章"].append(ch["编号"])
            for owner in info.get("归属", []):
                o = _clean_name(owner)
                if o and o not in b["归属"]:
                    b["归属"].append(o)
            b["触发"] = b["触发"] or info.get("触发", "")
            b["表现"] = b["表现"] or info.get("表现", "")
            for e in info.get("证据", []):
                if e and e not in b["证据"] and len(b["证据"]) < 2:
                    b["证据"].append(e)
        for r in (ex.get("关系") or []):
            a, b2 = _clean_name(r.get("甲", "")), _clean_name(r.get("乙", ""))
            if not (a and b2):
                continue
            key = "-".join(sorted([a, b2]))
            rel = pairs.setdefault(key, {"甲": a, "乙": b2, "章": [], "证据": [], "信任": "", "亏欠": "",
                                         "来源事件": ""})
            rel["章"].append(ch["编号"])
            rel["信任"] = rel["信任"] or str(r.get("信任") or "")
            rel["亏欠"] = rel["亏欠"] or str(r.get("亏欠") or "")
            rel["来源事件"] = rel["来源事件"] or str(r.get("来源事件") or "")
        # 文风统计
        for k, v in (ex.get("文风") or {}).items():
            style[k] = v

        # 同场共现 → 关系候选（确定性推断，规则引擎也能给）
        cast = [n for n in (ex.get("人物") or {}) if _clean_name(n)]
        for i in range(len(cast)):
            for j in range(i + 1, len(cast)):
                a, b2 = _clean_name(cast[i]), _clean_name(cast[j])
                if not (a and b2) or a == b2:
                    continue
                key = "-".join(sorted([a, b2]))
                rel = pairs.setdefault(key, {"甲": a, "乙": b2, "章": [], "证据": [], "信任": "", "亏欠": "",
                                             "来源事件": ""})
                if ch["编号"] not in rel["章"]:
                    rel["章"].append(ch["编号"])

    # 只有同场 ≥2 章的关系才落盘（避免一次擦肩就造关系）
    dropped_pairs = [k for k, v in pairs.items() if len(v["章"]) < 2]
    for k in dropped_pairs:
        pairs.pop(k)

    say(f"合并：人物 {len(persons)} / 地点 {len(places)} / 关系 {len(pairs)} / 变量 {len(variables)} / "
        f"决策 {len(decisions)} / 行为 {len(behaviors)}")

    for nm, info in persons.items():
        fn = f"{nm}.人物.属性"
        _write(project, fn, person_text(nm, info))
        made.append({"文件": fn, "大类": "人物", "子类": "属性",
                     "置信度": "中（属性需人审）" if info.get("属性") else "低（仅出场与证据，属性待补）"})
        fn = f"{nm}.人物.口癖"
        _write(project, fn, person_quirk_text(nm, info))
        made.append({"文件": fn, "大类": "人物", "子类": "口癖", "置信度": "低（样本，需人审）"})
        fn = f"{nm}.人物.知识"
        _write(project, fn, person_knowledge_text(nm, info))
        made.append({"文件": fn, "大类": "人物", "子类": "知识", "置信度": "低（待补知识边界）"})
    for nm, info in places.items():
        fn = f"{nm}.地点.属性"
        _write(project, fn, place_text(nm, info))
        made.append({"文件": fn, "大类": "地点", "子类": "属性", "置信度": "中（出场与证据来自原文）"})
    for key, info in pairs.items():
        fn = f"{key}.关系.关系网"
        _write(project, fn, relation_text(info["甲"], info["乙"], info))
        made.append({"文件": fn, "大类": "关系", "子类": "关系网", "置信度": "中（同场共现推断）"})
    for nm, info in variables.items():
        fn = f"{nm}.变量.数值"
        _write(project, fn, variable_text(nm, info))
        made.append({"文件": fn, "大类": "变量", "子类": "数值", "置信度": "中（模型抽取）"})
    for nm, info in decisions.items():
        fn = f"{nm}.决策.分支"
        _write(project, fn, decision_text(nm, info))
        made.append({"文件": fn, "大类": "决策", "子类": "分支", "置信度": "中（模型抽取）"})
    for nm, info in behaviors.items():
        info["公有"] = len(info.get("归属") or []) != 1
        fn = f"{nm}.行为.习惯"
        _write(project, fn, behavior_text(nm, info))
        made.append({"文件": fn, "大类": "行为", "子类": "习惯",
                     "置信度": "中（模型抽取）" if info.get("表现") else "低（需人审）"})

    fn = "原文风格.文风.样式"
    _write(project, fn, style_text(project, style, engines))
    made.append({"文件": fn, "大类": "文风", "子类": "样式", "置信度": "高（正文统计，确定性）"})
    fn = f"{project}.时间线.节点"
    _write(project, fn, timeline_text(project, chapters))
    made.append({"文件": fn, "大类": "时间线", "子类": "节点", "置信度": "高（章节列表）"})
    fn = f"{project}.工程.清单"
    _write(project, fn, plan_text(project, chapters, meta, "／".join(f"{k}×{v}" for k, v in engines.items())))
    made.append({"文件": fn, "大类": "工程", "子类": "清单", "置信度": "高"})

    report = {
        "工程": project, "模式": "模型抽取" if use_model else "规则抽取（无需模型）",
        "引擎分布": dict(engines),
        "章节数": len(chapters), "总字数": sum(c["字数"] for c in chapters),
        "交叉核对建议": {
            "需人审的属性": [f"{n}.人物.属性" for n, i in persons.items() if not i.get("属性")],
            "泛称角色（可能与具名角色是同一人，需合并或改名）": [n for n, i in persons.items() if i.get("泛称")],
            "称谓型角色（赵爷/三爷 这类叫法，可能是同一人的不同称呼）": [n for n, i in persons.items() if i.get("称谓")],
            "只同场一章被丢弃的关系": dropped_pairs,
            "变量": list(variables), "决策": list(decisions), "行为": list(behaviors),
        },
        "冲突": conflicts,
        "条目": made,
        "下一步": ["打开工程逐条人审（属性/知识/决策三处最需要）",
                   "满意后把通用条目「存入公共库」沉淀为可复用资产"],
    }
    state = files.scope_root("project", project).parent / "state"
    state.mkdir(parents=True, exist_ok=True)
    (state / "拆解报告.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    say(f"拆解完成：共生成 {len(made)} 个条目文件")
    return report
