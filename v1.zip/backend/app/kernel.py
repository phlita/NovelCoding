"""确定性内核：状态、表达式求值、事件/决策执行、执行轨迹。

这一层**不允许**任何模型参与。故事逻辑（谁做什么、状态怎么变、谁知道了什么、走哪条分支）
全在这里定死；正文渲染只是它的下游。

状态寻址（写在 .事件.逻辑 的 @效果 / @前置 里）：
    v.字据在手        全局变量
    s.李三.戒备       人物状态
    r.李三-赵爷.信任  关系字段
    知(李三, 字据是新描的)   知识账本

表达式支持：+ - * /  %  == != > >= < <=  且/并且/and  或/或者/or  非/not  括号 与 字符串
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

# --------------------------------------------------------------------------- #
# 表达式求值（Pratt 解析，零依赖、零 eval）
# --------------------------------------------------------------------------- #
TOKEN_RE = re.compile(r"""
    \s*(?:
      (?P<num>\d+(?:\.\d+)?)
    | (?P<path>[vrs]\.[^\s()=<>!+*/%|]+)
    | (?P<word>[A-Za-z_\u4e00-\u9fa5][A-Za-z0-9_\u4e00-\u9fa5]*)
    | (?P<op><=|>=|==|!=|&&|\|\||[-+*/%()<>,])
    )
""", re.X)

BOOL_TRUE = {"真", "是", "true", "True", "yes", "on"}
BOOL_FALSE = {"假", "否", "false", "False", "no", "off", ""}


class ExprError(Exception):
    pass


@dataclass
class Evaluator:
    """把表达式在给定状态上求值。缺变量按 0 / 假 处理，并记入 warnings。"""
    get_v: Any = None                  # callable(name) -> value
    get_s: Any = None                  # callable(person, field) -> value
    get_r: Any = None                  # callable(pair, field) -> value
    knows: Any = None                  # callable(person, fact) -> bool
    warnings: list[str] = field(default_factory=list)

    def _tok(self, text: str):
        pos, toks = 0, []
        while pos < len(text):
            m = TOKEN_RE.match(text, pos)
            if not m:
                if text[pos:].strip() == "":
                    break
                raise ExprError(f"无法解析：{text[pos:pos + 12]}")
            pos = m.end()
            kind = m.lastgroup
            val = m.group(kind)
            toks.append((kind, val))
        return toks

    def eval(self, text: str) -> Any:
        text = (text or "").strip()
        if not text:
            return True
        toks = self._tok(text)
        self._i = 0
        self._toks = toks
        value = self._or()
        if self._i < len(toks):
            raise ExprError(f"表达式末尾多余内容：{text}")
        return value

    # --- 递归下降 ---
    def _peek(self):
        return self._toks[self._i] if self._i < len(self._toks) else (None, None)

    def _take(self):
        t = self._peek()
        self._i += 1
        return t

    def _or(self):
        left = self._and()
        while True:
            kind, val = self._peek()
            if kind == "word" and val in ("或", "或者", "or") or (kind == "op" and val == "||"):
                self._take()
                right = self._and()
                left = bool(left) or bool(right)
            else:
                return left

    def _and(self):
        left = self._cmp()
        while True:
            kind, val = self._peek()
            if kind == "word" and val in ("且", "并且", "and") or (kind == "op" and val == "&&"):
                self._take()
                right = self._cmp()
                left = bool(left) and bool(right)
            else:
                return left

    def _cmp(self):
        left = self._add()
        kind, val = self._peek()
        if kind == "op" and val in ("==", "!=", ">", ">=", "<", "<="):
            self._take()
            right = self._add()
            return self._apply_cmp(val, left, right)
        return left

    @staticmethod
    def _num(v):
        if isinstance(v, bool):
            return 1 if v else 0
        if isinstance(v, (int, float)):
            return v
        s = str(v).strip()
        try:
            return float(s) if "." in s else int(s)
        except ValueError:
            return s

    def _apply_cmp(self, op: str, a, b):
        if op == "==":
            return self._num(a) == self._num(b) or str(a) == str(b)
        if op == "!=":
            return not self._apply_cmp("==", a, b)
        an, bn = self._num(a), self._num(b)
        try:
            if op == ">":
                return an > bn
            if op == ">=":
                return an >= bn
            if op == "<":
                return an < bn
            return an <= bn
        except TypeError as exc:
            raise ExprError(f"无法比较 {a!r} 与 {b!r}") from exc

    def _add(self):
        left = self._mul()
        while True:
            kind, val = self._peek()
            if kind == "op" and val in ("+", "-"):
                self._take()
                right = self._mul()
                left = self._arith(val, left, right)
            else:
                return left

    def _mul(self):
        left = self._unary()
        while True:
            kind, val = self._peek()
            if kind == "op" and val in ("*", "/", "%"):
                self._take()
                right = self._unary()
                left = self._arith(val, left, right)
            else:
                return left

    def _arith(self, op: str, a, b):
        an, bn = self._num(a), self._num(b)
        if isinstance(an, str) and isinstance(bn, str) and op == "+":
            return an + bn
        try:
            if op == "+":
                return an + bn
            if op == "-":
                return an - bn
            if op == "*":
                return an * bn
            if op == "/":
                return an / bn if bn else 0
            return an % bn if bn else 0
        except TypeError as exc:
            raise ExprError(f"无法计算 {a!r} {op} {b!r}") from exc

    def _unary(self):
        kind, val = self._peek()
        if kind == "op" and val == "-":
            self._take()
            return -self._num(self._unary())
        if (kind == "word" and val in ("非", "not")) or (kind == "op" and val == "!"):
            self._take()
            return not bool(self._unary())
        return self._primary()

    def _primary(self):
        kind, val = self._take()
        if kind == "num":
            return float(val) if "." in val else int(val)
        if kind == "path":
            return self._resolve_path(val)
        if kind == "op" and val == "(":
            inner = self._or()
            k2, v2 = self._take()
            if not (k2 == "op" and v2 == ")"):
                raise ExprError("括号不匹配")
            return inner
        if kind == "word":
            # 函数：知(人物, 事实) / 知道(...)
            nxt_kind, nxt = self._peek()
            if val in ("知", "知道", "knows") and nxt_kind == "op" and nxt == "(":
                self._take()
                k, person_tok = self._take()
                person = str(person_tok or "")
                k, v = self._peek()
                if k == "op" and v == ",":
                    self._take()
                fact_parts = []
                while True:
                    k, v = self._take()
                    if k is None:
                        raise ExprError("知(...) 少了右括号")
                    if k == "op" and v == ")":
                        break
                    fact_parts.append(str(v))
                fact = "".join(fact_parts).strip()
                return bool(self.knows(person, fact) if self.knows else False)
            if val in BOOL_TRUE:
                return True
            if val in BOOL_FALSE:
                return False
            self.warnings.append(f"裸标识符「{val}」按变量处理")
            return self._resolve_path(val)
        raise ExprError(f"表达式不合语法：{val!r}")

    def _resolve_path(self, path: str) -> Any:
        path = path.strip()
        parts = path.split(".")
        if parts[0] == "v":
            name = ".".join(parts[1:])
            if self.get_v is None:
                return 0
            val = self.get_v(name)
            if val is None:
                self.warnings.append(f"变量 v.{name} 未定义，按 0 处理")
                return 0
            return val
        if parts[0] == "s" and len(parts) >= 3:
            person, fld = parts[1], ".".join(parts[2:])
            val = self.get_s(person, fld) if self.get_s else None
            if val is None:
                self.warnings.append(f"人物状态 s.{person}.{fld} 未定义，按 0 处理")
                return 0
            return val
        if parts[0] == "r" and len(parts) >= 3:
            pair, fld = parts[1], ".".join(parts[2:])
            val = self.get_r(pair, fld) if self.get_r else None
            if val is None:
                self.warnings.append(f"关系 r.{pair}.{fld} 未定义，按 0 处理")
                return 0
            return val
        # 裸名 → 变量
        if self.get_v is None:
            return 0
        val = self.get_v(path)
        if val is None:
            self.warnings.append(f"变量 {path} 未定义，按 0 处理")
            return 0
        return val


# --------------------------------------------------------------------------- #
# 状态
# --------------------------------------------------------------------------- #
@dataclass
class State:
    变量: dict[str, Any] = field(default_factory=dict)
    人物状态: dict[str, dict[str, Any]] = field(default_factory=dict)
    关系: dict[str, dict[str, Any]] = field(default_factory=dict)
    知识: dict[str, set] = field(default_factory=dict)
    已发生: list = field(default_factory=list)

    def get_v(self, name):
        return self.变量.get(name)

    def get_s(self, person, fld):
        return (self.人物状态.get(person) or {}).get(fld)

    def get_r(self, pair, fld):
        return (self.关系.get(pair) or {}).get(fld)

    def knows(self, person, fact):
        return any(f == fact or f.startswith(fact) or fact.startswith(f)
                   for f in (self.知识.get(person) or set()))

    def snapshot(self) -> dict:
        return {"变量": dict(self.变量),
                "人物状态": {k: dict(v) for k, v in self.人物状态.items()},
                "关系": {k: dict(v) for k, v in self.关系.items()},
                "知识": {k: sorted(v) for k, v in self.知识.items()},
                "已发生": list(self.已发生)}


# --------------------------------------------------------------------------- #
# 事件 / 决策
# --------------------------------------------------------------------------- #
@dataclass
class Event:
    名: str
    前置: str = ""
    出场: list = field(default_factory=list)
    地点: str = ""
    步骤: list = field(default_factory=list)     # ["动作：...", "对白：...", "内心：..."]
    效果: list = field(default_factory=list)     # ["s.李三.戒备 += 2"]
    揭示: list = field(default_factory=list)     # ["李三：字据是新描的"]
    钩子: str = ""
    来源: str = ""

    def as_dict(self):
        return {"名": self.名, "前置": self.前置, "出场": self.出场, "地点": self.地点,
                "步骤": self.步骤, "效果": self.效果, "揭示": self.揭示, "钩子": self.钩子}


@dataclass
class Decision:
    名: str
    问题: str = ""
    选项: list = field(default_factory=list)     # [{"名","条件","去向"}]
    默认: str = ""

    def as_dict(self):
        return {"名": self.名, "问题": self.问题, "选项": self.选项, "默认": self.默认}


STEP_KINDS = ("动作", "对白", "内心", "镜头", "旁白")


def parse_step(raw: str) -> tuple[str, str]:
    text = (raw or "").strip()
    for kind in STEP_KINDS:
        if text.startswith(kind + "："):
            return kind, text[len(kind) + 1:].strip()
        if text.startswith(kind + ":"):
            return kind, text[len(kind) + 1:].strip()
    return "动作", text


EFFECT_RE = re.compile(r"^\s*([vsr]\.[^\s]+)\s*(=|\+=|-=|\*=|/=)\s*(.+?)\s*$")


class Kernel:
    """事件/决策的执行器。所有副作用都在这里发生，并留下轨迹。"""

    def __init__(self, state: State, known_persons=(), known_places=(), known_vars=(), known_pairs=()):
        self.state = state
        self.known_persons = set(known_persons)
        self.known_places = set(known_places)
        self.known_vars = set(known_vars)
        self.known_pairs = set(known_pairs)

    def evaluator(self) -> Evaluator:
        s = self.state
        return Evaluator(get_v=s.get_v, get_s=s.get_s, get_r=s.get_r, knows=s.knows)

    # ---------------- 事件 ---------------- #
    def run_event(self, ev: Event, chapter: str, trace: list) -> bool:
        e = self.evaluator()
        ok = True
        if ev.前置:
            try:
                ok = bool(e.eval(ev.前置))
            except ExprError as exc:
                trace.append({"章": chapter, "事件": ev.名, "类型": "错误",
                              "说明": f"前置条件无法求值：{exc}"})
                ok = False
        if not ok:
            trace.append({"章": chapter, "事件": ev.名, "类型": "跳过",
                          "说明": f"前置条件不成立：{ev.前置}"})
            return False
        for p in ev.出场:
            if p and self.known_persons and p not in self.known_persons:
                trace.append({"章": chapter, "事件": ev.名, "类型": "警告",
                              "说明": f"出场人物「{p}」没有对应的 人物 条目"})
        if ev.地点 and self.known_places and ev.地点 not in self.known_places:
            trace.append({"章": chapter, "事件": ev.名, "类型": "警告",
                          "说明": f"地点「{ev.地点}」没有对应的 地点 条目"})
        trace.append({"章": chapter, "事件": ev.名, "类型": "发生", "说明": ev.钩子 or ""})
        self.state.已发生.append(f"{chapter}:{ev.名}")
        for raw in ev.效果:
            self.apply_effect_raw(raw, chapter, ev.名, trace)
        for raw in ev.揭示:
            self._apply_reveal(raw, chapter, ev.名, trace)
        return True

    def apply_effect_raw(self, raw: str, chapter: str, ev_name: str, trace: list):
        """公开的效果入口：事件、世界规则、内置函数都走这里（只有一套求值器）。

        `调用 函数名(参数…)` 交给 rules 模块处理，其余按 `目标 运算 表达式` 解析。
        """
        text = (raw or "").strip()
        if not text:
            return
        if text.startswith("调用"):
            from app import rules

            if rules.call_function(self, text, chapter, trace):
                return
            # 函数调用失败时 rules 已经写过轨迹；若完全不是合法写法，再报一次
            if re.match(r"^\s*调用\s*[^(（]", text):
                return
        self._apply_effect(text, chapter, ev_name, trace)

    def _apply_effect(self, raw: str, chapter: str, ev_name: str, trace: list):
        m = EFFECT_RE.match(raw or "")
        if not m:
            trace.append({"章": chapter, "事件": ev_name, "类型": "警告",
                          "说明": f"无法解析的效果写法：{raw}"})
            return
        target, op, rhs = m.group(1), m.group(2), m.group(3)
        e = self.evaluator()
        try:
            value = e.eval(rhs)
        except ExprError as exc:
            trace.append({"章": chapter, "事件": ev_name, "类型": "错误",
                          "说明": f"效果右值无法求值（{raw}）：{exc}"})
            return
        for w in e.warnings:
            trace.append({"章": chapter, "事件": ev_name, "类型": "警告", "说明": w})
        before = self._read_target(target)
        after = self._compute(op, before, value)
        self._write_target(target, after)
        trace.append({"章": chapter, "事件": ev_name, "类型": "效果", "目标": target,
                      "运算": op, "前": before, "后": after})

    @staticmethod
    def _tidy(v):
        if isinstance(v, float) and v.is_integer():
            return int(v)
        return v

    @classmethod
    def _compute(cls, op: str, before, value):
        if op == "=":
            return cls._tidy(value)
        b = before if isinstance(before, (int, float)) else 0
        try:
            v = float(value)
        except (TypeError, ValueError):
            v = 0
        if op == "+=":
            return cls._tidy(round(b + v, 4))
        if op == "-=":
            return cls._tidy(round(b - v, 4))
        if op == "*=":
            return cls._tidy(round(b * v, 4))
        if op == "/=":
            return cls._tidy(round(b / v, 4)) if v else 0
        return value

    def _read_target(self, target: str):
        parts = target.split(".")
        if parts[0] == "v":
            return self.state.变量.get(".".join(parts[1:]))
        if parts[0] == "s" and len(parts) >= 3:
            return (self.state.人物状态.get(parts[1]) or {}).get(".".join(parts[2:]))
        if parts[0] == "r" and len(parts) >= 3:
            return (self.state.关系.get(parts[1]) or {}).get(".".join(parts[2:]))
        return None

    def _write_target(self, target: str, value):
        parts = target.split(".")
        if parts[0] == "v":
            self.state.变量[".".join(parts[1:])] = value
        elif parts[0] == "s" and len(parts) >= 3:
            self.state.人物状态.setdefault(parts[1], {})[".".join(parts[2:])] = value
        elif parts[0] == "r" and len(parts) >= 3:
            self.state.关系.setdefault(parts[1], {})[".".join(parts[2:])] = value

    def _apply_reveal(self, raw: str, chapter: str, ev_name: str, trace: list):
        text = (raw or "").strip()
        for sep in ("：", ":"):
            if sep in text:
                who, fact = text.split(sep, 1)
                who, fact = who.strip(), fact.strip()
                if not fact:
                    break
                if self.known_persons and who not in self.known_persons:
                    trace.append({"章": chapter, "事件": ev_name, "类型": "警告",
                                  "说明": f"揭示对象「{who}」没有对应的 人物 条目"})
                self.state.知识.setdefault(who, set()).add(fact)
                trace.append({"章": chapter, "事件": ev_name, "类型": "揭示",
                              "人物": who, "事实": fact})
                return
        trace.append({"章": chapter, "事件": ev_name, "类型": "警告",
                      "说明": f"揭示写法应为「人物：事实」，收到：{raw}"})

    # ---------------- 决策 ---------------- #
    def run_decision(self, dc: Decision, chapter: str, trace: list) -> str:
        e = self.evaluator()
        for opt in dc.选项:
            cond = (opt.get("条件") or "").strip()
            try:
                hit = True if not cond else bool(e.eval(cond))
            except ExprError as exc:
                trace.append({"章": chapter, "决策": dc.名, "类型": "错误",
                              "说明": f"选项「{opt.get('名')}」条件无法求值：{exc}"})
                continue
            if hit:
                trace.append({"章": chapter, "决策": dc.名, "类型": "分支",
                              "选中": opt.get("名"), "条件": cond or "（无条件）",
                              "去向": opt.get("去向") or ""})
                return opt.get("去向") or ""
        if dc.默认:
            trace.append({"章": chapter, "决策": dc.名, "类型": "分支", "选中": "默认",
                          "条件": "以上均不成立，走 @默认", "去向": dc.默认})
            return dc.默认
        trace.append({"章": chapter, "决策": dc.名, "类型": "警告",
                      "说明": "没有任何选项成立，也没有 @默认，剧情在此断了"})
        return ""
