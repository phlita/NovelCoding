"""极简 HTTP 客户端 + 响应类型（标准库 urllib）。移植自默认版 2.9 的 net.py（基础设施）。"""
from __future__ import annotations

import json
import socket
import ssl
import urllib.error
import urllib.request
from collections.abc import Iterator

DEFAULT_TIMEOUT = 180
_SSL_CTX = ssl.create_default_context()


class HttpError(RuntimeError):
    def __init__(self, status: int, body: str, message: str = ""):
        self.status, self.body = status, body
        super().__init__(message or f"HTTP {status}")


def _open(method: str, url: str, headers: dict, payload: bytes | None, timeout: int):
    req = urllib.request.Request(url, data=payload, method=method)
    for k, v in headers.items():
        req.add_header(k, v)
    return urllib.request.urlopen(req, timeout=timeout, context=_SSL_CTX)


def request(method: str, url: str, headers: dict | None = None, json_body=None,
            timeout: int = DEFAULT_TIMEOUT) -> str:
    headers = dict(headers or {})
    payload = None
    if json_body is not None:
        payload = json.dumps(json_body, ensure_ascii=False).encode("utf-8")
        headers.setdefault("Content-Type", "application/json; charset=utf-8")
    try:
        with _open(method, url, headers, payload, timeout) as resp:
            return resp.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as exc:
        body = ""
        try:
            body = exc.read().decode("utf-8", "replace")
        except Exception:  # noqa: BLE001
            pass
        raise HttpError(exc.code, body) from exc
    except (urllib.error.URLError, socket.timeout, TimeoutError) as exc:
        raise HttpError(0, "", f"网络请求失败：{exc}") from exc


def stream_lines(method: str, url: str, headers: dict | None = None, json_body=None,
                 timeout: int = DEFAULT_TIMEOUT) -> Iterator[str]:
    headers = dict(headers or {})
    payload = None
    if json_body is not None:
        payload = json.dumps(json_body, ensure_ascii=False).encode("utf-8")
        headers.setdefault("Content-Type", "application/json; charset=utf-8")
    try:
        resp = _open(method, url, headers, payload, timeout)
    except urllib.error.HTTPError as exc:
        body = ""
        try:
            body = exc.read().decode("utf-8", "replace")
        except Exception:  # noqa: BLE001
            pass
        raise HttpError(exc.code, body) from exc
    except (urllib.error.URLError, socket.timeout, TimeoutError) as exc:
        raise HttpError(0, "", f"网络请求失败：{exc}") from exc
    try:
        for raw in resp:
            yield raw.decode("utf-8", "replace")
    finally:
        try:
            resp.close()
        except Exception:  # noqa: BLE001
            pass


class Json:
    def __init__(self, data, status: int = 200):
        self.data, self.status = data, status


class Sse:
    def __init__(self, events):
        self.events = events


class Raw:
    def __init__(self, body: bytes, content_type: str = "application/octet-stream",
                 filename: str = "", status: int = 200):
        self.body, self.content_type = body, content_type
        self.filename, self.status = filename, status


class Error(Exception):
    def __init__(self, detail: str, status: int = 400):
        self.detail, self.status = detail, status
        super().__init__(detail)
