"""内置规则引擎：世界规则 + 内置函数。

这一层回答一个问题：**编辑区的内容，凭什么就能「编译」出合理的行为？**

条目文件只写了「谁在哪做了什么」，但真实世界里还有很多**不用写、默认成立**的东西：

    天黑了人要睡    →  时间推进到夜里，人物的精力就掉
    长期得不到实物  →  动机衰减，行为变消极
    又冷又饿        →  胆量下降，更容易退让
    信任太低        →  不肯说出真相

把这些写成规则，作者就不必在每一章重复交代——**规则自动作用于状态**。
这就是「小说即程序」里那个「标准库」：事件是函数调用，规则是运行时系统。

规则分两类
--------------------------------------------------
1. **世界规则（world）**：每章开始时按条件自动触发，不需要作者调用。
   ```
   {"id": "sleep_at_night", "name": "天黑了要睡",
    "if": "v.时辰 >= 21 或 v.时辰 < 5", "then": ["s.{全部}.精力 -= 2"]}
   ```
2. **内置函数（fn）**：作者在事件里主动调用，形如 `@效果 调用 动机衰减(李三, 3)`。
   ```
   {"id": "motivation_decay", "name": "动机衰减", "params": ["人物", "幅度"],
    "then": ["s.{人物}.动机 -= {幅度}"]}
   ```

规则体是**一组效果语句**，和事件里的 `@效果` 语法完全一致——这样只有一套求值器。
占位符 `{参数名}` 在调用时替换；特殊占位符 `{全部}` 展开成所有人物（批量规则用）。

安全性
--------------------------------------------------
规则只能改**状态**（数值），不能凭空产生事件、不能改正文。所以规则再多也不会
让故事跑偏，只会让人物的状态更符合常识。规则出错只记警告，不影响正文产出。
"""
from __future__ import annotations

import json
import re
from pathlib import Path

RULES_FILE = Path(__file__).resolve().parent / "rules.json"


# --------------------------------------------------------------------------- #
# 默认规则：内置的一套常识
# --------------------------------------------------------------------------- #
DEFAULT_RULES: dict = {
    "version": 1,
    "说明": "小说编程的内置规则。可以改条件、改数值；改完点保存即生效。",
    "变量约定": {
        "时辰": "0~23 的小时数，单位「点」。没有这个变量时规则自动跳过",
        "精力": "人物的体力，0~100",
        "动机": "人物做事的动力，0~100",
        "胆量": "人物敢不敢，0~100",
        "饥饿": "0~100，越高越饿",
    },
    "world": [
        {
            "id": "sleep_at_night", "name": "天黑了要睡", "enabled": True,
            "当": "v.时辰 >= 21 或 v.时辰 < 6",
            "则": ["s.{全部}.精力 -= 8", "s.{全部}.胆量 -= 2"],
            "说明": "深夜精力与胆量下降。缺 时辰 变量时自动不触发。",
        },
        {
            "id": "hunger_grows", "name": "饿了会越来越饿", "enabled": True,
            "当": "v.时辰 >= 11 且 v.时辰 < 14",
            "则": ["s.{全部}.饥饿 += 5"],
            "说明": "中午到饭点，饥饿值上升。",
        },
        {
            "id": "exhausted_collapse", "name": "精力见底就撑不住", "enabled": True,
            "当": "s.{全部}.精力 <= 10",
            "则": ["s.{全部}.胆量 -= 3", "v.疲惫在场 = 1"],
            "说明": "精力太低时胆量继续下滑，并置一个全局开关供事件判断。",
        },
        {
            "id": "desire_decay", "name": "长期得不到实物，动机衰减", "enabled": True,
            "当": "s.{全部}.动机 <= 20 且 s.{全部}.饥饿 >= 60",
            "则": ["s.{全部}.动机 -= 4", "s.{全部}.精力 -= 2"],
            "说明": "又饿又没盼头时，人会泄气——这正是「长期得不到就失去动力」。",
        },
        {
            "id": "cold_and_hungry", "name": "又冷又饿更容易退让", "enabled": True,
            "当": "s.{全部}.饥饿 >= 80",
            "则": ["s.{全部}.胆量 -= 4"],
            "说明": "极端饥饿下人物更难强硬。",
        },
        {
            "id": "trust_low_guarded", "name": "信任太低就设防", "enabled": True,
            "当": "r.{任一人对}.信任 <= 0",
            "则": ["s.{甲}.戒备 += 3"],
            "说明": "关系信任见底时，甲对乙的戒备上升（单挑出甲、乙两方）。",
        },
    ],
    "fn": [
        {
            "id": "motivation_decay", "name": "动机衰减", "enabled": True,
            "参数": ["人物", "幅度"],
            "则": ["s.{人物}.动机 -= {幅度}"],
            "说明": "示例：@效果 调用 动机衰减(李三, 3)",
        },
        {
            "id": "tired", "name": "疲惫", "enabled": True,
            "参数": ["人物", "幅度"],
            "则": ["s.{人物}.精力 -= {幅度}", "s.{人物}.胆量 -= {幅度}"],
            "说明": "累了就更容易让步。示例：@效果 调用 疲惫(李三, 5)",
        },
        {
            "id": "reassured", "name": "被安抚", "enabled": True,
            "参数": ["人物", "幅度"],
            "则": ["s.{人物}.戒备 -= {幅度}", "s.{人物}.动机 += {幅度}"],
            "说明": "被安抚后戒备下降、动机回升。",
        },
        {
            "id": "fed", "name": "吃饱了", "enabled": True,
            "参数": ["人物"],
            "则": ["s.{人物}.饥饿 = 0", "s.{人物}.胆量 += 2"],
            "说明": "吃饱后饥饿清零，胆量小涨。",
        },
    ],
}


# --------------------------------------------------------------------------- #
# 读写
# --------------------------------------------------------------------------- #
def load() -> dict:
    """读规则文件。

    兜底规则：**有内置规则就用内置规则；一条都没有就用默认规则集**。
    也就是把 world 和 fn 全部删空 = 恢复成出厂的默认那一套，而不是「什么规则都没有」——
    否则用户误删一半会得到半套规则，行为难以预期。
    """
    default = json.loads(json.dumps(DEFAULT_RULES))
    if not RULES_FILE.is_file():
        return default
    try:
        data = json.loads(RULES_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return default
    if not isinstance(data, dict):
        return default

    out = default
    world = data.get("world")
    fn = data.get("fn")
    # 只有「显式给了数组」时才替换；空数组 = 用户清空 → 用默认兜底
    if isinstance(world, list) and world:
        out["world"] = world
    if isinstance(fn, list) and fn:
        out["fn"] = fn
    if isinstance(data.get("变量约定"), dict) and data["变量约定"]:
        out["变量约定"] = data["变量约定"]
    if isinstance(data.get("说明"), str) and data["说明"].strip():
        out["说明"] = data["说明"]
    out["version"] = int(data.get("version") or 1)
    return out


def save(cfg: dict) -> dict:
    """写回规则文件。

    · 给了非空数组 → 用它
    · 给了空数组   → 存成空数组（表示「用默认兜底」），load() 会退回默认规则集
    """
    cur = load()
    if isinstance(cfg.get("world"), list):
        cur["world"] = cfg["world"]
    if isinstance(cfg.get("fn"), list):
        cur["fn"] = cfg["fn"]
    if isinstance(cfg.get("变量约定"), dict):
        cur["变量约定"] = cfg["变量约定"]
    if isinstance(cfg.get("说明"), str):
        cur["说明"] = cfg["说明"]
    cur["version"] = int(cur.get("version") or 1) + 1
    RULES_FILE.write_text(json.dumps(cur, ensure_ascii=False, indent=2), encoding="utf-8")
    return cur


def is_using_defaults() -> bool:
    """当前是否在用默认兜底规则（用户把规则清空了）。"""
    if not RULES_FILE.is_file():
        return True
    try:
        data = json.loads(RULES_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return True
    if not isinstance(data, dict):
        return True
    world = data.get("world")
    fn = data.get("fn")
    return not (isinstance(world, list) and world) and not (isinstance(fn, list) and fn)


def reset() -> dict:
    RULES_FILE.write_text(json.dumps(DEFAULT_RULES, ensure_ascii=False, indent=2), encoding="utf-8")
    return load()


# --------------------------------------------------------------------------- #
# 占位符
# --------------------------------------------------------------------------- #
ALL = "{全部}"
ANY_PAIR = "{任一人对}"
PLACEHOLDER_RE = re.compile(r"\{([^{}]+)\}")


def _expand(template: str, bindings: dict) -> str:
    """把 {参数} 替换成实际值。认不出的占位符原样保留（由求值器报未定义）。"""

    def sub(m):
        name = m.group(1)
        return str(bindings.get(name, m.group(0)))

    return PLACEHOLDER_RE.sub(sub, template)


def _rule_uses_all(rule: dict) -> bool:
    text = json.dumps(rule, ensure_ascii=False)
    return ALL in text


def _compiled(rule: dict) -> list[str]:
    """取规则体的字段名：新写法用「则」，兼容 then。"""
    body = rule.get("则")
    if body is None:
        body = rule.get("then")
    return [str(x) for x in (body or []) if str(x).strip()]


def _cond(rule: dict) -> str:
    c = rule.get("当")
    if c is None:
        c = rule.get("if")
    return str(c or "").strip()


# --------------------------------------------------------------------------- #
# 应用
# --------------------------------------------------------------------------- #
def apply_world_rules(kernel, chapter: str, trace: list) -> int:
    """在一章开始时按条件触发世界规则。返回触发次数。

    `{全部}` 规则会对每个人物各算一次条件；只要有人满足就对该人应用。
    `{任一人对}` 规则遍历所有关系对。
    """
    cfg = load()
    fired = 0
    persons = sorted(kernel.state.人物状态)
    pairs = sorted(kernel.state.关系)

    for rule in cfg.get("world") or []:
        if not isinstance(rule, dict) or rule.get("enabled") is False:
            continue
        cond = _cond(rule)
        body = _compiled(rule)
        if not cond or not body:
            trace.append({"章": chapter, "事件": rule.get("id"), "类型": "警告",
                          "说明": f"规则「{rule.get('name') or rule.get('id')}」缺少条件或后果，已跳过"})
            continue

        targets: list[dict] = []
        if ALL in cond or ALL in " ".join(body):
            for who in persons:
                targets.append({"全部": who, "人物": who})
        elif ANY_PAIR in cond or ANY_PAIR in " ".join(body):
            for key in pairs:
                a, _, b = key.partition("-")
                targets.append({"任一人对": key, "甲": a, "乙": b})
        else:
            targets.append({})

        for bind in targets:
            fired += _fire_if(kernel, rule, bind, chapter, trace)
    return fired


def _fire_if(kernel, rule: dict, bind: dict, chapter: str, trace: list) -> int:
    """条件成立就执行规则体。返回是否触发（1/0）。"""
    name = rule.get("name") or rule.get("id")
    cond = _expand(_cond(rule), bind)
    e = kernel.evaluator()
    try:
        ok = bool(e.eval(cond))
    except Exception as exc:  # noqa: BLE001
        trace.append({"章": chapter, "事件": name, "类型": "警告",
                      "说明": f"规则条件无法求值（{cond}）：{exc}"})
        return 0
    for w in e.warnings:
        trace.append({"章": chapter, "事件": name, "类型": "警告", "说明": w})
    if not ok:
        return 0
    fired = 0
    for raw in _compiled(rule):
        stmt = _expand(raw, bind)
        before = len(trace)
        kernel.apply_effect_raw(stmt, chapter, f"规则·{name}", trace)
        if len(trace) > before:
            for item in trace[before:]:
                if item.get("类型") == "效果":
                    item["来源"] = "规则"
                    fired += 1
    return 1 if fired else 0


def call_function(kernel, raw: str, chapter: str, trace: list) -> bool:
    """执行 `调用 函数名(参数, 参数…)`。返回是否成功。

    写法：`@效果 调用 动机衰减(李三, 3)`
    """
    m = re.match(r"^\s*调用\s*([^(（]+)[（(](.*)[）)]\s*$", raw or "")
    if not m:
        return False
    fname = m.group(1).strip()
    args = [a.strip() for a in re.split(r"[,，]", m.group(2)) if a.strip()]

    cfg = load()
    fn = next((f for f in (cfg.get("fn") or [])
               if isinstance(f, dict) and (f.get("name") == fname or f.get("id") == fname)), None)
    if fn is None:
        trace.append({"章": chapter, "事件": fname, "类型": "警告",
                      "说明": f"没有名为「{fname}」的内置函数"})
        return False
    if fn.get("enabled") is False:
        return False

    params = fn.get("参数") or fn.get("params") or []
    if len(args) < len(params):
        trace.append({"章": chapter, "事件": fname, "类型": "警告",
                      "说明": f"函数「{fname}」需要 {len(params)} 个参数，收到 {len(args)} 个"})
        return False

    bind = {p: args[i] for i, p in enumerate(params) if i < len(args)}
    for raw_effect in _compiled(fn):
        stmt = _expand(raw_effect, bind)
        if stmt.strip().startswith("调用"):
            # 函数里再调函数会无限递归，直接拒绝
            trace.append({"章": chapter, "事件": fname, "类型": "警告",
                          "说明": f"函数「{fname}」里不能再调用函数（{stmt}）"})
            continue
        kernel.apply_effect_raw(stmt, chapter, f"函数·{fname}", trace)
    return True


# --------------------------------------------------------------------------- #
# 给界面/文档用的摘要
# --------------------------------------------------------------------------- #
def describe() -> dict:
    """规则清单（给前端规则编辑器用）。"""
    cfg = load()
    return {
        "version": cfg.get("version"),
        "说明": cfg.get("说明", ""),
        "变量约定": cfg.get("变量约定", {}),
        "world": cfg.get("world") or [],
        "fn": cfg.get("fn") or [],
        "用默认兜底": is_using_defaults(),
        "文件": str(RULES_FILE),
    }
