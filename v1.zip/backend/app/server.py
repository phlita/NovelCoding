"""v3 HTTP 服务：标准库 http.server（多线程），提供 API + 静态资源。"""
from __future__ import annotations

import json
import os
import socket
import sys
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from app import config, files, llm, net, routes
from app.files import FsError

FRONTEND_DIR = files.ROOT / "frontend"

CONTENT_TYPES = {".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8",
                 ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png",
                 ".jpg": "image/jpeg", ".ico": "image/x-icon", ".json": "application/json; charset=utf-8"}
VERBOSE = os.environ.get("LS3_VERBOSE", "") not in ("", "0", "false")


class Context:
    def __init__(self, params: dict, query: dict, body: bytes, content_type: str):
        self.params, self.query, self.body, self.content_type = params, query, body, content_type
        self._json = None

    @property
    def json(self):
        if self._json is None:
            try:
                self._json = json.loads(self.body.decode("utf-8")) if self.body else {}
            except (json.JSONDecodeError, UnicodeDecodeError):
                self._json = {}
            if not isinstance(self._json, dict):
                self._json = {}
        return self._json


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server_version = "LingShu3"
    sys_version = ""

    def log_message(self, fmt, *args):
        if VERBOSE or (args and str(args[1] if len(args) > 1 else "").startswith("5")):
            sys.stderr.write(f"{self.address_string()} {fmt % args}\n")

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")

    def do_PUT(self):
        self._handle("PUT")

    def do_PATCH(self):
        self._handle("PATCH")

    def do_DELETE(self):
        self._handle("DELETE")

    def do_OPTIONS(self):
        self._send(204, b"", "text/plain", extra={"Access-Control-Allow-Methods":
                                                  "GET,POST,PUT,PATCH,DELETE,OPTIONS",
                                                  "Access-Control-Allow-Headers": "Content-Type"})

    def _handle(self, method: str):
        parsed = urllib.parse.urlparse(self.path)
        path = urllib.parse.unquote(parsed.path)
        query = {k: v[0] for k, v in urllib.parse.parse_qs(parsed.query).items()}
        if not path.startswith("/api/"):
            self._serve_static(path)
            return
        body = self._read_body()
        fn, params = routes.match(method, path)
        if fn is None:
            self._json_out({"detail": "Not Found"}, 404)
            return
        try:
            result = fn(Context(params or {}, query, body, self.headers.get("Content-Type", "")))
        except (FsError,) as exc:
            self._json_out({"detail": exc.detail}, exc.status)
            return
        except ValueError as exc:
            # 参数类错误（例如自定义接口重名）：是可解释的 400，不是服务端崩溃
            self._json_out({"detail": str(exc)}, 400)
            return
        except llm.LLMError as exc:
            self._json_out({"detail": str(exc)}, 502)
            return
        except net.Error as exc:
            self._json_out({"detail": exc.detail}, exc.status)
            return
        except Exception as exc:  # noqa: BLE001
            traceback.print_exc()
            self._json_out({"detail": f"服务端错误：{exc}"}, 500)
            return
        if isinstance(result, net.Sse):
            self._stream(result)
        elif isinstance(result, net.Raw):
            extra = {}
            if result.filename:
                extra["Content-Disposition"] = (
                    f"attachment; filename=\"download\"; "
                    f"filename*=UTF-8''{urllib.parse.quote(result.filename)}")
            self._send(result.status, result.body, result.content_type, extra=extra)
        elif isinstance(result, net.Json):
            self._json_out(result.data, result.status)
        elif result is None:
            self._send(204, b"", "text/plain")
        else:
            self._json_out(result, 200)

    def _read_body(self) -> bytes:
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        return self.rfile.read(length) if length > 0 else b""

    def _json_out(self, data, status: int = 200):
        body = json.dumps(data, ensure_ascii=False, default=str).encode("utf-8")
        self._send(status, body, "application/json; charset=utf-8")

    def _send(self, status: int, body: bytes, content_type: str, extra: dict | None = None):
        try:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-store")
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            if body and self.command != "HEAD":
                self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _stream(self, sse: net.Sse):
        try:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Transfer-Encoding", "chunked")
            self.end_headers()
            for item in sse.events:
                chunk = (f"event: {item.get('event', 'message')}\n"
                         f"data: {json.dumps(item.get('data', {}), ensure_ascii=False)}\n\n"
                         ).encode("utf-8")
                self.wfile.write(f"{len(chunk):X}\r\n".encode())
                self.wfile.write(chunk + b"\r\n")
                self.wfile.flush()
            tail = b"event: end\ndata: {}\n\n"
            self.wfile.write(f"{len(tail):X}\r\n".encode())
            self.wfile.write(tail + b"\r\n0\r\n\r\n")
            self.wfile.flush()
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _serve_static(self, path: str):
        rel = path[len("/assets/"):] if path.startswith("/assets/") else (
            "index.html" if path in ("/", "") else path.lstrip("/"))
        target = (FRONTEND_DIR / rel).resolve()
        try:
            target.relative_to(FRONTEND_DIR.resolve())
        except ValueError:
            self._json_out({"detail": "非法路径"}, 403)
            return
        if not target.is_file():
            target = FRONTEND_DIR / "index.html"
            if not target.is_file():
                self._json_out({"detail": "前端资源缺失"}, 404)
                return
        self._send(200, target.read_bytes(),
                   CONTENT_TYPES.get(target.suffix.lower(), "application/octet-stream"),
                   extra={"Cache-Control": "no-cache"})


class Server(ThreadingHTTPServer):
    """Windows 上 SO_REUSEADDR 会让第二个进程也绑同一端口（请求被旧进程抢答），必须关掉。"""
    allow_reuse_address = False
    daemon_threads = True


def _pick_port(preferred: int, tries: int = 30) -> int:
    for port in range(preferred, preferred + tries):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("0.0.0.0", port))
                return port
            except OSError:
                continue
    raise SystemExit(f"端口 {preferred}-{preferred + tries} 都被占用，请用 --port 指定。")


def serve(preferred_port: int = 8013, host: str = "0.0.0.0") -> int:
    port = _pick_port(preferred_port)
    httpd = Server((host, port), Handler)
    cur = config.resolve()
    print()
    print("  ==============================================")
    print("    灵枢 v3 · 小说工程化（工程 + 文件 + 双库）")
    print("  ==============================================")
    print()
    print(f"    访问地址:  http://127.0.0.1:{port}")
    print(f"    使用模型:  {cur['label']}（{cur['model']}）")
    print(f"    工作根目录: {files.ROOT}")
    print(f"    公共库:     {files.LIBRARY}")
    print(f"    工程库:     {files.PROJECTS}")
    print(f"    依赖:      无（仅标准库）  退出: Ctrl+C")
    print()
    sys.stdout.flush()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n已停止。")
    finally:
        httpd.server_close()
    return 0
