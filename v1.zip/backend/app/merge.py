"""实体归并：把「李三 / 三爷 / 那人」这类同一人的不同叫法并成一个条目。

为什么需要它
--------------------------------------------------
拆解器为了**忠实**，宁可多抽不可漏抽：正文里没给名字的角色（那人、来人）
和称呼型角色（三爷、赵爷）都会被单独建成 3 个文件（属性/口癖/知识）。
但构建器是按人名找状态的——散成三个人，`@出场 李三` 就找不到「三爷」的状态，
关系网的 key「李三-赵爷」也会和「三爷-赵爷」对不上。

所以拆完必须有一次归并。归并**不做模糊猜测**，分两段：

  1. suggest()：确定性生成「疑似同一人」候选，只看可解释的证据
       · 称谓归一：X爷 / X哥 / X掌柜 → 剥掉称呼字后的 X
       · 前缀归一：老李 / 小李 / 阿李 → 李（且需另一侧存在）
       · 包含关系：三爷 ⊂ 李三爷（短的并到长的）
       · 正文强证据：两名字从不在同一场景出现（同场互斥）→ 可能同一人
     每个候选都带 证据 / 置信度，由人拍板。

  2. apply()：按人给的映射真正合并
       · 人物：属性合并（先到先得，冲突记报告）、口癖取样本、知识取并集、证据合并
       · 关系：key 重排，甲/乙改新名；重名关系直接合并字段
       · 事件：@出场 / @揭示 里的人名批量改名
       · 剧本与正文：原文里的旧名替换成新名（可选，默认开）
       · 最后删掉被并入的旧文件

归并报告落到 state/归并报告.json，可回退（不自动删原文备份，靠 git / 手动）。
"""
from __future__ import annotations

import json
from collections import OrderedDict
from pathlib import Path

from app import files

# 称谓字：名字末尾是这些字时，可能是某人的称呼
TITLE_CHARS = set("爷哥姐娘婶婆叔姨嫂老板掌柜先生大人公子姑娘师傅师父大夫")
# 昵称前缀
NICK_PREFIX = set("老小阿大")


# --------------------------------------------------------------------------- #
# 一、读工程里的人物与关系（只读，不依赖 builder，避免循环依赖）
# --------------------------------------------------------------------------- #
def _kv(body: list[str]) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in body:
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if "=" in s:
            k, _, v = s.partition("=")
            out[k.strip()] = v.strip()
        else:
            k, _, v = s.partition("　")
            if v:
                out[k.strip()] = v.strip()
    return out


def _split_notes(text: str) -> tuple[dict[str, list[str]], list[str]]:
    notes: dict[str, list[str]] = OrderedDict()
    body: list[str] = []
    for line in (text or "").splitlines():
        s = line.strip()
        if s.startswith("@"):
            key, _, val = s[1:].partition(" ")
            notes.setdefault(key.strip(), []).append(val.strip())
        else:
            body.append(line)
    return notes, body


def load_project(project: str) -> dict:
    """把工程读成归并要用的结构。"""
    root = files.scope_root("project", project)
    if not root.exists():
        raise files.FsError(f"工程不存在：{project}", 404)
    persons: dict[str, dict] = OrderedDict()
    relations: dict[str, dict] = OrderedDict()
    events: dict[str, dict] = OrderedDict()
    scripts: dict[str, dict] = OrderedDict()
    files_all: dict[str, str] = OrderedDict()

    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        info = files.parse_filename(path.name)
        if not info["ok"]:
            continue
        cat, sub, stem = info["大类"], info["子类"], info["条目名"]
        rel = path.relative_to(root).as_posix()
        text = path.read_text(encoding="utf-8", errors="replace")
        files_all[rel] = text
        if cat == "人物":
            p = persons.setdefault(stem, {"属性": {}, "状态": {}, "口癖": "", "知识": [],
                                          "证据": [], "章": [], "泛称": False, "称谓": False,
                                          "文件": []})
            p["文件"].append(rel)
            notes, body = _split_notes(text)
            if sub == "属性":
                p["属性"] = _kv(body)
                if any("泛称" in n for n in notes.get("待审", [])):
                    p["泛称"] = True
                if any("称谓" in n for n in notes.get("待审", [])):
                    p["称谓"] = True
                for n in notes.get("证据", []):
                    if n and n not in p["证据"]:
                        p["证据"].append(n)
            elif sub == "状态":
                for k, v in _kv(body).items():
                    if k != stem and v != "":
                        p["状态"][k] = v
            elif sub == "口癖":
                p["口癖"] = text.strip()
            elif sub == "知识":
                for line in body:
                    s = line.strip()
                    if s and not s.startswith("@") and s not in p["知识"]:
                        p["知识"].append(s)
                for f in notes.get("知", []) + notes.get("知识", []):
                    if f and f not in p["知识"]:
                        p["知识"].append(f)
        elif cat == "关系":
            notes, body = _split_notes(text)
            relations[stem] = {"文件": rel, "字段": _kv(body),
                                "证据": notes.get("证据", []), "甲": "", "乙": ""}
        elif cat == "事件":
            notes, body = _split_notes(text)
            events[stem] = {"文件": rel, "注释": notes, "正文": body}
        elif cat == "剧本":
            scripts[stem] = {"文件": rel, "原文": text}

    for key in relations:
        parts = key.split("-", 1)
        if len(parts) == 2:
            relations[key]["甲"], relations[key]["乙"] = parts[0], parts[1]
    return {"persons": persons, "relations": relations, "events": events,
            "scripts": scripts, "files": files_all}


# --------------------------------------------------------------------------- #
# 二、生成归并建议（确定性，全部带证据）
# --------------------------------------------------------------------------- #
def _strip_title(name: str) -> tuple[str, str]:
    """三爷 → (三, 爷)；赵掌柜 → (赵, 掌柜)。返回 (词干, 称谓)。"""
    for title in sorted(TITLE_CHARS, key=len, reverse=True):
        if name.endswith(title) and len(name) > len(title):
            return name[: -len(title)], title
    return name, ""


def _cooccur(project: str, names: list[str]) -> dict[tuple[str, str], int]:
    """统计两两在多少章（剧本文件）里同时出现——同场 ⇒ 大概率不是同一人。"""
    data = load_project(project)
    seen: dict[tuple[str, str], set[str]] = {}
    for stem, info in data["scripts"].items():
        text = info["原文"]
        present = [n for n in names if n and n in text]
        for i in range(len(present)):
            for j in range(i + 1, len(present)):
                a, b = sorted([present[i], present[j]])
                seen.setdefault((a, b), set()).add(stem)
    return {k: len(v) for k, v in seen.items()}


def suggest(project: str) -> dict:
    """给出「疑似同一人」的候选，按置信度排序。不修改任何文件。"""
    data = load_project(project)
    persons = data["persons"]
    names = list(persons)
    if not names:
        return {"工程": project, "候选": [], "说明": "工程里没有人物条目"}

    co = _cooccur(project, names)
    generic = "、" .join(n for n, p in persons.items() if p.get("泛称")) or "无"
    titled = "、".join(n for n, p in persons.items() if p.get("称谓")) or "无"

    cands: list[dict] = []
    taken: set[tuple[str, str]] = set()

    def add(a: str, b: str, kind: str, conf: str, why: str, *, keep: str = ""):
        if a == b or not a or not b:
            return
        key = tuple(sorted([a, b]))
        if key in taken:
            return
        same = co.get(key, 0)
        if same > 0:
            # 同场出现过 → 基本可以断定不是同一人，直接否掉
            return
        taken.add(key)
        cands.append({"甲": a, "乙": b, "类型": kind, "置信度": conf,
                      "证据": why, "建议保留": keep or (b if len(b) >= len(a) else a),
                      "同场章数": same})

    # 1. 称谓归一：三爷 → 三（若工程里确有"三"这个人物条目）
    for n in names:
        stem, title = _strip_title(n)
        if not title:
            continue
        if stem in persons and stem != n:
            add(stem, n, "称谓归一", "高", f"「{n}」去掉称谓「{title}」=「{stem}」，两者从未同场")

    # 2. 昵称前缀归一：老李 / 小李 / 阿李 → 李
    for n in names:
        stem, title = _strip_title(n)
        if title:
            continue
        if len(n) >= 2 and n[0] in NICK_PREFIX and n[1:] in persons:
            add(n[1:], n, "前缀归一", "中", f"「{n}」去掉昵称前缀「{n[0]}」=「{n[1:]}」，两者从未同场")

    # 3. 包含关系：三爷 ⊂ 李三爷（短并到长）
    for a in names:
        for b in names:
            if a == b or len(a) >= len(b):
                continue
            if b.endswith(a) and len(a) >= 2:
                add(a, b, "包含归一", "中", f"「{b}」包含「{a}」（可能是全称与称呼）", keep=b)

    # 4. 泛称角色：只提示，不建议自动并（没有证据指向具体是谁）
    generic_list = [n for n, p in persons.items() if p.get("泛称")]

    cands.sort(key=lambda c: ({"高": 0, "中": 1, "低": 2}.get(c["置信度"], 3), -c["同场章数"]))
    return {
        "工程": project,
        "候选": cands,
        "泛称角色": generic_list,
        "称谓角色": [n for n, p in persons.items() if p.get("称谓")],
        "人物总数": len(names),
        "说明": (f"共 {len(names)} 个人物条目；泛称 {generic}；称谓 {titled}。"
                 "候选已排除「同场出现」的组合（同场 ⇒ 不是同一人）。"),
    }


# --------------------------------------------------------------------------- #
# 三、执行归并
# --------------------------------------------------------------------------- #
def _merge_attrs(dst: dict, src: dict, name_dst: str, name_src: str, conflicts: list[str]) -> dict:
    """属性合并：先到先得；冲突不改写，只记报告。"""
    for k, v in src.items():
        if not v:
            continue
        cur = dst.get(k)
        if cur and cur != v:
            conflicts.append(f"「{name_dst}」.{k}：保留「{cur}」（来自先合并的），丢弃「{v}」（来自「{name_src}」）")
        elif not cur:
            dst[k] = v
    return dst


def apply(project: str, mapping: list[dict] | str, *, rewrite_text: bool = True,
          dry_run: bool = False) -> dict:
    """按映射执行归并。

    mapping 两种写法：
      · [{"旧名": "三爷", "新名": "李三"}, ...]   或  [{"from": "...", "to": "..."}]
      · {"三爷": "李三", "那人": "李三"}           （简写）
    支持链式（三爷→李三，李三→李三爷 会先解析成终点），但不允许环。
    """
    pairs: list[tuple[str, str]] = []
    if isinstance(mapping, dict):
        pairs = [(str(k), str(v)) for k, v in mapping.items()]
    else:
        for m in mapping or []:
            a = str(m.get("旧名") or m.get("from") or "").strip()
            b = str(m.get("新名") or m.get("to") or "").strip()
            if a and b:
                pairs.append((a, b))
    if not pairs:
        raise files.FsError("没有给出归并映射（形如 三爷 → 李三）")

    # 解析链式并查环
    target = {a: b for a, b in pairs if a != b}
    for a in list(target):
        seen = {a}
        cur = target[a]
        while cur in target:
            if cur in seen:
                raise files.FsError(f"归并映射出现环：{' → '.join(seen)} → {cur}")
            seen.add(cur)
            cur = target[cur]
        target[a] = cur
    # 自映射（a已是最末）剔除
    target = {a: b for a, b in target.items() if a != b}
    if not target:
        raise files.FsError("所有映射都是自映射，没有可做的归并")

    root = files.scope_root("project", project)
    data = load_project(project)
    persons = data["persons"]
    unknown = [a for a in target if a not in persons]
    if unknown:
        raise files.FsError(f"这些旧名在工程里没有人物条目：{'、'.join(unknown)}")

    # 终点必须存在人物条目（否则等于凭空造人）
    for a, b in target.items():
        if b not in persons:
            raise files.FsError(f"归并目标「{b}」没有人物条目：先给它建 属性/状态 文件，或改成并到一个已有的名字")

    conflicts: list[str] = []
    merged: list[dict] = []
    written: list[str] = []
    deleted: list[str] = []
    warnings: list[str] = []
    # 按终点分组，一次把一个终点的所有旧名并进去
    by_target: dict[str, list[str]] = {}
    for a, b in target.items():
        by_target.setdefault(b, []).append(a)

    for keep, olds in by_target.items():
        dst = persons[keep]
        olds_sorted = sorted(olds)
        for old in olds_sorted:
            src = persons[old]
            if len(old) < 2:
                warnings.append(
                    f"「{old}」是单字名：已合并文件与关系，但没改正文（避免把普通字误替换），请人工检查剧本")
            _merge_attrs(dst["属性"], src["属性"], keep, old, conflicts)
            _merge_attrs(dst["状态"], src["状态"], keep, old, conflicts)
            if not dst["口癖"] and src["口癖"]:
                dst["口癖"] = src["口癖"]
            for f in src["知识"]:
                if f and f not in dst["知识"]:
                    dst["知识"].append(f)
            for e in src["证据"]:
                if e and e not in dst["证据"]:
                    dst["证据"].append(e)
            for c in src["章"]:
                if c not in dst["章"]:
                    dst["章"].append(c)
            dst["泛称"] = bool(dst.get("泛称")) and bool(src.get("泛称"))
        merged.append({"保留": keep, "并入": olds_sorted})

    # 任何文件内容里的改名（关系 key、事件出场/揭示、剧本正文、清单）
    # 只对长度 ≥ 2 的旧名做全局替换：单字名（如「三」）在正文里几乎必然是普通字，
    # 全局替换会把整章毁掉。单字旧名的合并靠文件改名 + 关系 key 重排来体现。
    text_targets = {k: v for k, v in target.items() if len(k) >= 2}

    def rename_text(text: str) -> str:
        out = text
        # 长的先换，避免「李三爷」被「李三」先切开
        for old in sorted(text_targets, key=len, reverse=True):
            out = out.replace(old, text_targets[old])
        return out

    def rename_rel_key(key: str) -> str:
        parts = key.split("-", 1)
        if len(parts) != 2:
            return key
        a, b = target.get(parts[0], parts[0]), target.get(parts[1], parts[1])
        if a == b:
            return ""                 # 两端并成同一人 → 这关系没意义，删掉
        return "-".join(sorted([a, b]))

    if not dry_run:
        def rewrite(rel: str) -> None:
            """把一个文件的内容按改名规则重写（只有真变了才落盘）。"""
            old = data["files"].get(rel, "")
            new = rename_text(old) if rewrite_text else old
            if new == old:
                return
            (root / rel).write_text(new, encoding="utf-8")
            written.append(rel)

        # ---- 1. 保留下来的那个人：按合并结果重写 属性/状态/知识，缺的子类补建 ----
        for keep in by_target:
            p = persons[keep]
            for sub, maker in (("属性", _person_attr_text),
                                ("状态", _person_state_text),
                                ("知识", _person_know_text)):
                # 找到 keep 现有的该子类文件（可能在子目录里）
                existing = None
                for rel in p["文件"]:
                    info = files.parse_filename(Path(rel).name)
                    if info["ok"] and info["子类"] == sub:
                        existing = rel
                        break
                content = maker(keep, p)
                if existing:
                    if content is not None:
                        (root / existing).write_text(content, encoding="utf-8")
                        written.append(existing)
                elif content is not None:
                    rel = f"{keep}.人物.{sub}"
                    (root / rel).write_text(content, encoding="utf-8")
                    written.append(rel)
                    warnings.append(f"「{keep}」原本没有 .人物.{sub}，已按合并结果补建")
            # 口癖：只在正文里改名，内容不动
            for rel in p["文件"]:
                info = files.parse_filename(Path(rel).name)
                if info["ok"] and info["子类"] == "口癖":
                    rewrite(rel)

        # ---- 2. 关系：key 重排（两端并成一人 → 删除；与已有关系重名 → 合并） ----
        for key, info in list(data["relations"].items()):
            rel_path = root / info["文件"]
            new_key = rename_rel_key(key)
            if not new_key:
                rel_path.unlink(missing_ok=True)
                deleted.append(info["文件"])
                warnings.append(f"关系「{key}」两端并成同一人，已删除")
                continue
            text = data["files"].get(info["文件"], "")
            new = rename_text(text) if rewrite_text else text
            new_path = root / f"{new_key}.关系.关系网"
            if new_path == rel_path:
                if new != text:
                    rel_path.write_text(new, encoding="utf-8")
                    written.append(info["文件"])
                continue
            if new_path.exists():
                # 目标关系已存在 → 旧文本接在后面（人审时可再整理），删掉旧文件
                existing = new_path.read_text(encoding="utf-8", errors="replace")
                new_path.write_text(existing.rstrip("\n") + "\n" + new, encoding="utf-8")
                warnings.append(f"关系「{key}」并入已存在的「{new_key}」")
            else:
                new_path.write_text(new, encoding="utf-8")
            written.append(new_path.relative_to(root).as_posix())
            rel_path.unlink(missing_ok=True)
            deleted.append(info["文件"])

        # ---- 3. 事件 / 剧本 / 工程清单：正文里的旧名替换 ----
        for info in data["events"].values():
            rewrite(info["文件"])
        for info in data["scripts"].values():
            rewrite(info["文件"])
        for rel in data["files"]:
            if rel.endswith(".工程.清单"):
                rewrite(rel)

        # ---- 4. 删掉被并入者的旧文件 ----
        for olds in by_target.values():
            for old in olds:
                for rel in persons[old]["文件"]:
                    p = root / rel
                    if p.exists():
                        p.unlink()
                        deleted.append(rel)

    report = {
        "工程": project,
        "归并": merged,
        "改名规则": [{"旧名": k, "新名": v} for k, v in sorted(target.items())],
        "冲突": conflicts,
        "警告": warnings,
        "重写文件": sorted(set(written)),
        "删除文件": sorted(set(deleted)),
        "改写正文": rewrite_text,
        "试运行": dry_run,
    }
    if not dry_run:
        state = root.parent / "state"
        state.mkdir(parents=True, exist_ok=True)
        (state / "归并报告.json").write_text(json.dumps(report, ensure_ascii=False, indent=2),
                                            encoding="utf-8")
    return report


# --------------------------------------------------------------------------- #
# 四、补文件模板（只在合并后原条目缺该子类时用）
# --------------------------------------------------------------------------- #
def _person_attr_text(name: str, p: dict) -> str | None:
    attrs = p.get("属性") or {}
    if not attrs:
        return None
    lines = [f"@条目 {name}"]
    if p.get("证据"):
        lines.append("@证据 " + "；".join(p["证据"][:3]))
    for k, v in attrs.items():
        lines.append(f"{k} {v}")
    return "\n".join(lines) + "\n"


def _person_state_text(name: str, p: dict) -> str | None:
    st = p.get("状态") or {}
    if not st:
        return None
    lines = [f"@条目 {name}", "@注释 数值型状态：初值在这里给，运行中被事件的 @效果 改写"]
    for k, v in st.items():
        lines.append(f"{k} = {v}")
    return "\n".join(lines) + "\n"


def _person_know_text(name: str, p: dict) -> str | None:
    facts = p.get("知识") or []
    if not facts:
        return None
    lines = [f"@条目 {name}", "@注释 这一栏决定他能说什么、不能说什么：只写他确实知道的事"]
    for f in facts:
        lines.append(f"@知 {f}")
    return "\n".join(lines) + "\n"
