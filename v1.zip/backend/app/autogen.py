"""AI 全自动生成：按规范产出条目 → 解析 → 直接写入工程。

和「对话」的区别
--------------------------------------------------
对话是把 AI 的回复显示给人看，人再决定贴哪儿。
这个模块是**全自动**：给定一个目标（比如「把第 03 章写成条目」），
它带着规范去问 AI，把回复解析成 {文件名: 内容}，校验后直接落到工程 src/ 里。

流程
--------------------------------------------------
    1. 拼 system = 规范文本 + 当前工程已有条目摘要（避免重复造人）
    2. 调模型（走 llm.chat，四条通路都支持）
    3. 从回复里解析出条目文件（认 ``` 代码块 + 「文件名：xxx」行）
    4. 逐个校验文件名是否合法（条目名.大类.子类）
    5. 写入（可选 dry_run 只预览不落盘）
    6. 返回报告：写了哪些、跳了哪些、为什么跳

安全性
--------------------------------------------------
· 只写 src/ 下的条目文件，不碰 build/、state/、公共库；
· 文件名必须通过 files.parse_filename 校验，非法直接跳过并记原因；
· 默认不覆盖已存在的文件（overwrite=False），避免 AI 把作者写好的内容冲掉；
· 解析失败就如实报告，不猜测、不硬写。
"""
from __future__ import annotations

import re
from pathlib import Path

from app import aispec, files, llm

# AI 回复里一个条目的开头：```文件名：xxx  或  ## 文件名：xxx
# 故意写宽松——文件名的合法性交给 files.parse_filename 校验，这里只负责切分
HEAD_RE = re.compile(
    r"^(?:```[a-zA-Z]*\s*)?(?:#+\s*)?(?:文件名|文件|File|file)\s*[:：]\s*(\S+)\s*$",
    re.M)


def parse_reply(text: str) -> list[dict]:
    """从模型回复里解析出条目文件。

    只认一种约定：**一个条目 = 一个围栏块，块的第一行是「文件名：xxx」**。
        ```
        文件名：李三.人物.属性
        身份 伙计
        ```
    围栏外如果有「文件名：xxx」+ 正文（模型偶尔不写围栏），也兜底认一下。
    同名取第一次出现。返回 [{"文件名":..., "内容":...}]，按出现顺序。
    """
    if not text:
        return []
    out: list[dict] = []
    seen: set[str] = set()

    def take(fname: str, body: str) -> None:
        name = Path((fname or "").strip().strip("`")).name
        if not name or name in seen:
            return
        content = (body or "").strip("\n")
        if not content.strip():
            return
        seen.add(name)
        out.append({"文件名": name, "内容": content.rstrip() + "\n"})

    # ① 围栏块：```…``` 配对
    for m in re.finditer(r"```[a-zA-Z]*\r?\n([\s\S]*?)```", text):
        body = m.group(1)
        lines = body.split("\n")
        if not lines:
            continue
        head = lines[0].strip()
        hm = re.match(r"^(?:文件名|文件|File|file)\s*[:：]\s*(.+)$", head)
        if hm:
            take(hm.group(1), "\n".join(lines[1:]))

    # ② 兜底：围栏外/未闭合的「文件名：xxx」段落
    marks = list(HEAD_RE.finditer(text))
    for i, m in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(text)
        chunk = text[m.end():end]
        chunk = chunk.replace("```", "")          # 去掉可能残留的围栏
        take(m.group(1), chunk)

    return out


def context_summary(project: str, limit: int = 60) -> str:
    """当前工程已有条目的摘要，给 AI 避免重复造人 / 造地点。"""
    root = files.scope_root("project", project)
    if not root.exists():
        return ""
    names: dict[str, list[str]] = {}
    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        info = files.parse_filename(p.name)
        if not info["ok"]:
            continue
        names.setdefault(info["大类"], []).append(info["条目名"])
    if not names:
        return ""
    lines = ["【工程已有条目】"]
    for cat, items in names.items():
        uniq = sorted(set(items))[:limit]
        lines.append(f"- {cat}：{'、'.join(uniq)}")
    return "\n".join(lines)


def build_prompt(project: str, task: str) -> tuple[str, str]:
    """拼 system / user。system 里是规范 + 已有条目摘要。"""
    system = aispec.spec_text()
    summary = context_summary(project)
    if summary:
        system += "\n\n" + summary + "\n（复用上面已存在的条目名，不要另起同名人物。）"
    user = (
        f"{task}\n\n"
        "请严格按上面的规范输出条目文件。每个文件写成：\n"
        "```\n文件名：条目名.大类.子类\n…文件内容…\n```\n"
        "只输出条目，不要解释。"
    )
    return system, user


def generate(project: str, task: str, *, dry_run: bool = False, overwrite: bool = False,
             max_tokens: int = 6000, log=None) -> dict:
    """全自动：问模型 → 解析 → 校验 → 写入。返回报告。"""
    say = log or (lambda *_: None)
    project = (project or "").strip()
    if not project:
        raise files.FsError("缺少 project")
    if not (files.PROJECTS / project).exists():
        raise files.FsError(f"工程不存在：{project}", 404)
    task = (task or "").strip()
    if not task:
        raise files.FsError("请说明要生成什么，例如「把第 03 章写成条目」")

    cap = llm.can_chat()
    if not cap["ok"]:
        raise files.FsError(cap["reason"])

    system, user = build_prompt(project, task)
    say(f"按规范生成：{task}")
    raw = llm.chat([{"role": "system", "content": system},
                    {"role": "user", "content": user}], max_tokens=max_tokens)
    say(f"模型返回 {len(raw)} 字")

    parsed = parse_reply(raw)
    say(f"解析出 {len(parsed)} 个条目")

    root = files.scope_root("project", project)
    written: list[dict] = []
    skipped: list[dict] = []

    for item in parsed:
        name = item["文件名"]
        info = files.parse_filename(name)
        if not info["ok"]:
            skipped.append({"文件名": name, "原因": info["why"]})
            continue
        target = root / name
        if target.exists() and not overwrite:
            skipped.append({"文件名": name, "原因": "已存在（未开启覆盖）"})
            continue
        if dry_run:
            written.append({"文件名": name, "字节": len(item["内容"]), "预览": item["内容"][:200]})
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(item["内容"], encoding="utf-8")
        written.append({"文件名": name, "字节": len(item["内容"]),
                        "大类": info["大类"], "子类": info["子类"]})
        say(f"写入 {name}")

    report = {
        "工程": project,
        "任务": task,
        "试运行": dry_run,
        "覆盖": overwrite,
        "写入": written,
        "跳过": skipped,
        "模型原文长度": len(raw),
        "说明": ("试运行：没有写任何文件" if dry_run
                 else f"已写入 {len(written)} 个条目，跳过 {len(skipped)} 个"),
    }
    if not parsed:
        report["原文开头"] = raw[:600]
    return report
