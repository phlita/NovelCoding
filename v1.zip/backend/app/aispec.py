"""给 AI 的规范：接入后按这套规则直接产出条目，不需要人手处理。

为什么需要它
--------------------------------------------------
不接规范的 AI 会写散文。接了规范的 AI 会写**条目文件**——
因为它知道：文件名怎么起、@ 指令有哪些、效果怎么写、有哪些内置函数可调、
哪些规则会自动生效（所以不用重复交代睡觉吃饭）。

这个模块把「怎么写」写成一份可以直接塞进 system prompt 的规范文本，
由 /api/ai/spec 提供给外部 AI（以及本站右栏对话）。
规范内容从真实代码里取（REGISTRY / rules），不是另抄一份——
这样改了注册表或规则，规范自动跟着变，不会漂移。
"""
from __future__ import annotations

from app import files, rules


def spec_text() -> str:
    """生成完整规范文本（markdown）。"""
    reg = files.REGISTRY
    cfg = rules.load()

    parts: list[str] = []
    parts.append("# 小说编程 · 条目编写规范 v1\n")
    parts.append(
        "你在为一个「小说即程序」的工作台编写内容。不要写整段散文，"
        "而要写**条目文件**——它们是这个故事的程序源码，由确定性内核编译成正文。\n"
    )

    parts.append("## 一、一个条目 = 一个文件\n")
    parts.append("文件名格式：`条目名.大类.子类`。大类与子类必须是下列之一：\n")
    for cat, subs in reg.items():
        names = "、".join(subs.keys())
        parts.append(f"- **{cat}**：{names}")
    parts.append("")

    parts.append("## 二、文件内部：注释区 + 正文区\n")
    parts.append(
        "`@` 开头的行是注释区（给编译器和人看的指令），其余是正文区。\n"
        "注释区**不进正文**，但会被内核执行。\n"
    )

    parts.append("## 三、各类条目的写法\n")

    parts.append("### 人物\n")
    parts.append(
        "```\n"
        ".人物.属性   → 正文区写 `身份 伙计`、`年龄 23` 这类「键 值」\n"
        ".人物.状态   → 正文区写 `戒备 = 0`、`精力 = 80`，会被事件改写\n"
        ".人物.知识   → `@知 柜台下沿有个缺口`，一行一条\n"
        ".人物.口癖   → `语域 `、`口癖 `、`只说 `、`绝不说 `\n"
        "```\n"
    )

    parts.append("### 变量\n")
    parts.append(
        "```\n"
        "类型 数值\n初值 0\n说明 李三欠赵爷的人情\n```\n"
        "正文区写初值；事件里用 `v.变量名` 读写。\n"
    )

    parts.append("### 事件（= 函数）\n")
    parts.append(
        "```\n"
        "@条目 试探\n"
        "@前置 v.字据在手==1\n"
        "@出场 李三 赵爷\n"
        "@地点 当铺\n"
        "@步骤 动作：李三把字据推到柜台上\n"
        "@步骤 对白：这纸是新写的\n"
        "@效果 s.赵爷.戒备 += 2\n"
        "@效果 调用 动机衰减(李三, 3)\n"
        "@揭示 李三：赵爷认这张纸比平常久\n"
        "@钩子 赵爷会在天亮前先出牌\n"
        "```\n"
        "- `@前置` 不成立 → 整个事件跳过（不是报错）\n"
        "- `@效果` 立即写回状态\n"
        "- `@揭示` 把事实写进该人物的知识账本\n"
    )

    parts.append("### 决策（= 分支）\n")
    parts.append(
        "```\n"
        "问题 要不要当面问？\n"
        "@选项 直接问 | r.李三-赵爷.信任 >= 3 | 摊牌\n"
        "@选项 忍着不问 | s.李三.胆量 >= 1 | 试探\n"
        "@默认 试探\n"
        "```\n"
        "按顺序取第一个条件成立的选项。\n"
    )

    parts.append("### 剧本（= 章节的正文骨架）\n")
    parts.append(
        "```\n"
        "@条目 第01章\n"
        "@章 第一章 字据\n"
        "@事件 试探\n"
        "@决策 查账\n"
        "@导演 前松后紧，最后一句留白\n"
        "> 动作：李三掀开门帘\n"
        "「对白：掌柜的在吗？」\n"
        "（内心：他知道我们来干什么）\n"
        "```\n"
        "`> ` 是动作，`「」` 是对白，`（）` 是内心。原文照搬，不改写。\n"
    )

    parts.append("## 四、表达式语法\n")
    parts.append(
        "| 写法 | 含义 |\n|---|---|\n"
        "| `v.变量名` | 全局变量 |\n"
        "| `s.人物.字段` | 人物状态 |\n"
        "| `r.甲-乙.字段` | 关系数值 |\n"
        "| `知(人物, 事实)` | 该人物是否知道某事 |\n"
        "| `+ - * / ( )` | 四则运算 |\n"
        "| `== != >= <= > <` | 比较 |\n"
        "| `且` `或` `非`（也认 `and or not`） | 逻辑 |\n"
    )
    parts.append("效果写法：`目标 运算 表达式`，运算取 `= += -= *= /=`。\n")

    parts.append("## 五、内置函数（可直接调用）\n")
    parts.append("写法：`@效果 调用 函数名(参数…)`\n")
    for fn in cfg.get("fn") or []:
        if not isinstance(fn, dict) or fn.get("enabled") is False:
            continue
        params = "、".join(fn.get("参数") or [])
        parts.append(f"- **{fn.get('name')}**（{params}）：{fn.get('说明') or ''}")
        for eff in fn.get("则") or []:
            parts.append(f"  - 效果：`{eff}`")
    parts.append("")

    parts.append("## 六、世界规则（会自动生效，不要重复交代）\n")
    parts.append(
        "下列规则在每章开始时**自动**作用于状态。所以：**不要**再写「他困了」「他饿了」"
        "这类事件去手动改精力/动机——内核已经做了。你只需要在正文里**表现**出这些变化。\n"
    )
    for r in cfg.get("world") or []:
        if not isinstance(r, dict) or r.get("enabled") is False:
            continue
        parts.append(f"- **{r.get('name')}**：当 `{r.get('当')}` → {r.get('说明') or ''}")
    parts.append("")

    parts.append("## 七、变量约定（建议在工程里定义这些变量，规则才能生效）\n")
    for k, v in (cfg.get("变量约定") or {}).items():
        parts.append(f"- `{k}`：{v}")
    parts.append("")

    parts.append("## 八、输出要求\n")
    parts.append(
        "1. 每个文件用单独一个代码块，第一行写成 `文件名：条目名.大类.子类`；\n"
        "2. 只写条目，不写解释、不写「好的」这类客套；\n"
        "3. 抽不到的信息写 `　@待补`，**不要编造**；\n"
        "4. 人物状态里的字段名要和事件 `@效果` 里的一致；\n"
        "5. 关系条目的文件名必须是 `甲-乙.关系.关系网`，甲乙用 `-` 连接。\n"
    )
    return "\n".join(parts)


def spec_json() -> dict:
    """结构化版本（给程序用）。"""
    return {
        "version": 1,
        "name": "小说编程条目规范",
        "registry": files.registry_public(),
        "expression": {"变量": "v.名", "人物状态": "s.人物.字段", "关系": "r.甲-乙.字段",
                       "知识": "知(人物, 事实)", "运算": ["+", "-", "*", "/", "(", ")"],
                       "比较": ["==", "!=", ">=", "<=", ">", "<"],
                       "逻辑": ["且", "或", "非", "and", "or", "not"]},
        "effect": {"格式": "目标 运算 表达式", "运算": ["=", "+=", "-=", "*=", "/="],
                   "函数调用": "调用 函数名(参数,…)"},
        "functions": [f for f in (rules.load().get("fn") or []) if isinstance(f, dict)],
        "world_rules": [r for r in (rules.load().get("world") or []) if isinstance(r, dict)],
        "variables": rules.load().get("变量约定") or {},
        "text": spec_text(),
    }
