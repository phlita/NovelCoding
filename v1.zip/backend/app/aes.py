"""纯 Python AES-128/256 + GCM + CBC（零依赖）。

只为解密编辑器里那 1KB 不到的密文，性能完全够用。
移植自默认版 2.9 的 app/aes.py（未做改动）。
"""

_SBOX = [
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16,
]
_INV_SBOX = [0] * 256
for _i, _v in enumerate(_SBOX):
    _INV_SBOX[_v] = _i

_RCON = [0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36,0x6c,0xd8,0xab,0x4d]


def _xtime(a):
    a <<= 1
    return (a ^ 0x1b) & 0xff if a & 0x100 else a


def _gmul(a, b):
    p = 0
    for _ in range(8):
        if b & 1:
            p ^= a
        b >>= 1
        a = _xtime(a)
    return p


_MUL2 = [_xtime(i) for i in range(256)]
_MUL3 = [_xtime(i) ^ i for i in range(256)]
_MUL9 = [_gmul(i, 9) for i in range(256)]
_MUL11 = [_gmul(i, 11) for i in range(256)]
_MUL13 = [_gmul(i, 13) for i in range(256)]
_MUL14 = [_gmul(i, 14) for i in range(256)]


def expand_key(key):
    nk = len(key) // 4
    nr = nk + 6
    w = [list(key[4 * i:4 * i + 4]) for i in range(nk)]
    for i in range(nk, 4 * (nr + 1)):
        t = list(w[i - 1])
        if i % nk == 0:
            t = t[1:] + t[:1]
            t = [_SBOX[b] for b in t]
            t[0] ^= _RCON[i // nk - 1]
        elif nk > 6 and i % nk == 4:
            t = [_SBOX[b] for b in t]
        w.append([w[i - nk][j] ^ t[j] for j in range(4)])
    return w, nr


def _add_round_key(s, w, rnd):
    for c in range(4):
        for r in range(4):
            s[4 * c + r] ^= w[rnd * 4 + c][r]


def encrypt_block(rk, block):
    w, nr = rk
    s = list(block)
    _add_round_key(s, w, 0)
    for rnd in range(1, nr + 1):
        s = [_SBOX[b] for b in s]
        s = [s[0], s[5], s[10], s[15], s[4], s[9], s[14], s[3],
             s[8], s[13], s[2], s[7], s[12], s[1], s[6], s[11]]
        if rnd != nr:
            for c in range(4):
                a = s[4 * c:4 * c + 4]
                s[4 * c + 0] = _MUL2[a[0]] ^ _MUL3[a[1]] ^ a[2] ^ a[3]
                s[4 * c + 1] = a[0] ^ _MUL2[a[1]] ^ _MUL3[a[2]] ^ a[3]
                s[4 * c + 2] = a[0] ^ a[1] ^ _MUL2[a[2]] ^ _MUL3[a[3]]
                s[4 * c + 3] = _MUL3[a[0]] ^ a[1] ^ a[2] ^ _MUL2[a[3]]
        _add_round_key(s, w, rnd)
    return bytes(s)


def decrypt_block(rk, block):
    w, nr = rk
    s = list(block)
    _add_round_key(s, w, nr)
    for rnd in range(nr - 1, -1, -1):
        s = [s[0], s[13], s[10], s[7], s[4], s[1], s[14], s[11],
             s[8], s[5], s[2], s[15], s[12], s[9], s[6], s[3]]
        s = [_INV_SBOX[b] for b in s]
        _add_round_key(s, w, rnd)
        if rnd != 0:
            for c in range(4):
                a = s[4 * c:4 * c + 4]
                s[4 * c + 0] = _MUL14[a[0]] ^ _MUL11[a[1]] ^ _MUL13[a[2]] ^ _MUL9[a[3]]
                s[4 * c + 1] = _MUL9[a[0]] ^ _MUL14[a[1]] ^ _MUL11[a[2]] ^ _MUL13[a[3]]
                s[4 * c + 2] = _MUL13[a[0]] ^ _MUL9[a[1]] ^ _MUL14[a[2]] ^ _MUL11[a[3]]
                s[4 * c + 3] = _MUL11[a[0]] ^ _MUL13[a[1]] ^ _MUL9[a[2]] ^ _MUL14[a[3]]
    return bytes(s)


def aes_ctr_xor(rk, iv, data, start_counter=2):
    out = bytearray()
    counter = start_counter
    for i in range(0, len(data), 16):
        block = iv[:12] + counter.to_bytes(4, "big")
        ks = encrypt_block(rk, block)
        chunk = data[i:i + 16]
        out += bytes(a ^ b for a, b in zip(chunk, ks))
        counter = (counter + 1) & 0xffffffff
    return bytes(out)


def _ghash(h, data):
    y = 0
    for i in range(0, len(data), 16):
        blk = data[i:i + 16].ljust(16, b"\0")
        y ^= int.from_bytes(blk, "big")
        # GF(2^128) 乘法
        z = 0
        v = h
        for bit in range(127, -1, -1):
            if (y >> bit) & 1:
                z ^= v
            v = (v >> 1) ^ (0xe1000000000000000000000000000000 if v & 1 else 0)
        y = z
    return y.to_bytes(16, "big")


def gcm_decrypt(key, nonce, ciphertext, tag, aad=b""):
    """返回明文；认证失败返回 None。"""
    try:
        rk = expand_key(key)
        h = int.from_bytes(encrypt_block(rk, b"\0" * 16), "big")
        if len(nonce) == 12:
            j0 = nonce + b"\0\0\0\1"
        else:
            j0 = _ghash(h, nonce + b"\0" * ((16 - len(nonce) % 16) % 16)
                        + (len(nonce) * 8).to_bytes(8, "big"))
        padded_aad = aad + b"\0" * ((16 - len(aad) % 16) % 16)
        padded_ct = ciphertext + b"\0" * ((16 - len(ciphertext) % 16) % 16)
        lengths = (len(aad) * 8).to_bytes(8, "big") + (len(ciphertext) * 8).to_bytes(8, "big")
        s = _ghash(h, padded_aad + padded_ct + lengths)
        ek = encrypt_block(rk, j0)
        expect = bytes(a ^ b for a, b in zip(ek, s))
        if expect != tag:
            return None
        return aes_ctr_xor(rk, nonce, ciphertext, start_counter=2)
    except Exception:  # noqa: BLE001
        return None


def cbc_decrypt(key, iv, ciphertext):
    rk = expand_key(key)
    prev = iv
    out = bytearray()
    for i in range(0, len(ciphertext), 16):
        blk = ciphertext[i:i + 16]
        if len(blk) < 16:
            return None
        dec = decrypt_block(rk, blk)
        out += bytes(a ^ b for a, b in zip(dec, prev))
        prev = blk
    return bytes(out)
