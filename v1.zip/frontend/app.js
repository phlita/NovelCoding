/* 小说编程 v1 · 三栏工作台逻辑（Vue 3，无构建）。
   左栏文件树 / 中栏文本区 / 右栏对话与操作；顶部菜单 / 底部状态栏。 */
const { createApp, ref, reactive, computed, onMounted, watch, nextTick } = Vue;

/* 图标统一走 js/icons.js（Lucide）。这里只留一个转发，避免模板里到处写 window.* */
const ICONS = (window.LingshuIcon && window.LingshuIcon.KIND) || {};

async function api(method, url, body) {
  const opt = { method, headers: { "Content-Type": "application/json" } };
  if (body !== undefined) opt.body = JSON.stringify(body);
  const res = await fetch(url, opt);
  const ct = res.headers.get("content-type") || "";
  const data = ct.includes("json") ? await res.json() : await res.text();
  if (!res.ok) throw new Error((data && data.detail) || ("HTTP " + res.status));
  return data;
}

/** SSE 读取：后端事件格式 event:/data: 两行一组。 */
async function streamSSE(url, payload, onEvent) {
  const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" },
                                 body: JSON.stringify(payload) });
  const reader = res.body.getReader();
  const dec = new TextDecoder();
  let buf = "", evt = "message";
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += dec.decode(value, { stream: true });
    let nl;
    while ((nl = buf.indexOf("\n")) >= 0) {
      const line = buf.slice(0, nl).trim();
      buf = buf.slice(nl + 1);
      if (line.startsWith("event:")) { evt = line.slice(6).trim(); continue; }
      if (!line.startsWith("data:")) continue;
      let data = {};
      try { data = JSON.parse(line.slice(5).trim() || "{}"); } catch (e) { data = {}; }
      onEvent(evt, data);
    }
  }
}

createApp({
  setup() {
    /* ------------ 状态 ------------ */
    const menu = ref("");
    const projects = ref([]);
    const project = ref("");
    const registry = ref({});
    const treeData = reactive({ library: [], project: { src: [], build: [] } });
    const cur = ref(null);            // 当前文件（含 scope/rel/条目名/大类/子类）
    const content = ref("");
    const dirty = ref(false);
    const deps = ref([]);
    const depMissing = ref([]);
    const savedAt = ref("");
    const status = reactive({ model: "", version: "", root: "" });
    const toast = ref("");
    const ui = reactive({ help: false, newProject: false, newFile: false, newLibFile: false,
                          pull: false, summary: false, settings: false, newCat: "",
                          decompose: false, report: false, build: false, state: false,
                          merge: false, theme: false, layout: false,
                          rules: false, about: false, gen: false });

    /* ---------- 编辑区：行号 / 高亮 / 预览 / 配色 ---------- */
    const midTab = ref("code");                    // code | preview
    const curLine = ref(1);
    const codeEl = ref(null);
    const gutterEl = ref(null);
    const codeScrollEl = ref(null);
    const lineCount = computed(() => Math.max(1, (content.value || "").split("\n").length));
    const highlighted = computed(() => {
      const kind = cur.value ? cur.value.大类 : "";
      return window.LingshuHighlight.render(content.value, kind);
    });
    const previewHtml = computed(() => buildPreview(content.value, cur.value));
    const ai = ref({ ok: false, reason: "" });
    const aiClass = computed(() => (ai.value && ai.value.ok ? "ok" : "manual"));
    /* 右上角只显示通路短名：「本机 TraeCode（免 Key）·default」→「本机 TraeCode」 */
    const aiShort = computed(() => {
      const label = (ai.value && ai.value.label) || "";
      if (!label) return "手动模式";
      return label
        .replace(/[（(][^）)]*[）)]/g, "")   // 去掉括号注解
        .split(/[·・]/)[0]                    // 去掉 ·模型名
        .trim() || "手动模式";
    });
    const aiTip = computed(() => {
      if (!ai.value) return "";
      if (ai.value.manual) return "手动编辑模式：点击接入 AI";
      const model = ai.value.model ? `\n模型：${ai.value.model}` : "";
      return (ai.value.ok ? "已接入" : "未就绪") + "：点击打开模型设置" + model;
    });

    /* 配色 */
    const themes = ref([]);
    const tunables = ref([]);
    const themeName = ref("paper");
    const themeCustom = reactive({});
    const initTheme = () => {
      const T = window.LingshuTheme;
      if (!T) return;
      const cur0 = T.load();
      themeName.value = cur0.name;
      Object.assign(themeCustom, cur0.custom || {});
      themes.value = T.list();
      tunables.value = T.TUNABLES;
    };
    const themeChips = (id) => {
      const t = (window.LingshuTheme && window.LingshuTheme.THEMES[id]) || {};
      return { bg: t.vars?.["--panel"] || "#fff", ink: t.vars?.["--ink"] || "#000",
               accent: t.vars?.["--accent"] || "#888" };
    };
    const themeValue = (key) => themeCustom[key] || (window.LingshuTheme ? window.LingshuTheme.valueOf(key) : "#000000");
    const pickTheme = (id) => {
      themeName.value = id;
      window.LingshuTheme.apply(id, {});
      Object.keys(themeCustom).forEach(k => delete themeCustom[k]);
    };
    const setTune = (key, val) => {
      themeCustom[key] = val;
      window.LingshuTheme.apply(themeName.value, { ...themeCustom });
    };
    const resetTheme = () => {
      Object.keys(themeCustom).forEach(k => delete themeCustom[k]);
      window.LingshuTheme.reset(themeName.value);
    };
    const openTheme = () => { ui.theme = true; };

    /* ---------- 布局：面板显隐 / 重排 / 三栏宽度 ---------- */
    const L = () => window.LingshuLayout;
    const layout = reactive({
      visible: {}, order: { left: [], right: [] }, widths: { left: 250, right: 310 },
      heights: {}, collapsed: {},
    });
    const initLayout = () => {
      const Lm = L();
      if (!Lm) return;
      const s = Lm.load();
      Object.assign(layout.visible, s.visible);
      Object.assign(layout.heights, s.heights || {});
      Object.assign(layout.collapsed, s.collapsed || {});
      layout.order.left = s.order.left.slice();
      layout.order.right = s.order.right.slice();
      layout.widths.left = s.widths.left;
      layout.widths.right = s.widths.right;
    };

    /* 面板高度：折叠时只占标题栏高度；指定了 px 就固定；否则 flex 平分剩余 */
    const panelStyle = (id) => {
      if (layout.collapsed[id]) return { flex: "0 0 auto", minHeight: "0" };
      const h = layout.heights[id];
      if (h == null) return { flex: "1 1 0", minHeight: "90px" };
      return { flex: `0 0 ${h}px`, height: h + "px", minHeight: "90px" };
    };
    const isCollapsed = (id) => !!layout.collapsed[id];
    const toggleCollapse = (id) => {
      const next = !layout.collapsed[id];
      layout.collapsed[id] = next;
      L().setCollapsed(id, next);
      if (!next) nextTick(fitHeight);
    };

    /* 垂直拖动：调面板高度。拖动条紧跟在面板后面，取 previousElementSibling 即可 */
    const startResizeH = (id, ev) => {
      const startY = ev.clientY;
      const splitter = ev.currentTarget;
      const panelEl = splitter && splitter.previousElementSibling;
      const startH = panelEl ? panelEl.getBoundingClientRect().height
                             : (layout.heights[id] || 180);
      if (splitter && splitter.classList) splitter.classList.add("dragging");
      document.body.classList.add("resizing-h");
      const onMove = (e) => {
        // 往上拖 = 变高
        layout.heights[id] = L().clampH(startH - (e.clientY - startY));
      };
      const onUp = () => {
        if (layout.heights[id] != null) L().setHeight(id, layout.heights[id]);
        if (splitter && splitter.classList) splitter.classList.remove("dragging");
        document.body.classList.remove("resizing-h");
        window.removeEventListener("mousemove", onMove);
        window.removeEventListener("mouseup", onUp);
      };
      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup", onUp);
    };
    const showLeft = computed(() =>
      visibleAny(layout.order.left, layout.visible));
    const showRight = computed(() =>
      visibleAny(layout.order.right, layout.visible));
    function visibleAny(ids, vis) {
      // 布局还没初始化（order 为空）时视为全部显示，避免首帧闪隐藏
      if (!ids || !ids.length) return true;
      return ids.some(id => vis[id]);
    }
    const leftStyle = computed(() => ({ width: layout.widths.left + "px" }));
    const rightStyle = computed(() => ({ width: layout.widths.right + "px" }));
    /* 模板里直接写 order.left / visible['left.tree']，这里给两个只读别名 */
    const order = computed(() => layout.order);
    const visible = computed(() => layout.visible);

    const layoutPanels = computed(() =>
      (L() && L().PANELS) || []);

    const setPanelVisible = (id, v) => {
      layout.visible[id] = !!v;
      L().setVisible(id, !!v);
    };

    /* 拖拽重排：同组内交换位置 */
    const dragPid = ref("");
    const dragOver = ref("");
    const onDragStart = (pid, e) => {
      // 点在标题栏的按钮上不触发面板拖拽
      const target = e && e.target;
      if (target && target.closest && target.closest("button")) {
        e.preventDefault();
        return;
      }
      dragPid.value = pid;
      if (e && e.dataTransfer) {
        e.dataTransfer.effectAllowed = "move";
        try { e.dataTransfer.setData("text/plain", pid); } catch (err) { /* 忽略 */ }
      }
    };
    const onDragOver = (pid) => {
      if (!dragPid.value || dragPid.value === pid) return;
      if (groupOf(dragPid.value) !== groupOf(pid)) return;
      dragOver.value = pid;
    };
    const onDragLeave = (pid) => { if (dragOver.value === pid) dragOver.value = ""; };
    const onDrop = (pid) => {
      const from = dragPid.value;
      dragOver.value = "";
      if (!from || from === pid) return;
      const g = groupOf(pid);
      if (g !== groupOf(from)) return;
      const ids = layout.order[g].slice();
      const a = ids.indexOf(from), b = ids.indexOf(pid);
      if (a < 0 || b < 0) return;
      ids.splice(a, 1);
      ids.splice(b, 0, from);
      layout.order[g] = ids;
      L().setOrder(g, ids);
      dragPid.value = "";
    };
    const onDragEnd = () => { dragPid.value = ""; dragOver.value = ""; };
    const groupOf = (pid) => (pid || "").split(".")[0];

    /* 三栏宽度拖动 */
    const startResize = (which, ev) => {
      const startX = ev.clientX;
      const startW = layout.widths[which];
      const splitter = ev.currentTarget;
      if (splitter && splitter.classList) splitter.classList.add("dragging");
      document.body.classList.add("resizing");
      const onMove = (e) => {
        const dx = e.clientX - startX;
        const next = L().clamp(which, which === "left" ? startW + dx : startW - dx);
        layout.widths[which] = next;
      };
      const onUp = () => {
        L().setWidth(which, layout.widths[which]);
        if (splitter && splitter.classList) splitter.classList.remove("dragging");
        document.body.classList.remove("resizing");
        window.removeEventListener("mousemove", onMove);
        window.removeEventListener("mouseup", onUp);
        nextTick(fitHeight);
      };
      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup", onUp);
    };
    const resetLayout = () => {
      const s = L().reset();
      Object.assign(layout.visible, s.visible);
      Object.assign(layout.heights, s.heights || {});
      Object.assign(layout.collapsed, s.collapsed || {});
      layout.order.left = s.order.left.slice();
      layout.order.right = s.order.right.slice();
      layout.widths.left = s.widths.left;
      layout.widths.right = s.widths.right;
    };

    /* ---------- 模型切换 ---------- */
    const modelOptions = ref([]);
    const modelPick = ref("");
    const manualMode = computed(() => !!(ai.value && ai.value.manual));
    const currentModelLabel = computed(() => {
      const hit = modelOptions.value.find(m => m.id === modelPick.value);
      if (hit) return hit.label;
      return ai.value && ai.value.label ? ai.value.label : "—";
    });
    /* 下拉里一项的文字：名称 + 倍率 / 标签。倍率是 CodeBuddy 那边给的 x0.11 这种。 */
    const modelOptionText = (m) => {
      if (!m) return "";
      const bits = [];
      if (m.rate != null && m.rate !== "") bits.push("x" + m.rate);
      if (m.note) bits.push(m.note);
      return bits.length ? `${m.label}　${bits.join(" · ")}` : m.label;
    };
    const loadModels = async () => {
      try {
        const r = await api("GET", "/api/ai/choosable");
        modelOptions.value = r.options || [];
        const cur = r.current || "";
        if (cur && modelOptions.value.some(m => m.id === cur)) modelPick.value = cur;
        else modelPick.value = modelOptions.value.length ? modelOptions.value[0].id : "";
      } catch (e) { modelOptions.value = []; }
    };
    const chooseModel = async () => {
      try {
        const pid = (ai.value && ai.value.provider) || setProvider.value;
        await api("POST", "/api/settings", { llm_models: { [pid]: modelPick.value } });
        await loadHealth(); await loadAi(); await loadModels();
        say("模型已切换到 " + currentModelLabel.value);
      } catch (e) { say("切换失败：" + e.message); }
    };

    /* ---------- 预览：把条目渲染成可读结果 ---------- */
    const esc = (s) => String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

    function buildPreview(text, meta) {
      const src = String(text || "");
      if (!src.trim()) return `<div class="empty-hint">${esc("（空文件）")}</div>`;
      const lines = src.split("\n");
      const notes = [];      // @ 行
      const body = [];       // 正文行
      lines.forEach((l) => {
        if (/^\s*@/.test(l)) notes.push(l.trim());
        else body.push(l);
      });

      const title = (meta && (meta.条目名 || meta.name)) || "预览";
      const out = [`<div class="doc-title">${esc(title)}</div>`];

      // 无正文、只有注释 → 直接把注释块展示出来
      if (!body.some(l => l.trim())) {
        out.push(`<div class="note-block">${notes.map(n => esc(n)).join("<br>") || "（只有注释区）"}</div>`);
        return out.join("");
      }

      // 头像/地点/变量这类「键 值」文件 → 表格
      const kv = [];
      const prose = [];
      body.forEach((l) => {
        const s = l.trim();
        if (!s) return;
        const m = /^([^\s=　]{1,12})\s*[=　]\s*(.*)$/.exec(s);
        if (m && !/^[>「（]/.test(s)) kv.push([m[1], m[2]]);
        else prose.push(s);
      });

      if (kv.length && !prose.length) {
        out.push(`<div class="kv">${kv.map(([k, v]) =>
          `<div class="k">${esc(k)}</div><div class="v">${esc(v) || "　"}</div>`).join("")}</div>`);
      }

      if (prose.length) {
        const paras = prose.map((l) => {
          if (l.startsWith(">")) return `<p class="beat">${esc(l.replace(/^>\s*/, ""))}</p>`;
          if (/^[「『]/.test(l)) return `<p class="quote">${esc(l)}</p>`;
          if (/^[（(]/.test(l)) return `<p class="beat">${esc(l)}</p>`;
          return `<p>${esc(l)}</p>`;
        }).join("");
        out.push(`<div class="prose">${paras}</div>`);
      }

      if (notes.length) {
        out.push(`<div class="note-block"><b>注释区</b>（构建时不进正文）<br>${notes.map(esc).join("<br>")}</div>`);
      }
      return out.join("");
    }

    /* ---------- 编辑区：输入 / 光标 / 滚动同步 ---------- */
    const onInput = () => { dirty.value = true; checkDeps(true); };

    /* 从 CSS 变量读取度量，保证 JS 算的和样式表用的是同一组数字 */
    const codeMetrics = () => {
      const cs = getComputedStyle(document.documentElement);
      const num = (name, fallback) => {
        const v = parseFloat(cs.getPropertyValue(name));
        return Number.isFinite(v) ? v : fallback;
      };
      return { lineH: num("--code-line-h", 21), padY: num("--code-pad-y", 10) };
    };

    const updateCaret = (e) => {
      const el = e && e.target;
      if (!el || typeof el.selectionStart !== "number") return;
      curLine.value = (el.value.slice(0, el.selectionStart).split("\n").length) || 1;
    };

    /* 行号栏与高亮层跟着外层滚动容器走；textarea 自己不开滚动 */
    const syncScroll = () => {
      const sc = codeScrollEl.value;
      const g = gutterEl.value;
      if (sc && g) g.scrollTop = sc.scrollTop;
    };

    /* 按「行数 × 行高 + 上下内边距」精确撑高 textarea。 */
    const fitHeight = () => {
      const ta = codeEl.value;
      if (!ta) return;
      const { lineH, padY } = codeMetrics();
      const lines = Math.max(1, (ta.value || "").split("\n").length);
      const h = lines * lineH + padY * 2 + lineH;   // 多留一行，避免边界抖动
      ta.style.height = h + "px";
    };

    /* 对齐自检：量出高亮层与输入层实际的每行高度差。
       行号错位这类问题肉眼难判断是哪一层的问题，直接量出来最快。 */
    const alignDiag = ref("");
    const alignOk = ref(true);
    const runAlignCheck = () => { alignOk.value = checkAlign() !== false; };
    const checkAlign = () => {
      const layer = document.querySelector(".code-layer");
      const ta = codeEl.value;
      if (!layer || !ta) return;
      const cl = layer.querySelector(".cl");
      const cs = getComputedStyle(layer);
      const ts = getComputedStyle(ta);
      const layerLine = cl ? cl.getBoundingClientRect().height : 0;
      const taLine = parseFloat(ts.lineHeight) || 0;
      const taPadT = parseFloat(ts.paddingTop) || 0;
      const lyPadT = parseFloat(cs.paddingTop) || 0;
      const differs = Math.abs(layerLine - taLine) > 0.5 || Math.abs(taPadT - lyPadT) > 0.5;
      alignDiag.value =
        `行高：高亮 ${layerLine.toFixed(1)}px / 输入 ${taLine.toFixed(1)}px　` +
        `上内边距：${lyPadT.toFixed(1)} / ${taPadT.toFixed(1)}　` +
        (differs ? "✗ 不一致" : "✓ 一致");
      return !differs;
    };
    const report = reactive({ 工程: "", 模式: "", 章节数: 0, 条目: [], 冲突: [], 交叉核对建议: {} });
    const bd = reactive({ mode: "rules", strict: false, scope: "all", chapter: "", chapters: [],
                          log: [], report: null, busy: false });
    const stateText = ref("");
    const mg = reactive({ suggest: {}, report: null, from: "", to: "", rewrite: true, busy: false });
    const dec = reactive({ text: "", path: "", project: "", 书名: "", 类型: "", mode: "rules",
                           max: 0, fileName: "", preview: null, log: [], report: null, busy: false });
    const np = reactive({ name: "", 书名: "", 类型: "", 梗概: "" });
    const nf = reactive({ cat: "人物", sub: "属性", name: "" });
    const pullSel = ref([]); const pullRename = ref("");
    const summary = reactive({ stats: {}, by_cat: {}, invalid: [] });
    const chatMsgs = ref([]); const chatText = ref(""); const withFile = ref(true);
    const withSpec = ref(true);          // 对话时是否带上条目规范（让 AI 直接产出条目）
    const lastAsk = ref("");             // 最近一次提问，供「重试」用
    const streaming = ref(false);
    const providers = ref([]); const setProvider = ref("manual"); const setKey = ref(""); const setModel = ref("");
    const probe = ref(null); const probing = ref(false); const diag = ref(null);
    const cus = reactive({ id: "", url: "", model: "" });

    /* 图标：返回 <img> 标签（Lucide，经 jsDelivr） */
    const icon = (name) => (window.LingshuIcon ? window.LingshuIcon.icon(name) : "");
    const kindIcon = (cat) => (window.LingshuIcon ? window.LingshuIcon.kindIcon(cat) : "file");
    const ico = (cat) => ICONS[cat] || "file";
    const curProvider = computed(() => providers.value.find(p => p.id === setProvider.value) || {});
    const catExample = (cat) => ({ 人物: "李三", 关系: "李三-赵爷", 事件: "第一次试探", 决策: "信任评估",
      剧本: "第01章", 地点: "当铺", 资产: "字据", 变量: "胆量", 时间线: "主线", 行为: "紧张摸袖口",
      文风: "冷调", 世界: "通用时代规则", 工程: "工程名" })[cat] || "条目名";

    const say = (msg) => { toast.value = msg; setTimeout(() => { toast.value = ""; }, 2200); };
    const toggle = (m) => { menu.value = menu.value === m ? "" : m; };

    /* ------------ 载入 ------------ */
    const refreshAll = async () => {
      projects.value = (await api("GET", "/api/projects")).projects;
      registry.value = await api("GET", "/api/registry");
      await loadTree();
    };
    const loadTree = async () => {
      const t = await api("GET", `/api/tree?project=${encodeURIComponent(project.value || "")}`);
      treeData.library = t.library;
      treeData.project = t.project;
    };
    const openProject = async (name) => {
      project.value = name; menu.value = "";
      cur.value = null; content.value = ""; dirty.value = false;
      await loadTree(); say(`已打开工程「${name}」`);
    };

    /* ------------ 文件 ------------ */
    const open = async (scope, rel) => {
      if (dirty.value && !confirm("当前文件有未保存改动，放弃并打开其它文件？")) return;
      try {
        const f = await api("GET", `/api/file?scope=${scope}&project=${encodeURIComponent(project.value)}&path=${encodeURIComponent(rel)}`);
        cur.value = f; content.value = f.content || ""; deps.value = f.依赖 || []; dirty.value = false;
        curLine.value = 1;
        checkDeps();
        // 等 DOM 更新后再量高度
        setTimeout(fitHeight, 0);
      } catch (e) { say("打开失败：" + e.message); }
    };
    const save = async () => {
      if (!cur.value) return;
      if (cur.value.scope === "build") return say("构建产物是生成物：改条目文件后重新构建，不要直接改 build/");
      try {
        const f = await api("PUT", "/api/file", { scope: cur.value.scope, project: project.value,
          path: cur.value.rel, content: content.value });
        cur.value = f; dirty.value = false; deps.value = f.依赖 || [];
        savedAt.value = new Date().toLocaleTimeString();
        checkDeps(); await loadTree(); say("已保存 " + f.name);
      } catch (e) { say("保存失败：" + e.message); }
    };
    const createFile = async () => {
      try {
        const scope = ui.newLibFile ? "library" : "project";
        if (scope === "project" && !project.value) return say("先打开工程");
        const f = await api("POST", "/api/file/new", { scope, project: project.value,
          大类: nf.cat, 子类: nf.sub, 条目名: nf.name.trim() });
        ui.newFile = ui.newLibFile = false; nf.name = "";
        await loadTree(); await open(f.scope, f.rel);
      } catch (e) { say("新建失败：" + e.message); }
    };
    const renameFile = async () => {
      if (!cur.value) return say("先打开一个文件");
      const nn = prompt("新文件名（保持「条目名.大类.子类」格式）", cur.value.name);
      if (!nn) return;
      try {
        const f = await api("POST", "/api/file/rename", { scope: cur.value.scope, project: project.value,
          path: cur.value.rel, new: nn });
        await loadTree(); await open(f.scope, f.rel);
      } catch (e) { say("重命名失败：" + e.message); }
    };
    const deleteFile = async () => {
      if (!cur.value) return say("先打开一个文件");
      if (!confirm(`删除 ${cur.value.name}？`)) return;
      try {
        await api("POST", "/api/file/delete", { scope: cur.value.scope, project: project.value, path: cur.value.rel });
        cur.value = null; content.value = ""; await loadTree(); say("已删除");
      } catch (e) { say("删除失败：" + e.message); }
    };
    const formatFile = () => {
      content.value = (content.value || "").split("\n")
        .map((l) => l.replace(/\s+$/g, "")).join("\n").replace(/\n{3,}/g, "\n\n");
      dirty.value = true; say("已整理（去尾空格 / 压缩空行），记得保存");
    };
    const copyPath = async () => {
      if (!cur.value) return;
      const p = `${cur.value.scope === "library" ? "library" : "projects/" + project.value + "/" + (cur.value.scope === "build" ? "build" : "src")}/${cur.value.rel}`;
      try { await navigator.clipboard.writeText(p); say("已复制：" + p); } catch (e) { say(p); }
    };
    const insertHeader = () => {
      const name = cur.value ? cur.value.条目名 : "条目";
      const stamp = `@条目 ${name}\n@来源 ${project.value ? "工程「" + project.value + "」" : "公共库"}\n`;
      if (content.value.startsWith("@条目")) return say("文件头已存在");
      content.value = stamp + content.value; dirty.value = true; say("已插入文件头注释");
    };

    /* ------------ 依赖校验（解析编辑器当前内容，不依赖加载快照） ------------ */
    const DEP_LINE = /^\s*@(导入|import|依赖|引用)\s+(.+?)\s*$/i;
    const checkDeps = async (silent) => {
      const found = [];
      (content.value || "").split("\n").forEach((l) => {
        const m = l.match(DEP_LINE);
        if (m) found.push(m[2].trim());
      });
      deps.value = found;
      depMissing.value = [];
      if (!found.length) return;
      const names = new Set();
      const scan = (nodes) => nodes.forEach(n => n.type === "dir" ? scan(n.children || []) : names.add(n.name));
      scan(treeData.library); scan(treeData.project.src);
      depMissing.value = found.filter((d) => !names.has(d) && ![...names].some(n => n.startsWith(d.split(".")[0])));
      if (depMissing.value.length && !silent) say("依赖缺失：" + depMissing.value.join("、"));
    };

    /* ------------ 双库传递 ------------ */
    const pullOne = async (f) => {
      try {
        await api("POST", "/api/transfer/pull", { project: project.value, paths: [f.rel] });
        await loadTree(); say("已拉入项目：" + f.条目名);
      } catch (e) { say("拉入失败：" + e.message); }
    };
    const doPull = async () => {
      try {
        const r = await api("POST", "/api/transfer/pull", { project: project.value, paths: pullSel.value,
          rename: pullRename.value.trim() });
        ui.pull = false; pullSel.value = []; pullRename.value = "";
        await loadTree(); say(`已拉入 ${r.files.length} 个条目`);
      } catch (e) { say("拉入失败：" + e.message); }
    };
    const promote = async () => {
      if (!cur.value || cur.value.scope !== "project") return say("请先打开本项目里的文件");
      const name = prompt("存入公共库的条目名（可改，便于复用）", cur.value.条目名);
      if (!name) return;
      const generalize = confirm("是否泛化？（把本工程人物名替换成 {{人物1}} 之类占位符，便于跨工程复用）");
      try {
        const f = await api("POST", "/api/transfer/promote", { project: project.value, path: cur.value.rel,
          name, generalize });
        await loadTree(); say("已存入公共库：" + f.name);
      } catch (e) { say("存入失败：" + e.message); }
    };

    /* ------------ 工程操作 ------------ */
    const createProject = async () => {
      try {
        await api("POST", "/api/projects", { ...np });
        ui.newProject = false;
        const name = np.name; np.name = np.书名 = np.类型 = np.梗概 = "";
        await refreshAll(); await openProject(name);
      } catch (e) { say("创建失败：" + e.message); }
    };
    const renameProject = async () => {
      const nn = prompt("新工程名", project.value); if (!nn) return;
      try { await api("POST", `/api/projects/${encodeURIComponent(project.value)}/rename`, { new: nn });
        project.value = nn; await refreshAll(); say("已重命名");
      } catch (e) { say("重命名失败：" + e.message); }
    };
    const deleteProject = async () => {
      if (!confirm(`删除工程「${project.value}」及其全部文件？不可恢复。`)) return;
      try { await api("DELETE", `/api/projects/${encodeURIComponent(project.value)}`);
        project.value = ""; cur.value = null; content.value = ""; await refreshAll(); say("已删除工程");
      } catch (e) { say("删除失败：" + e.message); }
    };
    const showSummary = async () => {
      try { Object.assign(summary, await api("GET", `/api/projects/${encodeURIComponent(project.value)}/summary`));
        ui.summary = true; } catch (e) { say(e.message); }
    };

    /* ------------ 拆解器：导入整本小说 ------------ */
    const hasNovel = computed(() => !!(dec.text && dec.text.trim()) || !!dec.path.trim());

    const pickNovelFile = async (e) => {
      const file = e.target.files && e.target.files[0];
      if (!file) return;
      const buf = await file.arrayBuffer();
      let text = "";
      try {
        text = new TextDecoder("utf-8", { fatal: true }).decode(buf);
      } catch (err) {
        try { text = new TextDecoder("gb18030").decode(buf); }
        catch (err2) { text = new TextDecoder("utf-8").decode(buf); }
      }
      dec.text = text; dec.fileName = file.name; dec.path = ""; dec.preview = null; dec.report = null;
      if (!dec.project) dec.project = file.name.replace(/\.(txt|md)$/i, "").slice(0, 20);
      say(`已读入 ${file.name}（${text.length} 字）`);
    };

    const previewNovel = async () => {
      try {
        dec.busy = true;
        dec.preview = await api("POST", "/api/decompose/preview",
          { text: dec.text, path: dec.path, max_chapters: dec.max || 0 });
      } catch (e) { say("预览失败：" + e.message); }
      finally { dec.busy = false; }
    };

    const runDecompose = async () => {
      if (!dec.project.trim()) return say("请填工程名");
      dec.busy = true; dec.log = []; dec.report = null;
      try {
        await streamSSE("/api/decompose/run",
          { text: dec.text, path: dec.path, project: dec.project.trim(), mode: dec.mode,
            max_chapters: dec.max || 0, 书名: dec.书名, 类型: dec.类型 },
          (evt, data) => {
            if (evt === "log") dec.log.push(data.text);
            else if (evt === "report") { dec.report = data; Object.assign(report, data); }
            else if (evt === "message") dec.log.push("⚠ " + (data.error || "失败"));
          });
      } catch (e) { dec.log.push("⚠ " + e.message); }
      finally { dec.busy = false; }
    };

    const openDecomposed = async () => {
      const name = (dec.report && dec.report.工程) || dec.project.trim();
      ui.decompose = false;
      await refreshAll(); await openProject(name);
      say(`已打开拆解出的工程「${name}」，共 ${(dec.report && dec.report.条目.length) || 0} 个条目`);
    };

    const openReport = async (r) => {
      const target = r || dec.report || project.value;
      try {
        if (target && typeof target === "object") Object.assign(report, target);
        else if (target) Object.assign(report, await api("GET", `/api/decompose/report?project=${encodeURIComponent(target)}`));
        else return say("先打开一个工程，或先做一次拆解");
        ui.report = true;
      } catch (e) { say(e.message); }
    };

    /* ------------ 构建器：条目 → 正文 ------------ */
    const openBuild = async () => {
      if (!project.value) return say("先打开一个工程");
      ui.build = true;
      // 章节列表：实时读后端目录树（不用缓存的 treeData，免得刚改完文件选不到新章）
      try {
        const t = await api("GET", `/api/tree?project=${encodeURIComponent(project.value)}`);
        const names = new Set();
        const scan = (nodes) => (nodes || []).forEach(n => {
          if (n.type === "dir") return scan(n.children);
          const m = /^(.+?)\.剧本\.正文$/.exec(n.name || "");
          if (m) names.add(m[1]);
          if (n.scope === "build" && /^第.+\.txt$/.test(n.name || "")) names.add(n.name.replace(/\.txt$/, ""));
        });
        scan(t.project && t.project.src); scan(t.project && t.project.build);
        bd.chapters = [...names].sort();
        if (!bd.chapters.includes(bd.chapter)) bd.chapter = bd.chapters[0] || "";
      } catch (e) { bd.chapters = []; }
    };

    const objOpen = (name) => {
      if (!project.value) return say("先打开一个工程");
      ui.build = false;
      open("build", name);
    };

    const buildBook = async () => {
      if (!project.value) return say("先打开一个工程");
      const single = bd.scope === "one";
      if (single && !bd.chapter) return say("先选一个章节");
      bd.busy = true; bd.log = []; bd.report = null;
      try {
        await streamSSE("/api/build",
          { project: project.value, mode: bd.mode, strict: bd.strict === true || bd.strict === "true",
            single, chapters: single ? [bd.chapter] : null },
          (evt, data) => {
            if (evt === "log") bd.log.push(data.text);
            else if (evt === "report") bd.report = data;
            else if (evt === "message") bd.log.push("⚠ " + (data.error || "构建失败"));
          });
        await loadTree();
        if (bd.report) {
          const st = bd.report.统计;
          say(`构建完成：${st.章节数} 章 / ${st.总字数} 字，门禁 ${bd.report.门禁.结果}`);
        }
      } catch (e) { bd.log.push("⚠ " + e.message); }
      finally { bd.busy = false; }
    };

    const openState = async () => {
      if (!project.value) return say("先打开一个工程");
      try {
        const data = await api("GET", `/api/state?project=${encodeURIComponent(project.value)}`);
        stateText.value = JSON.stringify(data, null, 2);
        ui.state = true;
      } catch (e) { say(e.message); }
    };

    /* ------------ 实体归并 ------------ */
    const loadMergeSuggest = async () => {
      if (!project.value) return say("先打开一个工程");
      try {
        mg.busy = true;
        const s = await api("GET", `/api/merge/suggest?project=${encodeURIComponent(project.value)}`);
        (s.候选 || []).forEach(c => { c._sel = c.置信度 === "高"; });   // 高置信度默认勾上
        mg.suggest = s;
      } catch (e) { say("扫描失败：" + e.message); }
      finally { mg.busy = false; }
    };

    const openMerge = async () => {
      if (!project.value) return say("先打开一个工程");
      ui.merge = true; mg.report = null; mg.from = mg.to = "";
      await loadMergeSuggest();
    };

    const runMerge = async () => {
      const picked = (mg.suggest.候选 || []).filter(c => c._sel);
      const mapping = picked.map(c => ({ 旧名: c.建议保留 === c.甲 ? c.乙 : c.甲, 新名: c.建议保留 }));
      if (mg.from.trim() && mg.to.trim()) mapping.push({ 旧名: mg.from.trim(), 新名: mg.to.trim() });
      if (!mapping.length) return say("没有可归并的项：勾选候选，或手动填一条");
      if (!confirm(`将执行 ${mapping.length} 条归并，旧文件会被删除（可在 state/归并报告.json 查看记录）。继续？`)) return;
      try {
        mg.busy = true;
        mg.report = await api("POST", "/api/merge/apply", {
          project: project.value, mapping, rewrite_text: mg.rewrite });
        mg.from = mg.to = "";
        await loadTree(); await loadMergeSuggest();
        say(`归并完成：重写 ${(mg.report.重写文件 || []).length} 个文件，删除 ${(mg.report.删除文件 || []).length} 个`);
      } catch (e) { say("归并失败：" + e.message); }
      finally { mg.busy = false; }
    };

    /* 规范文本：只在需要时拉一次，之后复用 */
    const specCache = ref("");

    /* ------------ AI 全自动生成 ------------ */
    const gen = reactive({ task: "", dry: false, overwrite: false, log: [], report: null, busy: false });
    const runGenerate = async () => {
      if (!project.value) return say("先打开一个工程");
      if (!gen.task.trim()) return say("先写要生成什么");
      gen.busy = true; gen.log = []; gen.report = null;
      try {
        await streamSSE("/api/ai/generate",
          { project: project.value, task: gen.task.trim(),
            dry_run: gen.dry, overwrite: gen.overwrite },
          (evt, d) => {
            if (evt === "log") gen.log.push(d.text);
            else if (evt === "report") gen.report = d;
            else if (evt === "message") gen.log.push("⚠ " + (d.error || "生成失败"));
          });
        if (gen.report) {
          const w = (gen.report.写入 || []).length, s = (gen.report.跳过 || []).length;
          say(`生成完成：写入 ${w} 个，跳过 ${s} 个`);
        }
      } catch (e) { gen.log.push("⚠ " + e.message); }
      finally { gen.busy = false; }
    };
    const afterGenerate = async () => {
      await loadTree();
      ui.gen = false;
    };

    /* ------------ 内置规则 ------------ */
    const rulesData = reactive({ world: [], fn: [], 变量约定: {}, version: 0, 用默认兜底: false });
    let keySeq = 0;
    const newKey = () => "k" + (++keySeq);
    const prep = (list) => (list || []).map(r => ({
      ...r,
      _key: r.id || newKey(),
      enabled: r.enabled !== false,
      _body: (r.则 || r.then || []).join("\n"),
      _params: (r.参数 || r.params || []).join(", "),
    }));
    const hydrateRules = (d) => {
      rulesData.world = prep(d.world);
      rulesData.fn = prep(d.fn);
      rulesData.变量约定 = d.变量约定 || {};
      rulesData.version = d.version || 0;
      rulesData.用默认兜底 = !!d.用默认兜底;
    };
    const openRules = async () => {
      try {
        hydrateRules(await api("GET", "/api/rules"));
        ui.rules = true;
      } catch (e) { say("读取规则失败：" + e.message); }
    };
    const addRule = (kind) => {
      if (kind === "world") {
        rulesData.world.push({
          _key: newKey(), id: "rule_" + Date.now().toString(36), name: "新规则",
          enabled: true, 当: "", 则: [], _body: "", 说明: "",
        });
      } else {
        rulesData.fn.push({
          _key: newKey(), id: "fn_" + Date.now().toString(36), name: "新函数",
          enabled: true, 参数: [], _params: "", 则: [], _body: "", 说明: "",
        });
      }
    };
    const delRule = (kind, i) => {
      const list = kind === "world" ? rulesData.world : rulesData.fn;
      const name = (list[i] && list[i].name) || "这一条";
      if (!confirm(`删除「${name}」？保存后生效。`)) return;
      list.splice(i, 1);
    };
    const saveRules = async () => {
      try {
        const payload = {
          world: rulesData.world.map(r => ({
            id: r.id, name: r.name, enabled: r.enabled !== false,
            当: r.当, 则: r.则 || [], 说明: r.说明 || "",
          })),
          fn: rulesData.fn.map(f => ({
            id: f.id, name: f.name, enabled: f.enabled !== false,
            参数: f.参数 || [], 则: f.则 || [], 说明: f.说明 || "",
          })),
        };
        hydrateRules(await api("POST", "/api/rules", payload));
        specCache.value = "";            // 规则变了，规范缓存作废
        say(rulesData.用默认兜底
          ? "规则已清空：将使用默认兜底规则"
          : "规则已保存，下次构建生效");
      } catch (e) { say("保存规则失败：" + e.message); }
    };
    const resetRules = async () => {
      if (!confirm("恢复内置默认规则？当前修改会丢掉。")) return;
      try {
        hydrateRules(await api("POST", "/api/rules/reset"));
        specCache.value = "";
        say("已恢复默认规则");
      } catch (e) { say("恢复失败：" + e.message); }
    };

    /* ------------ 对话 ------------ */
    const send = async (retryText) => {
      const text = (retryText != null ? retryText : chatText.value).trim();
      if (!text || streaming.value) return;
      if (ai.value && !ai.value.ok) return say("还没有接入 AI：" + (ai.value.reason || ""));
      lastAsk.value = text;
      chatMsgs.value.push({ role: "user", content: text });
      if (retryText == null) chatText.value = "";
      streaming.value = true;
      const messages = chatMsgs.value.filter(m => m.role !== "system")
        .map(m => ({ role: m.role, content: m.content }));
      const idx = chatMsgs.value.push({ role: "assistant", content: "", error: "", retry: false }) - 1;
      const box = chatMsgs.value[idx];
      try {
        const spec = await loadSpec();
        const system = spec || "你是小说编程工作台的助手：协助编写条目文件、检查设定一致性。";
        // 当前文件放在 user 消息里，不塞进 system：system 只放「怎么写」的规范，
        // user 放「照着写什么」。混在一起会让模型把规范当任务，一直思考不产出。
        if (withFile.value && cur.value) {
          messages[messages.length - 1] = {
            role: "user",
            content: `${text}\n\n【当前文件】${cur.value.name}\n${content.value || ""}`,
          };
        }
        await streamSSE("/api/chat/stream", { messages, system },
          (evt, d) => {
            if (evt === "delta") box.content += d.text || "";
            else if (evt === "message") {
              box.error = d.error || "调用失败";
              box.retry = !!d.retry;
            }
          });
      } catch (e) {
        box.error = e.message;
        box.retry = true;
      }
      finally { streaming.value = false; }
    };
    const retryLast = () => { if (lastAsk.value) send(lastAsk.value); };

    /* 把 AI 回复写成条目文件。
       优先按「文件名：xxx」解析出多个条目；解析不出来时，若当前开着文件，
       就整体写进当前文件。 */
    const applyReply = async (text) => {
      if (!project.value) return say("先打开一个工程");
      if (!text || !text.trim()) return;
      try {
        // 先按多条目解析
        let r = await api("POST", "/api/ai/apply", {
          project: project.value, text, overwrite: false });
        if ((r.写入 || []).length) {
          await loadTree();
          say(`已写入 ${r.写入.length} 个条目：${r.写入.map(w => w.文件名).join("、")}`);
          return;
        }
        // 解析不出来：写进当前文件（如果开着）
        if (cur.value && cur.value.scope === 'project') {
          if (!confirm(`没有解析出条目文件。要把这段内容整体写进「${cur.value.name}」吗？（会覆盖现有内容）`)) return;
          r = await api("POST", "/api/ai/apply", {
            project: project.value, text, target: cur.value.name, overwrite: true });
          await open('project', cur.value.rel);
          say("已写入当前文件");
          return;
        }
        const skipped = (r.跳过 || []).map(s => `${s.文件名}（${s.原因}）`).join("、");
        say(skipped ? "没有可写入的条目：" + skipped : "回复里没有识别出条目文件");
      } catch (e) { say("写入失败：" + e.message); }
    };

    /* 规范文本：只在需要时拉一次，之后复用 */
    const loadSpec = async () => {
      if (specCache.value) return specCache.value;
      if (!withSpec.value) return "";
      try {
        const res = await fetch("/api/ai/spec");
        if (!res.ok) return "";
        specCache.value = await res.text();
        return specCache.value;
      } catch (e) { return ""; }
    };
    const insert = (txt) => { if (!cur.value) return say("先打开文件"); content.value = txt; dirty.value = true; setTimeout(fitHeight, 0); say("已插入正文（记得 Ctrl+S）"); };
    const append = (txt) => { if (!cur.value) return say("先打开文件"); content.value = (content.value || "") + "\n" + txt; dirty.value = true; setTimeout(fitHeight, 0); say("已追加（记得 Ctrl+S）"); };

    /* ------------ 设置 ------------ */
    const loadHealth = async () => {
      try {
        const h = await api("GET", "/api/health");
        status.model = h.provider.label + (h.provider.model ? "·" + h.provider.model : "");
        status.version = h.version; status.root = h.root;
      } catch (e) { status.model = "未连接"; }
    };
    const loadAi = async () => {
      try {
        const s = await api("GET", "/api/ai/status");
        ai.value = { ok: s.ok, reason: s.reason, manual: s.manual, label: s.label,
                     provider: s.provider, model: s.model };
      } catch (e) {
        ai.value = { ok: false, reason: "读取 AI 状态失败：" + e.message };
      }
    };
    const openSettings = async () => {
      try {
        const s = await api("GET", "/api/settings");
        providers.value = s.providers;
        setProvider.value = s.llm_provider || "manual";
        probe.value = null; diag.value = null;
        ui.settings = true;
      } catch (e) { say("读取设置失败：" + e.message); }
    };
    const saveSettings = async () => {
      try {
        await api("POST", "/api/settings", { llm_provider: setProvider.value,
          llm_keys: { [setProvider.value]: setKey.value || null },
          llm_models: { [setProvider.value]: setModel.value || null } });
        await loadHealth(); await loadAi(); await loadModels();
        ui.settings = false; say("设置已应用");
      } catch (e) { say("保存设置失败：" + e.message); }
    };
    const probeLocal = async () => {
      const which = curProvider.value && curProvider.value.api_style;
      if (which !== "codebuddy" && which !== "trae") return;
      try {
        probing.value = true; probe.value = null; diag.value = null;
        const r = await api("POST", "/api/ai/probe", { which, force: true });
        probe.value = r;
        if (r.ok) say(`已找到 ${r.editor} 的登录`);
      } catch (e) { say("扫描失败：" + e.message); }
      finally { probing.value = false; }
    };
    /* 诊断：直接看网关到底回了什么（结构摘要，不含令牌） */
    const diagnoseLocal = async () => {
      const which = curProvider.value && curProvider.value.api_style;
      if (which !== "codebuddy" && which !== "trae") return;
      try {
        probing.value = true; diag.value = null;
        diag.value = await api("GET", `/api/ai/diag?which=${which}`);
      } catch (e) { say("诊断失败：" + e.message); }
      finally { probing.value = false; }
    };
    const addCustom = async () => {
      if (!cus.id || !cus.url) return say("接口名与 base_url 必填");
      try {
        await api("POST", "/api/settings", { llm_custom: { [cus.id]: { label: cus.id, base_url: cus.url,
          api_style: "openai", needs_key: true, default_model: cus.model,
          models: [{ id: cus.model, label: cus.model }] } } });
        cus.id = cus.url = cus.model = ""; await openSettings(); say("自定义接口已保存");
      } catch (e) { say("保存失败：" + e.message); }
    };

    document.addEventListener("click", (e) => {
      if (e.target instanceof Element && e.target.closest(".menubar")) return;
      menu.value = "";
    });
    document.addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "s") { e.preventDefault(); save(); }
    });

    onMounted(async () => {
      initTheme();
      initLayout();
      await refreshAll(); await loadHealth(); await loadAi(); await loadModels();
      // 手动模式的默认工程：首次进来直接打开，省得面对空工作台
      if (!project.value && projects.value.length) {
        const starter = projects.value.find(p => p.name === "我的第一部小说") || projects.value[0];
        await openProject(starter.name);
        // 自动打开第一个条目，让代码区/预览区立刻有内容
        const src = treeData.project.src || [];
        const pick = src.find(n => n.type !== "dir") ||
          (src.find(n => n.type === "dir") || {}).children?.[0];
        if (pick) await open(pick.scope, pick.rel);
      }
      window.addEventListener("resize", fitHeight);
      // 内容或文件变化后重新量高度（高亮层与输入层必须等高才能对齐）
      watch([content, () => cur.value], () => nextTick(() => { fitHeight(); runAlignCheck(); }));
      watch(midTab, (v) => { if (v === "code") nextTick(() => { fitHeight(); runAlignCheck(); }); });
    });

    return { menu, toggle, projects, project, registry, treeData, cur, content, dirty, deps, depMissing,
      savedAt, status, toast, ui, np, nf, pullSel, pullRename, summary, chatMsgs, chatText, withSpec,
      withFile,
      streaming, providers, setProvider, setKey, setModel, cus, ico, curProvider, catExample,
      report, dec, hasNovel, pickNovelFile, previewNovel, runDecompose, openDecomposed, openReport,
      bd, stateText, openBuild, objOpen, buildBook, openState,
      mg, openMerge, loadMergeSuggest, runMerge,
      // 编辑区 / 预览 / 配色 / AI 状态
      midTab, curLine, codeEl, gutterEl, codeScrollEl, lineCount, highlighted, previewHtml,
      ai, aiClass, aiShort, aiTip, loadAi, probe, probing, probeLocal, diag, diagnoseLocal,
      themes, tunables, themeName, themeCustom, themeChips, themeValue, pickTheme, setTune,
      resetTheme, openTheme,
      onInput, updateCaret, syncScroll, fitHeight, alignDiag, alignOk, runAlignCheck,
      // 布局：面板显隐 / 重排 / 三栏宽度
      layout, layoutPanels, showLeft, showRight, leftStyle, rightStyle,
      order, visible, panelStyle, isCollapsed, toggleCollapse, startResizeH,
      icon, kindIcon,
      setPanelVisible, resetLayout, dragOver, onDragStart, onDragOver, onDragLeave,
      onDrop, onDragEnd, startResize,
      // 模型切换
      modelOptions, modelPick, manualMode, currentModelLabel, modelOptionText, loadModels, chooseModel,
      // 内置规则
      rulesData, openRules, saveRules, resetRules, addRule, delRule,
      // AI 全自动生成
      gen, runGenerate, afterGenerate,
      refreshAll, openProject, open, save, createFile, renameFile, deleteFile, formatFile, copyPath,
      insertHeader, checkDeps, pullOne, doPull, promote, createProject, renameProject, deleteProject,
      showSummary, send, retryLast, applyReply, insert, append, openSettings, saveSettings, addCustom };
  },
})
  .component("modal", {
    emits: ["close"],
    template: `<div class="overlay" @click.self="$emit('close')"><div class="box"><slot></slot></div></div>`,
  })
  .mount("#app");
