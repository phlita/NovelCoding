/* 图标：Lucide（ISC 许可证，免费商用）
   https://lucide.dev · CDN: https://cdn.jsdelivr.net/npm/lucide-static@latest/icons/

   为什么用 <img src> 而不是内联 SVG：
   · 内联 SVG 会被 Vue 的模板编译器当作组件解析，容易报错；
   · <img> 不参与模板解析，也能被浏览器缓存；
   · 换 CDN 只需改一个常量。

   离线兜底：CDN 不可达时 img 加载失败，用 onerror 回落到内置的几个简单字形，
   界面不会出现空方块。 */
(function () {
  "use strict";

  const BASE = "https://cdn.jsdelivr.net/npm/lucide-static@0.468.0/icons/";
  const SIZE = 14;

  /* 只在这里登记用到的图标，避免到处写字符串 */
  const ICONS = {
    "folder-tree": "folder-tree",
    "package": "package",
    "library": "library",
    "plus": "plus",
    "arrow-down-to-line": "arrow-down-to-line",
    "chevron-right": "chevron-right",
    "chevron-down": "chevron-down",
    "file": "file",
    "user": "user",
    "users": "users",
    "map-pin": "map-pin",
    "git-branch": "git-branch",
    "variable": "variable",
    "split": "split",
    "repeat": "repeat",
    "palette": "palette",
    "scroll-text": "scroll-text",
    "globe": "globe",
    "box": "box",
    "clock": "clock",
    "settings": "settings",
    "sparkles": "sparkles",
    "play": "play",
  };

  /* 兜底字形：CDN 挂了也不至于空白 */
  const FALLBACK = {
    "folder-tree": "▤", "package": "▦", "library": "▥", "plus": "+",
    "arrow-down-to-line": "↓", "chevron-right": "▸", "chevron-down": "▾",
    "file": "▤", "user": "☺", "users": "☻", "map-pin": "⌂", "git-branch": "⇄",
    "variable": "𝑥", "split": "⑂", "repeat": "↻", "palette": "❦",
    "scroll-text": "☰", "globe": "◍", "box": "◈", "clock": "≡",
    "settings": "⚙", "sparkles": "✦", "play": "▶",
  };

  /* 条目大类 → 图标名 */
  const KIND = {
    工程: "box", 世界: "globe", 人物: "user", 关系: "git-branch", 地点: "map-pin",
    资产: "box", 时间线: "clock", 事件: "play", 变量: "variable", 决策: "split",
    行为: "repeat", 文风: "palette", 剧本: "scroll-text",
  };

  function url(name) {
    const file = ICONS[name] || name;
    return `${BASE}${file}.svg`;
  }

  /* 返回图标标签字符串，供 v-html 使用。

     为什么用 CSS mask 而不是 <img>：
     Lucide 的 SVG 是 stroke="currentColor"，用 <img> 引用时无法继承 CSS 颜色，
     暗色主题下会变成透明/黑色看不清。用 mask-image + background-color，
     图标颜色就跟着 currentColor 走，换主题自动适配。

     data-g 是离线兜底字形：CDN 拉不到时给 <html> 加 no-icon-cdn，
     CSS 用 ::after 把字形显示出来，界面不会出现一片空白。 */
  function icon(name, extraClass) {
    const cls = "ico-mask" + (extraClass ? " " + extraClass : "");
    const g = (FALLBACK[name] || "•").replace(/"/g, "&quot;");
    return `<span class="${cls}" style="--ico:url('${url(name)}')" data-g="${g}" aria-hidden="true"></span>`;
  }

  /* 加载失败时的兜底字形（离线或 CDN 不可达）。
     做法：探测一张小图，失败就给 <html> 加 no-icon-cdn，
     CSS 用 .ico-mask::after 显示兜底字形。 */

  function kindIcon(kind) {
    return KIND[kind] || "file";
  }

  /* 探测一次 CDN：拉不到就给 <html> 加 no-icon-cdn，CSS 改用字形兜底 */
  function probe() {
    try {
      const img = new Image();
      img.onerror = () => document.documentElement.classList.add("no-icon-cdn");
      img.src = url("file");
    } catch (e) { /* 忽略 */ }
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", probe);
  } else {
    probe();
  }

  window.LingshuIcon = { icon, url, kindIcon, KIND, ICONS };
})();
