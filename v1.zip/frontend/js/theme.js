/* 配色系统：内置几套方案 + 自定义。
   一套方案 = 一组 CSS 变量。切换主题只改 <html data-theme> 与自定义变量，
   所有颜色都从变量来，样式表里不出现硬编码颜色。 */
(function () {
  "use strict";

  /* 每套主题的键：
     bg      页面底色          panel   面板底
     ink     主文字            dim     次要文字
     line    分隔线            accent  强调色（当前行/选中）
     btnBg   按钮底            btnInk  按钮字
     代码区（编辑器）专用：
     codeBg / codeInk / gutterBg / gutterInk / selBg / lineNoActive
     语法高亮 token：
     tComment / tKey / tString / tNumber / tRef / tTag / tPunct */
  const THEMES = {
    paper: {
      name: "宣纸",
      vars: {
        "--bg": "#f3efe7", "--panel": "#fbf8f2", "--ink": "#2f2a24", "--dim": "#8a8175",
        "--line": "#e2dacd", "--accent": "#9a5b34", "--btnBg": "#efe8dc", "--btnInk": "#3a332b",
        "--codeBg": "#fbf8f2", "--codeInk": "#2f2a24", "--gutterBg": "#f2ece1", "--gutterInk": "#a99e8e",
        "--selBg": "#e7ddcc", "--lineNoActive": "#9a5b34",
        "--tComment": "#9a8f7e", "--tKey": "#8a4b1e", "--tString": "#4a6b3d",
        "--tNumber": "#b2562c", "--tRef": "#3d6b8a", "--tTag": "#7a4a8a", "--tPunct": "#a09384"
      }
    },
    ink: {
      name: "墨蓝",
      vars: {
        "--bg": "#eef1f5", "--panel": "#f7f9fc", "--ink": "#1f2733", "--dim": "#77808f",
        "--line": "#dbe1ea", "--accent": "#2f5d8a", "--btnBg": "#e7edf5", "--btnInk": "#243040",
        "--codeBg": "#f7f9fc", "--codeInk": "#1f2733", "--gutterBg": "#eaf0f7", "--gutterInk": "#9aa5b5",
        "--selBg": "#dde7f3", "--lineNoActive": "#2f5d8a",
        "--tComment": "#8b96a5", "--tKey": "#215a8a", "--tString": "#2e7a5a",
        "--tNumber": "#a8552c", "--tRef": "#6a4a9a", "--tTag": "#9a3f6a", "--tPunct": "#98a1ae"
      }
    },
    moss: {
      name: "苔绿",
      vars: {
        "--bg": "#eef1ea", "--panel": "#f8faf5", "--ink": "#242c22", "--dim": "#7d8677",
        "--line": "#dde3d6", "--accent": "#4a6b3d", "--btnBg": "#e9efe1", "--btnInk": "#2c3527",
        "--codeBg": "#f8faf5", "--codeInk": "#242c22", "--gutterBg": "#edf2e6", "--gutterInk": "#9aa693",
        "--selBg": "#e0e9d6", "--lineNoActive": "#4a6b3d",
        "--tComment": "#8d9985", "--tKey": "#3f6b2c", "--tString": "#2e6b7a",
        "--tNumber": "#a05a2c", "--tRef": "#5a4a8a", "--tTag": "#8a4a5a", "--tPunct": "#98a292"
      }
    },
    dark: {
      name: "暗夜",
      vars: {
        "--bg": "#1c1e22", "--panel": "#24272c", "--ink": "#e6e4df", "--dim": "#8b9098",
        "--line": "#34383f", "--accent": "#7aa2d6", "--btnBg": "#2e3238", "--btnInk": "#e6e4df",
        "--codeBg": "#1f2227", "--codeInk": "#e6e4df", "--gutterBg": "#1a1c20", "--gutterInk": "#5d636c",
        "--selBg": "#2c3440", "--lineNoActive": "#7aa2d6",
        "--tComment": "#6b7280", "--tKey": "#c792ea", "--tString": "#9ece6a",
        "--tNumber": "#ff9e64", "--tRef": "#7dcfff", "--tTag": "#f7768e", "--tPunct": "#8b9098"
      }
    },
    slate: {
      name: "石墨",
      vars: {
        "--bg": "#e8e9eb", "--panel": "#f4f5f6", "--ink": "#25282c", "--dim": "#7c8188",
        "--line": "#d6d8db", "--accent": "#4a5560", "--btnBg": "#e2e4e6", "--btnInk": "#2b2f34",
        "--codeBg": "#f4f5f6", "--codeInk": "#25282c", "--gutterBg": "#e9eaec", "--gutterInk": "#9ba0a6",
        "--selBg": "#dde0e3", "--lineNoActive": "#4a5560",
        "--tComment": "#91969c", "--tKey": "#3d4a57", "--tString": "#4a6b52",
        "--tNumber": "#8a5a3a", "--tRef": "#3f5f7a", "--tTag": "#6f4a6b", "--tPunct": "#9a9ea3"
      }
    }
  };

  /* 可被用户单独覆盖的变量（设置里的「配色调整」） */
  const TUNABLES = [
    { key: "--bg", label: "页面底色" },
    { key: "--panel", label: "面板底色" },
    { key: "--ink", label: "主文字" },
    { key: "--dim", label: "次要文字" },
    { key: "--line", label: "分隔线" },
    { key: "--accent", label: "强调色" },
    { key: "--codeBg", label: "代码区底" },
    { key: "--codeInk", label: "代码区字" },
    { key: "--tComment", label: "注释 @行" },
    { key: "--tKey", label: "键名" },
    { key: "--tString", label: "字符串" },
    { key: "--tNumber", label: "数字" },
    { key: "--tRef", label: "引用 v./s./r." }
  ];

  const STORE_KEY = "lingshu.v3.theme";
  const CUR = { name: "paper", custom: {} };

  function apply(themeName, custom) {
    const t = THEMES[themeName] || THEMES.paper;
    const root = document.documentElement;
    CUR.name = THEMES[themeName] ? themeName : "paper";
    CUR.custom = custom || {};
    // 先写主题默认值，再用用户覆盖
    for (const [k, v] of Object.entries(t.vars)) root.style.setProperty(k, v);
    for (const [k, v] of Object.entries(CUR.custom)) {
      if (v) root.style.setProperty(k, v);
    }
    root.setAttribute("data-theme", CUR.name);
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify({ name: CUR.name, custom: CUR.custom }));
    } catch (e) { /* 隐私模式下忽略 */ }
  }

  function load() {
    let saved = null;
    try { saved = JSON.parse(localStorage.getItem(STORE_KEY) || "null"); } catch (e) { saved = null; }
    apply(saved && saved.name ? saved.name : "paper", (saved && saved.custom) || {});
    return { ...CUR };
  }

  function reset(themeName) {
    apply(themeName || CUR.name, {});
  }

  function valueOf(key) {
    const t = THEMES[CUR.name] || THEMES.paper;
    return CUR.custom[key] || t.vars[key] || "";
  }

  window.LingshuTheme = {
    THEMES, TUNABLES, apply, load, reset, valueOf,
    current: () => ({ ...CUR }),
    list: () => Object.entries(THEMES).map(([id, t]) => ({ id, name: t.name })),
  };
})();
