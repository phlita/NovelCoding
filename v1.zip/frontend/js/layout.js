/* 布局：面板显隐 / 面板顺序 / 三栏宽度。全部持久化到 localStorage。

   设计取舍：
   · 面板顺序只允许在三栏内部重排（左栏内部、右栏内部），不跨栏拖动——
     跨栏重排会让「中栏放代码区」这种破坏性状态成为可能，而中栏是编辑核心。
   · 显隐与顺序都只影响 DOM 的 v-if / 排序，不改内存里的数据。
   · 三栏宽度用 flex-basis（px），中栏占剩余空间，所以左右变宽时中栏自动收窄。 */
(function () {
  "use strict";

  const KEY = "lingshu.v3.layout";

  /* 可显隐/重排的面板。group 决定它能和谁换位置。 */
  const PANELS = [
    { id: "left.tree", group: "left", label: "本项目文件树" },
    { id: "left.build", group: "left", label: "构建产物" },
    { id: "left.library", group: "left", label: "公共库" },
    { id: "right.chat", group: "right", label: "AI 对话" },
    { id: "right.ops", group: "right", label: "操作按钮" },
  ];

  const DEFAULTS = {
    visible: { "left.tree": true, "left.build": true, "left.library": true,
               "right.chat": true, "right.ops": true },
    order: { left: ["left.tree", "left.build", "left.library"],
             right: ["right.chat", "right.ops"] },
    widths: { left: 250, right: 310 },
    /* 面板高度（px）。null = 不指定，由 flex 分配剩余空间。
       左栏三个面板：本项目与公共库平分剩余，构建产物给固定高度。 */
    heights: { "left.tree": null, "left.build": 180, "left.library": null,
               "right.chat": null, "right.ops": null },
    /* 折叠状态 */
    collapsed: {},
    MIN: { left: 180, right: 220, mid: 380 },
  };

  let state = null;

  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  function normalize(raw) {
    const out = clone(DEFAULTS);
    if (!raw || typeof raw !== "object") return out;
    if (raw.visible && typeof raw.visible === "object") {
      for (const p of PANELS) {
        if (typeof raw.visible[p.id] === "boolean") out.visible[p.id] = raw.visible[p.id];
      }
    }
    if (raw.order && typeof raw.order === "object") {
      for (const g of ["left", "right"]) {
        const want = Array.isArray(raw.order[g]) ? raw.order[g].filter(id => PANELS.some(p => p.id === id && p.group === g)) : [];
        const rest = DEFAULTS.order[g].filter(id => !want.includes(id));
        if (want.length || rest.length) out.order[g] = want.concat(rest);
      }
    }
    if (raw.widths && typeof raw.widths === "object") {
      for (const g of ["left", "right"]) {
        const n = Number(raw.widths[g]);
        if (Number.isFinite(n)) out.widths[g] = clamp(g, n);
      }
    }
    if (raw.heights && typeof raw.heights === "object") {
      for (const p of PANELS) {
        if (!(p.id in out.heights)) continue;
        const v = raw.heights[p.id];
        if (v === null) { out.heights[p.id] = null; continue; }
        const n = Number(v);
        if (Number.isFinite(n)) out.heights[p.id] = clampH(n);
      }
    }
    if (raw.collapsed && typeof raw.collapsed === "object") {
      for (const p of PANELS) {
        if (typeof raw.collapsed[p.id] === "boolean") out.collapsed[p.id] = raw.collapsed[p.id];
      }
    }
    return out;
  }

  /* 面板高度夹取：最小够露出一行标题，最大不超半屏 */
  function clampH(n) {
    return Math.max(90, Math.min(1200, Math.round(n)));
  }

  function clamp(which, n) {
    const min = DEFAULTS.MIN[which] || 120;
    const max = which === "mid" ? 100000 : 520;
    return Math.max(min, Math.min(max, Math.round(n)));
  }

  function load() {
    let raw = null;
    try { raw = JSON.parse(localStorage.getItem(KEY) || "null"); } catch (e) { raw = null; }
    state = normalize(raw);
    return state;
  }

  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { /* 忽略 */ }
  }

  function get() { return state || load(); }
  function setVisible(id, v) { const s = get(); s.visible[id] = !!v; save(); return s; }
  function setOrder(group, ids) { const s = get(); s.order[group] = ids.slice(); save(); return s; }
  function setWidth(which, px) { const s = get(); s.widths[which] = clamp(which, px); save(); return s; }
  function setHeight(id, px) {
    const s = get();
    if (!(id in s.heights)) return s;
    s.heights[id] = (px === null) ? null : clampH(px);
    save(); return s;
  }
  function setCollapsed(id, v) {
    const s = get();
    s.collapsed[id] = !!v;
    save(); return s;
  }
  function reset() { state = clone(DEFAULTS); save(); return state; }
  function panels(group) { return PANELS.filter(p => !group || p.group === group); }

  window.LingshuLayout = {
    PANELS, DEFAULT_WIDTHS: DEFAULTS.widths, MIN: DEFAULTS.MIN,
    load, get, save, setVisible, setOrder, setWidth, setHeight, setCollapsed,
    reset, panels, clamp, clampH,
  };
})();
