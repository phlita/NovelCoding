/* 条目文件语法高亮。
   v3 的文件只有两种行：
     · @ 开头  → 注释区（导演说明 / 前置 / 效果 / 揭示 / 依赖）
     · 其余    → 正文区（键值、数值、剧本分镜）
   以及三种引用：v.变量  s.人物.字段  r.甲-乙.字段，和剧本里的对白/动作/内心标记。

   输出 HTML 片段（已转义）。为了能在 textarea 上方叠加显示，每行返回一个
   <span class="ln">…</span>，行号由外层 gutter 单独渲染。 */
(function () {
  "use strict";

  function esc(s) {
    return String(s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  // 一条正文行里的着色：先切出引用/数字/引号，再包 span
  const REF_RE = /\b([vsr])\.([^\s=<>!+*/(),]+)/g;
  const NUM_RE = /(?<![\w.])(-?\d+(?:\.\d+)?)(?![\w.])/g;
  const QUOTE_RE = /([「『][^」』]*[」』])/g;

  function paintBody(line) {
    let out = esc(line);
    // 引用 v./s./r. （在已转义文本上操作是安全的：这些字符不会被转义改写）
    out = out.replace(REF_RE, (m, kind, rest) => `<span class="t-ref">${m}</span>`);
    out = out.replace(NUM_RE, (m) => `<span class="t-num">${m}</span>`);
    out = out.replace(QUOTE_RE, (m) => `<span class="t-str">${m}</span>`);
    return out;
  }

  // 注释行的 @键 高亮，其余按普通文字
  function paintNote(line) {
    const m = /^(\s*)(@[^\s　:：]*)(.*)$/.exec(line);
    if (!m) return esc(line);
    const [, space, tag, rest] = m;
    let tail = esc(rest);
    tail = tail.replace(REF_RE, (x) => `<span class="t-ref">${x}</span>`);
    tail = tail.replace(NUM_RE, (x) => `<span class="t-num">${x}</span>`);
    return `${space}<span class="t-tag">${esc(tag)}</span>${tail}`;
  }

  // 剧本分镜标记：> 动作 / 「对白」/（内心）
  function paintScript(line) {
    const s = line.trimStart();
    if (s.startsWith(">")) return `<span class="t-key">${esc(line)}</span>`;
    if (s.startsWith("（") || s.startsWith("(")) return `<span class="t-comment">${esc(line)}</span>`;
    let out = esc(line);
    out = out.replace(QUOTE_RE, (m) => `<span class="t-str">${m}</span>`);
    return out;
  }

  /* 主入口：整篇文本 → HTML（每行一个 block 元素）

     关键：**行与行之间不能有换行符**。
     容器是 white-space: pre，join("\n") 会让那个换行也各占一行，
     再叠加 .cl 自身的 block 换行 → 行数翻倍，行号与内容就永远对不上。
     所以这里用空串连接，每行只由 .cl 这一个 block 负责换行。
     空行用 " "（一个空格）占位，不用 &nbsp;——后者在 pre 下会撑出多余宽度。 */
  function render(text, kind) {
    const lines = String(text == null ? "" : text).split("\n");
    const out = [];
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      let html;
      if (/^\s*@/.test(line)) html = paintNote(line);
      else if (kind === "剧本") html = paintScript(line);
      else if (/^\s*$/.test(line)) html = "";
      else html = paintBody(line);
      // 空行也要占一个 .cl，否则行号会和内容错位
      out.push(`<div class="cl">${html || " "}</div>`);
    }
    return out.join("");
  }

  /* 行号栏 */
  function gutter(count) {
    const out = [];
    for (let i = 1; i <= count; i++) out.push(`<span class="gl">${i}</span>`);
    return out.join("");
  }

  window.LingshuHighlight = { render, gutter, esc };
})();
